/*
 * SchemaSelectionPanel.java
 *
 * Created on August 16, 2007, 8:12 PM
 */

package com.enterprisedb.migration.panels;

import com.enterprisedb.migration.panels.model.ObjectTypeListModel;
import com.enterprisedb.migration.panels.renderer.ImageableCellRenderer;
import com.enterprisedb.migration.util.WizardUtils;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;
import java.awt.Color;
import javax.swing.ListModel;
import org.netbeans.spi.wizard.Wizard;
import org.netbeans.spi.wizard.WizardPage;
import org.netbeans.spi.wizard.WizardPanelNavResult;

/**
 *
 * @author  altaf
 */
public class SchemaSelectionPanel extends WizardPage {
    
    /** Creates new form SchemaSelectionPanel */
    public SchemaSelectionPanel() {
        super("Step3", DESCRIPTION);
        initComponents();   //initialize components
        updateData();   //update data        
        listPanel.targetList.setCellRenderer(new ImageableCellRenderer("schema.png"));
        listPanel.sourceList.setCellRenderer(new ImageableCellRenderer("schema.png"));
        setBackground(Color.WHITE);
    }
    
    /**
     * Get description of the step
     * This method is required by wizard framework to get the description of each step
     * @return description of the step
     */
    
    public static String getDescription() {
        return DESCRIPTION;
    }
    /**
     * Get selected schemas
     * This method is called by ObjectSelectionPanel to get the list of schemas selected by user
     * @return ArrayList containing schema names
     */
    
    public static ArrayList getSelectedSchemas() {
        return selectedSchemas;
    }
    
    /**
     * Load the schemas in source list based on the filter
     */
    
    private void updateData() {
        // Get schemas from MySQL connection based on the filter
        String data[] = getSchemas(SourceDatabasePanel.getConnection(), WizardUtils.escapeMysqlString(filter.getText())+"%");
        
        //Get model of the source list
        ObjectTypeListModel model = (ObjectTypeListModel) listPanel.sourceList.getModel();
        model.clear();  //clear the contents
        for(int i=0; i< data.length; i++) { // and repopulate the source list
            // make sure the the item has not already been selected and available in target list
            if(!WizardUtils.inTarget(data[i], (ObjectTypeListModel)listPanel.targetList.getModel()))
                model.addItem(data[i]);
        }
        listPanel.sourceList.updateUI();  //finally update the UI o sourceList
        
        //update buttons
        listPanel.updateButtons();        
    }
    
    /**
     * This function is called when the user has pressed 'Next' button
     * We will get the selected items and add them to selectedItems array so that 
     * when next panels call getSelectedSchemas() method of this panel, they get  valid 
     * list of schemas
     *
     * @param stepName the name of the step
     * @param settings the parameter map gathered on this screen
     * @return status to indicate that we should remain on same page or proceed further
     */
    
    public WizardPanelNavResult allowNext(String stepName, Map settings,
            Wizard wizard) {
        
        //build an array of data and add it as parameter
        ListModel lm = listPanel.targetList.getModel();        
        if(lm.getSize() == 0) {
            WizardUtils.showError(this, "No schema selected for migration", "Error");
            return WizardPanelNavResult.REMAIN_ON_PAGE;
        }
        selectedSchemas = new ArrayList<String>(lm.getSize());
        for(int i=0; i< lm.getSize(); i++)
            selectedSchemas.add((String)lm.getElementAt(i));        
                   
        WizardUtils.addAllParams(settings);
        return super.allowNext(stepName, settings, wizard);
    }
    
    /**
     * Get schemas selected by user
     * @param con the source connection that should be used to get schemas
     * @param schemaPattern the schema pattern that should be used to filter results
     * @return String[] containing the schemas
     */
    
    private String[] getSchemas(Connection con, String schemaPattern) {        
        ArrayList<String> data = new ArrayList<String>();
        try{
            /*Schemas in MySQL are actually catalogs .. but we are not using getCatalogs() method of
             DatabaseMetaData because we need to filter out the results. We will use query to find out
             the schemas */
            
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT SCHEMA_NAME FROM information_schema.schemata where SCHEMA_NAME LIKE '"+schemaPattern+"' AND SCHEMA_NAME <> 'information_schema' AND SCHEMA_NAME <> 'mysql'");
            while(rs.next()) {  // Iterate through the result set and add items to data array
                data.add(rs.getString("SCHEMA_NAME"));
            }
            rs.close(); // close result set and the statement objects
            st.close();
        }catch(Exception exp){
            exp.printStackTrace();
        }
        return data.toArray(new String[0]);
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        javax.swing.JLabel filterLabel;
        javax.swing.JButton refresh;
        javax.swing.JPanel topPanel;

        topPanel = new javax.swing.JPanel();
        filterLabel = new javax.swing.JLabel();
        filter = new javax.swing.JTextField();
        refresh = new javax.swing.JButton();
        listPanel = new com.enterprisedb.migration.panels.ListSelectionPanel();

        setLayout(new java.awt.BorderLayout());

        filterLabel.setText("Filter Source Schemas");

        filter.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                filterKeyReleased(evt);
            }
        });

        refresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/enterprisedb/migration/images/refresh.png")));
        refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout topPanelLayout = new org.jdesktop.layout.GroupLayout(topPanel);
        topPanel.setLayout(topPanelLayout);
        topPanelLayout.setHorizontalGroup(
            topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(topPanelLayout.createSequentialGroup()
                .add(filter, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 160, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(6, 6, 6)
                .add(refresh, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(389, Short.MAX_VALUE))
            .add(topPanelLayout.createSequentialGroup()
                .add(filterLabel)
                .addContainerGap(460, Short.MAX_VALUE))
        );
        topPanelLayout.setVerticalGroup(
            topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(topPanelLayout.createSequentialGroup()
                .add(filterLabel)
                .add(5, 5, 5)
                .add(topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, filter, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, refresh, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 26, Short.MAX_VALUE))
                .addContainerGap())
        );
        add(topPanel, java.awt.BorderLayout.PAGE_START);

        add(listPanel, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        updateData();
    }//GEN-LAST:event_refreshActionPerformed

    private void filterKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filterKeyReleased
        updateData();
    }//GEN-LAST:event_filterKeyReleased
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField filter;
    private com.enterprisedb.migration.panels.ListSelectionPanel listPanel;
    // End of variables declaration//GEN-END:variables
    
    private static String DESCRIPTION = "Source Schema";
    private static ArrayList<String> selectedSchemas = null;    
}
