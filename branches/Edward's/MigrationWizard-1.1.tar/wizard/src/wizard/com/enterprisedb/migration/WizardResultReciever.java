/*
 * WizardResultReciever.java
 *
 * Created on August 8, 2007, 2:50 PM
 *
 * This class is the main event handler for the Finish or Cancel events
 * If user has pressed Finish button, it saves the gathered data to the
 * preferences and exits. On Cancel, it prompts user to really exit or not.
 * Upon confirmation, it simply terminates.
 */

package com.enterprisedb.migration;

import com.enterprisedb.migration.panels.DestinationDatabasePanel;
import com.enterprisedb.migration.panels.SourceDatabasePanel;
import com.enterprisedb.migration.util.WizardUtils;
import java.util.Iterator;
import java.util.Map;
import java.util.prefs.Preferences;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.netbeans.api.wizard.WizardResultReceiver;

/**
 *
 * @author altaf
 */
public class WizardResultReciever implements WizardResultReceiver {
    
    /**
     * Creates a new instance of WizardResultReciever
     * @param container the container that needs to be closed upon Cancel or
     * Finish after taking the necesssary action
     */
    
    public WizardResultReciever(JFrame container) {
        this.container = container;
    }
    
    /**
     * This function handles the "Finish" event
     * @param wizardResult Result of the wizard produced by WizardResult.finish
     */
    
    public void finished(Object wizardResult) {
        if(wizardResult instanceof Map) //If this is a Map, store preferences
            savePreferences((Map)wizardResult);
        try {   // close the connections
            SourceDatabasePanel.getConnection().close();
            DestinationDatabasePanel.getConnection().close();
        } catch (Exception ex) {
        }
        container.dispose();    //Close the wizard
        System.exit(0); //terminate
    }
    
    /**
     * This function handles the "Finish" event
     * @param settings Map of parameters entered during the wizard
     */
    
    public void cancelled(Map settings) {
        boolean dialogShouldClose = JOptionPane.showConfirmDialog(null,
                "Do you really want to exit?", "Confirmation", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
        if(dialogShouldClose) {
            savePreferences(settings); //save the preferences
            try {   // close the connections
                SourceDatabasePanel.getConnection().close();
                DestinationDatabasePanel.getConnection().close();
            } catch (Exception ex) {
            }
                container.dispose();    // close the container
                System.exit(-1);    // terminate
            }
    }
    
    /**
     * Save the wizard data to preferences
     * This function stores the parameters gathered during wizard process so that
     * they can be loaded as default values on next launch
     *
     * @param gatheredSettings the parameters gathered during wizard
     */
    
    private void savePreferences(Map gatheredSettings) {
        if (gatheredSettings != null && gatheredSettings.size() > 0) {
            Preferences prefs = WizardUtils.getPreferences();
            Iterator keys = gatheredSettings.keySet().iterator();
            //Iterate through the map and store all keys except source
            //and destination PASSWORD fields
            while(keys.hasNext()) {
                String key = (String)keys.next();
                if(!SourceDatabasePanel.PASSWORD.equals(key) && !DestinationDatabasePanel.PASSWORD.equals(key))
                    prefs.put(key,gatheredSettings.get(key).toString());
            }
        }
    }
    // Variable declaration section
    private JFrame container = null; //Reference to the container that needs to be closed upon Finish or Cancel
}
