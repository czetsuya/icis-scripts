/*
 * DestinationDatabasePanel.java
 *
 * Created on August 8, 2007, 8:04 PM
 *
 * This panel collects destination (PostgreSQL) database credentials
 */

package com.enterprisedb.migration.panels;

import com.enterprisedb.migration.util.WizardUtils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;
import java.awt.Color;
import org.netbeans.spi.wizard.Wizard;
import org.netbeans.spi.wizard.WizardPanelNavResult;

/**
 *
 * @author altaf
 */
public class DestinationDatabasePanel extends ConnectionInput {
    
    /** Creates a new instance of DestinationDatabasePanel */
    public DestinationDatabasePanel() {        
        super("Step2", DESCRIPTION);
        // Set the names and default values of the input fields
        // names are required by the wizard framework to populate them as a wizard data
        
        WizardUtils.setUpTextComponent(host, HOST, "localhost");    // set up host field
        WizardUtils.setUpTextComponent(port, PORT, "5432");         // set up port field
        WizardUtils.setUpTextComponent(db, DATABASE, "postgres");   // set up database field
        WizardUtils.setUpTextComponent(user, USER, "postgres");     // set up user field
        WizardUtils.setUpTextComponent(password, PASSWORD, "");     // set up password field
    }
    
    /**
     * Get description of the step
     * This method is required by wizard framework to get the description of each step
     * @return description of the step
     */
    
    public static String getDescription() {
        return DESCRIPTION;
    }
    
    /**
     * Get PostgreSQL connection
     * This function will return null if the user has not yet pressed next button
     * after entering the credentials
     * @return Connection to the PostgreSQL instance
     */    
    public static Connection getConnection() {
        return conn;
    }
    
    /**
     * This function is called when the user has pressed 'Next' button
     * We will validate the data entered by user, and try to connect to the database
     * If we failed, we will report the error and remain on the same page. Otherwise
     * proceed for the next screen
     *
     * @param stepName the name of the step
     * @param settings the parameter map gathered on this screen
     * @return status to indicate that we should remain on same page or proceed further
     */
    
    public WizardPanelNavResult allowNext(String stepName, Map settings,
            Wizard wizard) {
        
        //Get credentials from settings
        String host = (String)settings.get(HOST);
        String port = (String)settings.get(PORT);
        String dbname = (String)settings.get(DATABASE);
        String user = (String)settings.get(USER);
        String password = (String)settings.get(PASSWORD);
        
        if(host.length() == 0) {    // user did not enter host value
            WizardUtils.showError(this, "Host is a required field", "Input Error");
            return WizardPanelNavResult.REMAIN_ON_PAGE;
        }
        if(port.length() == 0) {    // user did not enter port
            WizardUtils.showError(this, "Port is a required field", "Input Error");
            return WizardPanelNavResult.REMAIN_ON_PAGE;
        }
        if(dbname.length() == 0) {  // user did not enter database
            WizardUtils.showError(this, "Database Name is a required field", "Input Error");
            return WizardPanelNavResult.REMAIN_ON_PAGE;
        }
        if(user.length() == 0) {    // user did not enter user name
            WizardUtils.showError(this, "User is a required field", "Input Error");
            return WizardPanelNavResult.REMAIN_ON_PAGE;
        }
        //password may be empty
        
        //Load the driver for MySQL
        try{
            Class.forName("com.edb.Driver");
        }catch(ClassNotFoundException cnfe) {
            //ignore it. DriverManager will generate beautiful error message if failed to connect
        }
        //Now connect with the database
        try{
            DriverManager.setLoginTimeout(5);   // set LoginTimeout to 5 seconds
            conn = DriverManager.getConnection("jdbc:edb://"+host+":"+port+"/"+dbname, user, password);
        }catch(SQLException exp) {
            WizardUtils.showError(this, "Could not connect to the target database\n"+exp.getMessage(),"Connection Error");
            return WizardPanelNavResult.REMAIN_ON_PAGE;
        }
        //save the parameters
        WizardUtils.addAllParams(settings);
        //return
        return super.allowNext(stepName, settings, wizard);
    }

    //Variable declaration section
    private static String DESCRIPTION = "Destination DB information";
    public static String HOST = "DEST_Host";
    public static String PORT = "DEST_Port";
    public static String DATABASE = "DEST_Database";
    public static String USER = "DEST_User";
    public static String PASSWORD = "DEST_Password";
    private static Connection conn = null;
}
