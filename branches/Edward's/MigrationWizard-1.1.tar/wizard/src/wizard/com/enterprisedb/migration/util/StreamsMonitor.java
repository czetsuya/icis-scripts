package com.enterprisedb.migration.util;

import javax.swing.text.JTextComponent;
import java.io.*;
import javax.swing.text.Document;
import javax.swing.text.BadLocationException;

public class StreamsMonitor {

    private JTextComponent textComponent;
    private BufferedReader inOut;
    private BufferedReader inErr;

    private StreamMonitorThread outThread;
    private StreamMonitorThread errThread;

    private boolean closeStreamOnExit;


    public StreamsMonitor(JTextComponent textComponent, InputStream inOut,
                          InputStream inErr) {

        this.textComponent = textComponent;
        this.inOut = new BufferedReader(new InputStreamReader(inOut));
        this.inErr = new BufferedReader(new InputStreamReader(inErr));

        this.closeStreamOnExit = false;
    }

    public void setCloseStreamOnExit(boolean value) {
        this.closeStreamOnExit = value;
    }

    public boolean isCloseStreamOnExit() {
        return this.closeStreamOnExit;
    }

    public void start() {
        if (inOut != null) {
            this.outThread = new StreamMonitorThread(textComponent, inOut);
            this.outThread.start();
        }
//        if (inErr != null) {
//            this.errThread = new StreamMonitorThread(textComponent, inErr);
//            this.errThread.start();
//        }
    }

    public void stop() {
        if (outThread != null) {
            this.outThread.stopThread();
        }
        if (errThread != null) {
            this.errThread.stopThread();
        }
    }

    class StreamMonitorThread extends Thread {
        private JTextComponent textComp;
        private Document doc;
        private BufferedReader in;
        private boolean stop = false;

        public StreamMonitorThread (JTextComponent textComp,
                                    BufferedReader in) {
            this.textComp = textComp;
            this.doc = textComp.getDocument();
            this.in = in;
        }

        public void run() {
            String line = null;
            try {
                while ((line = in.readLine()) != null &&  !stop) {
                    try {                        
                        doc.insertString(doc.getLength(), line+"\n", null);                        
                    } catch (BadLocationException blexp) {
                        WizardUtils.showError(null, blexp.getMessage(), "Error");
                    }
                }
            } catch (Exception exp) {
                WizardUtils.showError(null, exp.getMessage(), "Error");
            } finally {
                if (StreamsMonitor.this.isCloseStreamOnExit()) {
                    try {
                        in.close();
                    } catch (Exception exp) {}
                }
            }
        }

        public void stopThread() {
            this.stop = true;
        }
    }
}
