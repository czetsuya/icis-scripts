/*
 * WizardResult.java
 *
 * Created on August 3, 2007, 1:00 PM
 *
 * This class gets intimated when finish or cancel events occure in the wizard
 */

package com.enterprisedb.migration;

import java.util.Map;
import org.netbeans.spi.wizard.WizardException;
import org.netbeans.spi.wizard.WizardPage;

/**
 *
 * @author altaf
 */
public class WizardResult implements WizardPage.WizardResultProducer {
    
    /**
     * This function is called when the user has pressed "Finish" button
     * @param wizardData Map of parameters entered during the wizard
     * @return Object data we actually want to return to handlers
     */
    
    public Object finish(Map wizardData) throws WizardException {
        return wizardData;
    }
    
    /**
     * This function is called when the user has pressed "Cancel" button
     * @param settings Map of parameters entered during the wizard
     * @return true indicating that wizard can be cancelled
     */

    public boolean cancel(Map settings) {
        return true;
    }
}