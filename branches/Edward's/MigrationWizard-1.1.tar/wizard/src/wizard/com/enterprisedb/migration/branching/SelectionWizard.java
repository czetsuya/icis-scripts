/*
 * SelectionWizard.java
 *
 * Created on August 21, 2007, 3:26 PM
 * 
 */

package com.enterprisedb.migration.branching;

import com.enterprisedb.migration.panels.FinishPanel;
import com.enterprisedb.migration.panels.MigrationPanel;
import com.enterprisedb.migration.panels.ObjectSelectionPanel;
import com.enterprisedb.migration.panels.OptionsPanel;
import com.enterprisedb.migration.panels.SchemaSelectionPanel;
import java.util.Map;
import javax.swing.JComponent;
import org.netbeans.spi.wizard.WizardBranchController;
import org.netbeans.spi.wizard.WizardController;
import org.netbeans.spi.wizard.WizardPanelProvider;

/**
 *
 * @author altaf
 */
public class SelectionWizard extends WizardBranchController {
    
    /** Creates a new instance of SelectionWizard */
    public SelectionWizard() {
        super(new InitialSeps());
        
    }
    protected WizardPanelProvider getPanelProviderForStep(String step, Map collectedData) {
        //if(Boolean.TRUE.equals(collectedData.get(OptionsPanel.MIGRATION_SCHEMA_ONLY))) {
        if(false) {
            return new WizardPanelProvider(new String[]{"schemaSelection", "migration"},
                    new String[]{SchemaSelectionPanel.getDescription(), MigrationPanel.getDescription()}) {
                protected JComponent createPanel(WizardController wizardController, String id, Map map) {
                    switch ( indexOfStep( id ) ) {
                        case 0:
                            return new SchemaSelectionPanel();
                        case 1:
                            return new MigrationPanel();
                        default: 
                            throw new IllegalArgumentException ( id );
                    }
                }
                
            };
        }else {
            return new WizardPanelProvider(new String[]{"schemaSelection", "objectSelection","migration", "done"},
                    new String[]{SchemaSelectionPanel.getDescription(), ObjectSelectionPanel.getDescription(), MigrationPanel.getDescription(), "Finish"}) {
                protected JComponent createPanel(WizardController wizardController, String id, Map map) {
                    switch ( indexOfStep( id ) ) {
                        case 0:
                            return new SchemaSelectionPanel();
                        case 1:
                            return new ObjectSelectionPanel();
                        case 2:
                            return new MigrationPanel();
                        case 3:
                            return new FinishPanel();
                        default: 
                            throw new IllegalArgumentException ( id );
                    }
                }
                
            };
        }
    }
    
}
