/*
 * WizardUtils.java
 *
 * Created on August 8, 2007, 12:55 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.migration.util;

import com.enterprisedb.migration.panels.model.ObjectTypeListModel;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.prefs.Preferences;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author altaf
 */
public class WizardUtils {
    
   /**
     * Determine if the given Object is in target list?
     * This function is called prior to adding the item in SourceList while 
     * updating the data so that and item is not duplicated in both source aand target list
     */
    public static boolean inTarget(Object obj, ObjectTypeListModel targetModel) {
        for(int i=0; i< targetModel.getSize(); i++) {
            if(targetModel.getElementAt(i).equals(obj))
                return true;
        }
        return false;
    }    
    
    /**
     * Move all items from source list to target list
     * @param srcList source list
     * @param targetList the target list
     */
    public static void moveAllItems(JList srcList, JList targetList) {
        ObjectTypeListModel fromModel = (ObjectTypeListModel) srcList.getModel();
        ObjectTypeListModel toModel = (ObjectTypeListModel) targetList.getModel();
        while(fromModel.getSize()> 0) {
            toModel.addItem(fromModel.remove(0));
        }
        srcList.updateUI();
        targetList.updateUI();
    }
    
    /**
     * Move the selected items from source list to the target list
     * @param srcList source list
     * @param targetList the target list
     */
    public static void moveSelectedItems(JList srcList, JList targetList) {
        ObjectTypeListModel fromModel = (ObjectTypeListModel) srcList.getModel();
        ObjectTypeListModel toModel = (ObjectTypeListModel) targetList.getModel();
        int[] indices = srcList.getSelectedIndices();
        for(int i=0; i< indices.length; i++) {
            toModel.addItem(fromModel.remove(indices[i]-i));
        }
        srcList.updateUI();
        targetList.updateUI();
        srcList.setSelectedIndices(new int[]{});
        targetList.setSelectedIndices(new int[]{});
    } 
    
    /**
     * Set the size of the component
     * This function is used to set the Size (prefered, minimum and maximum) of 
     * a component so that the component does not change it's shape when the parent is resized
     * @param JComponent the component on which size should be applied
     * @param d the Dimension that represents size of the component
     */
    
    public static void setComponentSize(JComponent comp, Dimension d) {
        comp.setMaximumSize(d);
        comp.setMinimumSize(d);
        comp.setPreferredSize(d);
    }
    
    /**
     * Display the error message
     * @param parent the parent component
     * @param errorMessage the errror message to display
     * @param title the title of the messagebox
     */
    
    public static void showError(JComponent parent, String errorMessage, String title) {
        JOptionPane.showMessageDialog(parent, errorMessage,
                title, JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * Get the default value from preferences
     * @param key the key for default value
     * @param defaultValue the default value to be returned if the key not found
     * @return the default value
     */
    
    public static String loadDefaultValue(String key, String defaultValue) {
        return prefs.get(key, defaultValue);
    }
    
    /**
     * Store the default value to the preferences
     * @param key the key for  value
     * @param defaultValue the default value to be stored against the given key
     * @return the default value
     */
    
    public static void storeDefaultValue(String key, String defaultValue) {
        prefs.put(key, defaultValue);
    }
    
    /**
     * Setup the text component
     * This function sets the name property of the text component so that it can be stored 
     * in wizard parameters. Also it sets the default value of the component
     * @param field the text field component
     * @param name the name of the field used to get the parameter against this field
     * @param defaultValue the default value of the field if no preferences for this name found
     */
    
    public static void setUpTextComponent(JTextField field, String name, String defaultValue) {
        field.setName(name);
        field.setText(loadDefaultValue(name, defaultValue));
    }
    
    /**
     * Get the preferences
     * This function returns the preferences that contain default values of the parameters entered
     * during the wizard
     * @return Preferences object
     */
    
    public static Preferences getPreferences() {
        return prefs;
    }
    
    /**
     * Add all parameters available in HashMap
     * @param map Map containing set of parameters
     */
    
    public static void addAllParams(Map map) {
        params.putAll(map);
    }
    
    /**
     * Add a parameter
     * @param key the key of parameter
     * @param obj the value of key
     */
    
    public static void addParameter(String key, Object obj) {
        params.put(key, obj);
    }
    
    /**
     * Get parameter value for the given key
     * @param key the key
     * @return value for the given key
     */
    
    public static Object getParameter(String key) {
        return params.get(key);
    }
    
    /**
     * Get background image for right panel
     */
    
    public static BufferedImage getRightPanelImage() {
        if(rightBgImg == null)
            
            try {
                rightBgImg = ImageIO.read (ClassLoader.getSystemResource("com/enterprisedb/migration/images/right-panel.png"));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        return rightBgImg;
    }
    
    /**
     * Escape mysql string
     * This function is used to escape mysql string while getting schema or table list
     *
     * @param src the source string
     * @return the escaped string
     */
    
    public static String escapeMysqlString(String src) {
        if(src == null || src.length() == 0)
            return src;
        
        StringBuffer buf = new StringBuffer();
        char[] chars = src.toCharArray();
        for(int i=0; i< chars.length; i++) {
            switch(chars[i]) {
                case '_':
                case '%':
                case '\'':
                case '"':
                case '\\':
                    buf.append('\\');
            }
            buf.append(chars[i]);
        }
        return buf.toString();
    }
    
    /** Construct the prefereces object so that we can preserve and load the previous session's values */
    private static Preferences prefs = Preferences.userNodeForPackage(WizardUtils.class);
    
    /** HashMap to hold parameters gathered during wizard */
    private static HashMap params = new HashMap();
    
    /** Background image for right panels **/
    private static BufferedImage rightBgImg = null;
}
