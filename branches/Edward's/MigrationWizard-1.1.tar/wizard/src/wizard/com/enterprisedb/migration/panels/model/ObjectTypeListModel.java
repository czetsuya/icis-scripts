/*
 * ObjectTypeListModel.java
 *
 * Created on August 6, 2007, 10:29 AM
 *
 * This is a ListModel to be used as Model in lists (Schema selection lists and table selection lists)
 */

package com.enterprisedb.migration.panels.model;

import java.util.Vector;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;

/**
 *
 * @author altaf
 */
public class ObjectTypeListModel extends AbstractListModel implements ComboBoxModel{
    
    /** Creates a new instance of ObjectTypeListModel */
    public ObjectTypeListModel() {
    }
    
    /**
     * Returns the length of the list.
     * @return the length of the list
     */

    public int getSize() {
        return data.size();
    }
    
    /**
     * Returns the value at the specified index
     * @param index the requested index 
     * @return the value at index
     */

    public Object getElementAt(int index) {
        return data.elementAt(index);
    }
    
    /**
     * Add an item to the list
     * @param item the item to add in the list
     */
    
    public void addItem(Object item) {
        data.addElement(item);
    }
    
    /**
     * Remove an item at specified index from the list
     * @param index the index of item to be removed
     * @return the removed object
     */
    
    public Object remove(int index) {
        return data.remove(index);
    }
    
    /**
     * Remove all items from the list
     */
    
    public void clear() {
        data.clear();
    }
    
    /**
     * Set the selected item
     * @param anItem - the list object to select or null to clear the selection
     */

    public void setSelectedItem(Object anItem) {
        selectedItem = anItem;
    }
    
    /**
     * Returns the selected item
     * @return The selected item or null if there is no selection
     */

    public Object getSelectedItem() {
        return selectedItem;
    }
    
    //Variable declaration section
    private Vector data = new Vector(); //Vector to hold the data
    private Object selectedItem = null; //holds the selected item in case of ComboBox
}
