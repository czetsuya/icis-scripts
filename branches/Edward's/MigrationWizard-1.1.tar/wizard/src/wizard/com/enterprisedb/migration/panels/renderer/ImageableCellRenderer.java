/*
 * ImageableCellRenderer.java
 *
 * Created on August 6, 2007, 10:24 AM
 *
 * This class renders the image inside a JList cell
 */

package com.enterprisedb.migration.panels.renderer;

import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 *
 * @author altaf
 */
public class ImageableCellRenderer extends JLabel implements ListCellRenderer {
    
     ImageIcon icon = null;  //the icon to render
     
     /**
      * Create a new instance of ImageableCellRenderer
      * @param imageName the name of image file inside com/enterprisedb/migration/images
      */
     
     public ImageableCellRenderer(String imageName) {
         icon = getIcon("com/enterprisedb/migration/images/"+imageName);    //construct the icon object
     }
     // This is the only method defined by ListCellRenderer.
     // We just reconfigure the JLabel each time we're called.

     public Component getListCellRendererComponent(
       JList list,
       Object value,            // value to display
       int index,               // cell index
       boolean isSelected,      // is the cell selected
       boolean cellHasFocus)    // the list and the cell have the focus
     {
         String s = value.toString();
         setText(s);    // set display text      
         setIcon(icon); // set the con
   	   if (isSelected) {    //if item is selected
             setBackground(list.getSelectionBackground());  // set the selection background
	       setForeground(list.getSelectionForeground());    // and the selected foreground
	   }
         else { 
	       setBackground(list.getBackground()); // set normal background
	       setForeground(list.getForeground()); // and normal foreground
	   }
	   setEnabled(list.isEnabled());    // if list is enabled, enable this item too, otherwise disable it
	   setFont(list.getFont());     // and set font as the font of list
         setOpaque(true);   //set it to Opaque
         return this;   
     }
     
     /**
      * Get the imageIcon from classpath
      * @param path the path of the file
      * @return ImageIcon object
      */
     
     private static ImageIcon getIcon(String path) {
         return new ImageIcon(ClassLoader.getSystemResource(path));//load icon from class path and return
     }
 }