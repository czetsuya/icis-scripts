/*
 * ObjectSelectionPanel.java
 *
 * Created on August 17, 2007, 8:17 AM
 */

package com.enterprisedb.migration.panels;

import com.enterprisedb.migration.panels.model.DBObject;
import com.enterprisedb.migration.panels.model.ObjectTypeListModel;
import com.enterprisedb.migration.panels.renderer.ImageableCellRenderer;
import com.enterprisedb.migration.util.WizardUtils;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.awt.Color;
import javax.swing.ComboBoxModel;
import javax.swing.ListModel;
import org.netbeans.spi.wizard.Wizard;
import org.netbeans.spi.wizard.WizardPage;
import org.netbeans.spi.wizard.WizardPanelNavResult;

/**
 *
 * @author  altaf
 */
public class ObjectSelectionPanel extends WizardPage {
    
    /** Creates new form ObjectSelectionPanel */
    public ObjectSelectionPanel() {
        super("Step4", ObjectSelectionPanel.DESCRIPTION);   
        initComponents();
        listPanel.targetList.setCellRenderer(new ImageableCellRenderer("table.png"));
        listPanel.sourceList.setCellRenderer(new ImageableCellRenderer("table.png"));
        setBackground(Color.WHITE);
    }
    
    /**
     * Get description of the step
     * This method is required by wizard framework to get the description of each step
     * @return description of the step
     */
    
    public static String getDescription() {
        return DESCRIPTION;
    }
    
    /**
     * Get all tables from catalog using connection con
     * @param con Connection to the database
     * @param catalog the catalog that holds the tables
     * @param ResultSet containing tables
     */
  
    private ResultSet getTables(Connection con, String catalog) throws SQLException {
        return con.getMetaData().getTables( catalog,"%",WizardUtils.escapeMysqlString(filter.getText())+"%",new String[]{"TABLE"});
    }
    
    /**
     * This function is called by wizard framework when rendering the page
     * We have overridden this method because we want to refresh the schema list 
     * every time user presses previous and then next button
     */
    
    protected void renderingPage() {
        ObjectTypeListModel model = (ObjectTypeListModel) schema.getModel();
        model.clear();  // clear the items in schema combo
        String[] schemas = getSchemas();    // get all schemas
        for(int i=0; i<schemas.length; i++) {   
            model.addItem(schemas[i]);  //load them into the schema combo
        }
        model.setSelectedItem(schemas[0]);  // set first item as selected
        schema.updateUI();  // update the UI
        //update the source list too
        updateData();        
        
        // Check if any of the schemas of selected list removed, update the selected items list
        if (updatetargetList()) {
            listPanel.targetList.updateUI();
        }
    }
    
    /**
     * Update the target list
     * This function removes items from selected objects list if there are some objects
     * whose schema is not available in current selection. This is possible if user selected 
     * some objects, them pressed previous and removed a schema and then pressed next. Now 
     * some of the selected objects are invalid. Just remove them
     *
     * @return true if the this function has modified the list and it needs GUI updation
     *  false otherwise
     */    
    
     private boolean updatetargetList() {
        String currentSchemas[] = getSchemas();
        Arrays.sort(currentSchemas);    // sort the list so that we can search from it using binary search
        ObjectTypeListModel model = (ObjectTypeListModel) listPanel.targetList.getModel();
        boolean update = false;
        for(int i=0; i < model.getSize(); i++) {
            if(Arrays.binarySearch(currentSchemas, ((DBObject)model.getElementAt(i)).getSchema()) < 0){
                //schema of the object not found in schemas array -> Object is invalid. Remove it
                model.remove(i);
                i--;    //After removing this object, all next objects changed their positions
                update = true;  // the list needs GUI updation
            }
        }
        return update;
    }
    /**
     * Get schemas selected on SchemaSelectionPanel1 page
     * 
     * @return String[] in presentable form
     */
    
    private String[] getSchemas() {         
        ArrayList ar = (ArrayList) SchemaSelectionPanel.getSelectedSchemas().clone();
        ar.add(0, "All Selected");  // add "All Selected" as first item
        return (String[]) ar.toArray(new String[0]);        
    }
    
    /**
     * Update the data in source list
     * This function is called whenever filter is changed so that the filter 
     * results can be loaded into the source list
     */
    private void updateData() {
        String type = (String) objType.getSelectedItem();
        if(type.equalsIgnoreCase("table(s)")) { 
            //The Object type is "Table" (Only tables are allowed to be migrated in MySQL)
            ObjectTypeListModel model = (ObjectTypeListModel) listPanel.sourceList.getModel();
            model.clear();  // clear the source list
            try {
                if(schema.getSelectedIndex() == 0) {    //if "All Selected" item is selected
                    ComboBoxModel schemaModel = schema.getModel();
                    for(int i=1; i < schemaModel.getSize(); i++) {      // Iterate throu the list of schemas and get tables of each item
                        ResultSet rs = getTables(SourceDatabasePanel.getConnection(), schemaModel.getElementAt(i).toString());
                        while(rs.next()) {   
                            DBObject obj = new DBObject(rs.getString("TABLE_NAME"), "Table", schemaModel.getElementAt(i).toString());
                            if(!WizardUtils.inTarget(obj, (ObjectTypeListModel) listPanel.targetList.getModel()))
                                model.addItem(obj); // If item is not in target list, add it to source list
                        }
                    }
                } else {    // Get tables of the selected schema
                    ResultSet rs = getTables(SourceDatabasePanel.getConnection(), schema.getSelectedItem().toString());                
                    while(rs.next()) {   
                        DBObject obj = new DBObject(rs.getString("TABLE_NAME"), "Table", schema.getSelectedItem().toString());
                        if(!WizardUtils.inTarget(obj,(ObjectTypeListModel) listPanel.targetList.getModel()))
                            model.addItem(obj); // If item is not in target list, add it to source list
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        
        listPanel.sourceList.updateUI();  // finally update the UI
        //update buttons
        listPanel.updateButtons();        
    }
    
    /**
     * This function is called when the user has pressed 'Next' button
     * We will get the selected items and add them to selectedItems array so that 
     * when next panels call getSelectedObjects() method of this panel, they get  valid 
     * list of objects
     *
     * @param stepName the name of the step
     * @param settings the parameter map gathered on this screen
     * @return status to indicate that we should remain on same page or proceed further
     */
    
    public WizardPanelNavResult allowNext(String stepName, Map settings,
            Wizard wizard) {
        // is DATA_ONLY option selected?
        boolean dataOnly = Boolean.TRUE.equals(WizardUtils.getParameter(OptionsPanel.MIGRATION_DATA_ONLY));
        
        //build an array of data and add it as parameter        
        ListModel lm = listPanel.targetList.getModel();        
        if(lm.getSize() == 0) {
            WizardUtils.showError(this, "No object selected for migration", "Error");
            return WizardPanelNavResult.REMAIN_ON_PAGE;
        }
        selectedObjects = new ArrayList<String>(lm.getSize());
        for(int i=0; i< lm.getSize(); i++){
            if(dataOnly) {
                if(!tableExistsInTarget((DBObject) lm.getElementAt(i))) {
                    selectedObjects.clear();
                    WizardUtils.showError(this, "Object \"" + lm.getElementAt(i).toString()+"\" does not exist in target database\n" +
                            "Hint: All selected objects should exist in target database for data only migration", "Error");
                    return WizardPanelNavResult.REMAIN_ON_PAGE;
                }
            }
            selectedObjects.add(lm.getElementAt(i).toString());
        }
        return super.allowNext(stepName, settings, wizard);
    }
    
    /**
     * check if the desired table is in target database?
     * valid only for data_only option
     *
     * @param table the DBObject rpresenting the table
     *
     * @return true if table exists in targe database.
     *  false otherwise
     */
    
    private boolean tableExistsInTarget(DBObject table) {
        Connection con = DestinationDatabasePanel.getConnection();
        ResultSet rs;
        try {
            String query = "select c.relname, s.nspname from pg_catalog.pg_class c, pg_catalog.pg_namespace s " +
                    "where c.relname='"+table.getObjName()+"' and s.nspname='"+table.getSchema()+"' and s.oid=c.relnamespace";
            //rs = con.getMetaData().getTables(con.getCatalog(), table.getSchema(), table.getObjName(), new String[] {"TABLE"});
            rs = con.createStatement().executeQuery(query);
            if(rs.next()) {
                rs.close();
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Get selected objects
     * This method is called by MigrationPanel to get the list of objects selected by user
     * @return ArrayList containing object names
     */
    
    public static ArrayList getSelectedObjects() {
        return selectedObjects;
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        javax.swing.JLabel filterLabel;
        javax.swing.JLabel objTypeLabel;
        javax.swing.JButton refresh;
        javax.swing.JLabel schemaLabel;
        javax.swing.JPanel topPanel;

        topPanel = new javax.swing.JPanel();
        schema = new javax.swing.JComboBox();
        objType = new javax.swing.JComboBox();
        objTypeLabel = new javax.swing.JLabel();
        schemaLabel = new javax.swing.JLabel();
        filterLabel = new javax.swing.JLabel();
        filter = new javax.swing.JTextField();
        refresh = new javax.swing.JButton();
        listPanel = new com.enterprisedb.migration.panels.ListSelectionPanel();

        setLayout(new java.awt.BorderLayout());

        schema.setModel(new ObjectTypeListModel());
        schema.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                schemaActionPerformed(evt);
            }
        });

        objType.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Table(s)" }));
        objType.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                objTypeItemStateChanged(evt);
            }
        });

        objTypeLabel.setText("Object Type");

        schemaLabel.setText("Schema");

        filterLabel.setText("Filter");

        filter.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                filterKeyReleased(evt);
            }
        });

        refresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/enterprisedb/migration/images/refresh.png")));
        refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout topPanelLayout = new org.jdesktop.layout.GroupLayout(topPanel);
        topPanel.setLayout(topPanelLayout);
        topPanelLayout.setHorizontalGroup(
            topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(topPanelLayout.createSequentialGroup()
                .add(topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(objTypeLabel)
                    .add(objType, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 106, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(15, 15, 15)
                .add(topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(schema, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 110, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(schemaLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(14, 14, 14)
                .add(topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(topPanelLayout.createSequentialGroup()
                        .add(filter, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 191, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(refresh, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(filterLabel))
                .addContainerGap(99, Short.MAX_VALUE))
        );
        topPanelLayout.setVerticalGroup(
            topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(topPanelLayout.createSequentialGroup()
                .add(topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(objTypeLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 12, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(schemaLabel)
                    .add(filterLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(topPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(objType, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(schema, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(filter, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(refresh, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        topPanelLayout.linkSize(new java.awt.Component[] {filter, objType, refresh, schema}, org.jdesktop.layout.GroupLayout.VERTICAL);

        topPanelLayout.linkSize(new java.awt.Component[] {filterLabel, objTypeLabel, schemaLabel}, org.jdesktop.layout.GroupLayout.VERTICAL);

        add(topPanel, java.awt.BorderLayout.NORTH);

        add(listPanel, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        updateData();
    }//GEN-LAST:event_refreshActionPerformed

    private void filterKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filterKeyReleased
        updateData();
    }//GEN-LAST:event_filterKeyReleased

    private void objTypeItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_objTypeItemStateChanged
        updateData();
    }//GEN-LAST:event_objTypeItemStateChanged

    private void schemaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_schemaActionPerformed
        updateData();
    }//GEN-LAST:event_schemaActionPerformed
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField filter;
    private com.enterprisedb.migration.panels.ListSelectionPanel listPanel;
    private javax.swing.JComboBox objType;
    private javax.swing.JComboBox schema;
    // End of variables declaration//GEN-END:variables
    
    private static String DESCRIPTION = "Schema Objects";    
    private static ArrayList<String> selectedObjects = new ArrayList<String>();
}
