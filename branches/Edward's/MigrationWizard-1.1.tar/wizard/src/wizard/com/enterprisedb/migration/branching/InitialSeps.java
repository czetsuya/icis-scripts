/*
 * InitialSeps.java
 *
 * Created on August 21, 2007, 3:15 PM
 * 
 */

package com.enterprisedb.migration.branching;

import com.enterprisedb.migration.panels.DestinationDatabasePanel;
import com.enterprisedb.migration.panels.FinishPanel;
import com.enterprisedb.migration.panels.OptionsPanel;
import com.enterprisedb.migration.panels.SourceDatabasePanel;
import java.util.Map;
import javax.swing.JComponent;
import org.netbeans.spi.wizard.WizardController;
import org.netbeans.spi.wizard.WizardPanelProvider;

/**
 *
 * @author altaf
 */
public class InitialSeps extends WizardPanelProvider {
    
    /** Creates a new instance of InitialSeps */
    public InitialSeps() {
        super(new String[]{"sourceConnection","destinationConnection","options"} , 
                new String[]{SourceDatabasePanel.getDescription(),
                DestinationDatabasePanel.getDescription(),
                OptionsPanel.getDescription()});
    }

    protected JComponent createPanel(WizardController wizardController, String id, Map map) {
        switch ( indexOfStep( id ) ) {
            case 0:
                return new SourceDatabasePanel();
            case 1:
                return new DestinationDatabasePanel();
            case 2:
                return new OptionsPanel();
            default: 
                throw new IllegalArgumentException ( id );
        }
    }
    
}
