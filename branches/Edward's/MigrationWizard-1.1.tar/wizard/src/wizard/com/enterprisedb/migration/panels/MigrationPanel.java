/*
 * MigrationPanel.java
 *
 * Created on August 10, 2007, 10:53 AM
 */

package com.enterprisedb.migration.panels;

import com.enterprisedb.migration.WizardLauncher;
import com.enterprisedb.migration.util.WizardUtils;
import com.enterprisedb.mtk.ConnectionProps;
import com.enterprisedb.mtk.MigrationProps;
import com.enterprisedb.mtk.MigrationToolkit;
import java.awt.Container;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.SwingUtilities;
import org.netbeans.spi.wizard.Wizard;
import org.netbeans.spi.wizard.WizardController;
import org.netbeans.spi.wizard.WizardPage;

/**
 *
 * @author  altaf
 */
public class MigrationPanel extends WizardPage
{
    
    /** Creates new form MigrationPanel */
    public MigrationPanel() {
        
        initComponents();
        initializeNavigationalButtons();        
        setBackground(Color.WHITE);
    }
    
    /**
     * Get description of the step
     * This method is required by wizard framework to get the description of each step
     * @return description of the step
     */
    
    public static String getDescription() {
        return DESCRIPTION;
    }
    
    /**
     * Start migration process
     * @param sourceProps Credentials of the source database connection
     * @param targetProps Credentials of the target database connection
     * @param dropSchema flag to indicate that the schema should be re-created?
     * @param schemas array of schemas
     * @param objects array of objects to be migrated
     */
    
    //private void startMigration(final ConnectionProps sourceProps, final ConnectionProps targetProps,
            //final boolean dropSchema, final String[] schemas, final String[] objects, final String defaultDate, MigrationProps.MigrationType migrationType, boolean migrateConstraints) {        
    private void startMigration(MigrationProps props) {
        try{   
            final MigrationToolkit mtk = new MigrationToolkit(props);
            mtk.attachOutputComponent(logPane);
            
            try {   
                disableButtions();
                SwingUtilities.invokeLater(new Runnable(){
                    public void run(){
                        progressBar.setIndeterminate(true);
                    }
                } );                
                
                mtk.startMigration();                
                enableButtions();
                progressBar.setIndeterminate(false);
                progressBar.setValue(100);
            } catch (Exception ex) {
                logPane.append(ex.getMessage());
            }
        }catch(Exception exp) {
            logPane.append(exp.getMessage());
        }
        
    }
    
    public void enableButtions() {
        String keys[] = WizardLauncher.getNavButtons().keySet().toArray(new String[0]);
        for(int i=0; i< keys.length; i++) {
            JButton btn = duplicateBtn[i];
            Container cont = btn.getParent();
            cont.remove(btn);
            cont.add(WizardLauncher.getNavButtons().get(keys[i]));
            cont.repaint();
        }
    }
    public void disableButtions() {        
        String keys[] = WizardLauncher.getNavButtons().keySet().toArray(new String[0]);
        for(int i=0; i< keys.length; i++) {
            JButton btn = WizardLauncher.getNavButtons().get(keys[i]);
            Container cont = btn.getParent();
            cont.remove(btn);            
            cont.add(duplicateBtn[i]);            
            cont.repaint();
        } 
    }
    
    private void initializeNavigationalButtons() {
        String keys[] = WizardLauncher.getNavButtons().keySet().toArray(new String[0]);
        for(int i=0; i< keys.length; i++) {
            JButton btn = WizardLauncher.getNavButtons().get(keys[i]);            
            duplicateBtn[i].setBounds(btn.getBounds());
            duplicateBtn[i].setText(btn.getText());
            duplicateBtn[i].setEnabled(false);
        }
    }
    
    /**
     * This function is called by wizard framework when rendering the page
     * We have overridden this method because we want to start migration
     * every time user presses previous and then next button
     */
    protected void renderingPage() {
        logPane.setText("");
        // build source props
        final ConnectionProps srcProps = new ConnectionProps(
                "jdbc:mysql://" + (String)WizardUtils.getParameter(SourceDatabasePanel.HOST) +
                ":" + (String)WizardUtils.getParameter(SourceDatabasePanel.PORT) +"/" + 
                (String)WizardUtils.getParameter(SourceDatabasePanel.DATABASE),
                (String)WizardUtils.getParameter(SourceDatabasePanel.USER),
                (String)WizardUtils.getParameter(SourceDatabasePanel.PASSWORD));
        
        // build target props
        final ConnectionProps destProps = new ConnectionProps(
                "jdbc:edb://" + (String)WizardUtils.getParameter(DestinationDatabasePanel.HOST) +
                ":" + (String)WizardUtils.getParameter(DestinationDatabasePanel.PORT) +"/" + 
                (String)WizardUtils.getParameter(DestinationDatabasePanel.DATABASE),
                (String)WizardUtils.getParameter(DestinationDatabasePanel.USER),
                (String)WizardUtils.getParameter(DestinationDatabasePanel.PASSWORD));
        
        // get all selected schemas        
        final String[] schemas = (String[]) SchemaSelectionPanel.getSelectedSchemas().toArray(new String[0]);
        // get all selected objects
        final String[] objects = (String[]) ObjectSelectionPanel.getSelectedObjects().toArray(new String[0]);
        
        String defaultDate = null;        
        if(Boolean.TRUE.equals(WizardUtils.getParameter(OptionsPanel.USE_DEFAULT_DATE)))
            defaultDate = (String)WizardUtils.getParameter(OptionsPanel.DEFAULT_DATE);
        
        MigrationProps.MigrationType migrationType = MigrationProps.MigrationType.FULL_MIGRATION;
        if(Boolean.TRUE.equals(WizardUtils.getParameter(OptionsPanel.MIGRATION_DATA_ONLY)))
            migrationType = MigrationProps.MigrationType.DATA_ONLY;
        if(Boolean.TRUE.equals(WizardUtils.getParameter(OptionsPanel.MIGRATION_SCHEMA_ONLY)))
            migrationType = MigrationProps.MigrationType.SCHEMA_ONLY;
        
        boolean migrateConstraints = true;
        if(Boolean.FALSE.equals(WizardUtils.getParameter(OptionsPanel.MIGRATE_CONSTRAINTS)))
                migrateConstraints = false;
        //final MigrationProps props = new MigrationProps(srcProps, destProps, schemas, objects, defaultDate, migrationType, migrateConstraints, Boolean.TRUE.equals(WizardUtils.getParameter(OptionsPanel.DROP_SCHEMA)), '\t');
        final MigrationProps props = new MigrationProps(srcProps, destProps, schemas, objects, defaultDate, migrationType, migrateConstraints, Boolean.TRUE.equals(WizardUtils.getParameter(OptionsPanel.DROP_SCHEMA)));
        final String defDate = defaultDate;
        // start migration
        Thread t = new Thread(
                new Runnable(){            
                    public void run() {
                        //startMigration(srcProps, destProps, Boolean.TRUE.equals(WizardUtils.getParameter(OptionsPanel.DROP_SCHEMA)), schemas, objects, defDate, migrationType, migrateConstraints);
                        startMigration(props);
                    }
                }
                );
        t.start();        
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        progressBar = new javax.swing.JProgressBar();
        logScroller = new javax.swing.JScrollPane();
        logPane = new javax.swing.JTextArea();

        setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5));
        progressBar.setMaximumSize(new java.awt.Dimension(10, 26));
        progressBar.setMinimumSize(new java.awt.Dimension(10, 26));
        progressBar.setPreferredSize(new java.awt.Dimension(10, 26));

        logPane.setColumns(20);
        logPane.setEditable(false);
        logPane.setRows(5);
        logPane.setWrapStyleWord(true);
        logScroller.setViewportView(logPane);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(progressBar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 155, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
            .add(logScroller, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(logScroller, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(progressBar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea logPane;
    private javax.swing.JScrollPane logScroller;
    private javax.swing.JProgressBar progressBar;
    // End of variables declaration//GEN-END:variables
    
    private static String DESCRIPTION = "Migrate";
    //Duplicate buttons to be replaced to show a disabled view
    private JButton[] duplicateBtn = new JButton[]{
        new JButton(),
        new JButton(),
        new JButton(),
        new JButton()
    };
}
