/*
 * DBObject.java
 *
 * Created on August 6, 2007, 10:48 AM
 *
 * DBObject represents a database object e.g. table, procedure, view etc
 */

package com.enterprisedb.migration.panels.model;

/**
 *
 * @author altaf
 */
public class DBObject {
    
    /** 
     * Creates a new instance of DBObject 
     * @param objectName the name of the object
     * @param objectType type of object
     * @param objectSchema the schema that holds the object
     */
    public DBObject(String objectName, String objectType, String objectSchema) {
        objName = objectName;
        objType = objectType;
        objSchema = objectSchema;
    }
    
    /**
     * Get object name
     * @return Name of object
     */
    public String getObjName() {
        return objName;
    }
    
    /**
     * Get object type
     * @return Object type
     */

    public String getObjType() {
        return objType;
    }
    
    /**
     * Get schema
     * @return schema which holds the object
     */
    
    public String getSchema() {
        return objSchema;
    }
    
    /**
     * Get string representation of the object
     * @return String representation (fully qualified object name)
     */
    
    public String toString() {
        if((objSchema.length()>1))
            return objSchema+"."+objName;
        return objName;
    }
    
    /**
     * Compare two objects
     * @param the target object
     * @return true if the target obect points to the same underlying object
     * false otherwise
     */
    
    public boolean equals(Object object) {        
        if(object instanceof DBObject) {
            DBObject obj = (DBObject)object;
            if(objName.equals(obj.getObjName()) && objType.equals(obj.getObjType()) && objSchema.equals(obj.getSchema()))
                return true;
        }
        return false;
    }
    
    //Variable declaration section
    private String objName = null;
    private String objType = null;
    private String objSchema = null;
}
