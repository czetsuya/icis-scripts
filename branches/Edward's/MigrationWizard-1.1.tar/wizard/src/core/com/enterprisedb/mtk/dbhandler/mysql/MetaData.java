/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/**
 * MetaData.java
 *
 * Created on January 11, 2007, 3:47 PM
 *
 * @author Shahid Faiz
 * @version #VERSION#
 */
package com.enterprisedb.mtk.dbhandler.mysql;

import java.sql.*;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.ArrayList;

import com.enterprisedb.mtk.Utility;
import com.enterprisedb.mtk.common.IMTKConnection;
import com.enterprisedb.mtk.common.MTKConstants;
import com.enterprisedb.mtk.common.MTKMetaData;
import com.enterprisedb.mtk.schema.metadata.Column;
import com.enterprisedb.mtk.schema.metadata.Constraint;
import com.enterprisedb.mtk.schema.metadata.ConstraintList;
import com.enterprisedb.mtk.schema.metadata.Index;
import com.enterprisedb.mtk.schema.metadata.IndexList;
import com.enterprisedb.mtk.schema.metadata.Table;
import com.enterprisedb.mtk.schema.metadata.View;

public class MetaData extends MTKMetaData {
    private IMTKConnection conn = null;
    private DatabaseMetaData metaData = null;

    private String commaSepViewNames = null;
    private String commaSepTableNames = null;

    /**
     * Creates a new instance of MetaData
     */
    public MetaData(IMTKConnection conn) throws Exception {
        super();
        this.conn = conn;
        this.dbConn = conn.getConnection();
        this.metaData = dbConn.getMetaData();
    }

    /**
     * Creates a new instance of MetaData
     */
    public MetaData(IMTKConnection conn, String targetSchemaName) throws Exception {
        super();
        this.conn = conn;
        this.dbConn = conn.getConnection();

        // check if targetSchemaName is case-sensitive, enclose in double quotes
        this.targetSchemaName = targetSchemaName;
        this.metaData = dbConn.getMetaData();
    }

    /**
     * Encloses the string value in MySQL recognized escape character (`).
     * @param name String
     * @return String
     */
    public String escape(String name) {
        return "`"+name+"`";
    }

    /**
     * Escapes wild characters in the specified objectName if any using provided
     * escapeString.
     *
     * @param var String
     * @param escapeString String
     * @return String
     */
    public String escapeWildCharacters(String objectName, String escapeString) {
        StringBuilder strBuilder = new StringBuilder();
        char ch;
        for (int i = 0; i < objectName.length(); i++) {
            ch = objectName.charAt(i);
            if (ch == '_' || ch == '%') {
                strBuilder.append(escapeString + ch);
            } else {
                strBuilder.append(ch);
            }
        }
        return strBuilder.toString();
    }

    /**
     * Returns true if MySQL version is 5.0 or greater.
     * @return boolean
     * @throws SQLException
     */
    public boolean isVersion5OrGreater() throws SQLException {
        return metaData.getDatabaseMajorVersion() >= 5;
    }

    /**
     * Method used to initialize the statement to get tables in selected database.
     * @param commaSepTableNames String
     * @throws SQLException
     */
    protected void initTableStatement(String commaSepTableNames) throws SQLException {
        // Not preparing any SQL for tables, because we will get list using
        // DatabaseMetaData methods
        this.commaSepTableNames = removeSingleQuotes(commaSepTableNames);
    }

    /**
     * Gets specified or all tables information from database, and adds them
     * to the schema object. This method is called by MTK frame,
     * <code>getTables()</code> actually does all the trick.
     *
     * @param commaSepTableNames String
     * @param importViewAsTable boolean
     * @throws SQLException
     */
    public void getTables(String commaSepTableNames, boolean importViewAsTable)
            throws SQLException {

        super.getTables(removeSingleQuotes(commaSepTableNames), importViewAsTable);

        // import VIEWS as Tables, this is a requirement for Redwood Replicator.
        // any views that are part of comma-separated list will be imported as
        // EnterpriseDB tables. This will not affect existing functionality as if
        // list doesn't contain a VIEW, the following code will do nothing.
        if (importViewAsTable) {
            initViewStatement(commaSepTableNames);
            getViewsAsTables();
        }
    }

    /**
     * Retrieves tables' information and them to schema object.
     * @throws SQLException
     */
    protected void getTables() throws SQLException {
        // Execute USE schemaName command explicitly, incase default database
        // in the URL is not the one specified to pick objects.
        // In that case view definition returned by MySQL is full qualified
        // by schema name also.
        // AND if this schema doesn't exist user will get a proper message.
        Statement stmt = null;
        try {
            stmt = conn.getConnection().createStatement();
            stmt.executeQuery("USE " + escape(schema.getName()));
        } catch (SQLException exp) {
            throw processException(new SQLException("Following problem occurred while using specified source schema.\n"+exp.getMessage()));
        } finally {
            if (stmt != null)
                stmt.close();
        }

        writeLog("Getting Table Definitions");

        Table table = null;

        if (commaSepTableNames != null && commaSepTableNames.trim().length() > 0) {
            String[] tableNames = commaSepTableNames.split(",");
            for (String name : tableNames) {
                table = getTable(name);
                if (table != null)
                    schema.addTable(table);
            }
        } else {
            ResultSet rs = null;
            try {
                rs = metaData.getTables(escapeWildCharacters(schema.getName(), metaData.getSearchStringEscape()),
                                        "%", "%", new String[] {"TABLE"});
                if (rs != null) {
                    while (rs.next()) {
                        table = getTable(rs.getString(3));
                        if (table != null)
                            schema.addTable(table);
                    }
                }
            } catch (SQLException exp) {
                throw processException(exp);
            } finally {
                if (rs != null)
                    rs.close();
            }
        }
    }

    /**
     * This method reads VIEW meta data information and transforms it as
     * Table object so that it can be migrated and mapped to EnterpriseDB table object.
     */
    private void getViewsAsTables() throws SQLException {
        writeLog("Getting View Definitions");
        if (commaSepViewNames != null && commaSepViewNames.trim().length() > 0) {

            String[] viewNames = commaSepViewNames.split(",");
            ResultSet rs = null;
            try {
                rs = metaData.getTables(escapeWildCharacters(schema.getName(), metaData.getSearchStringEscape()),
                                        "%", "%", new String[] {"VIEW"});
                if (rs != null) {
                    Table table = null;
                    while (rs.next()) {
                        if (Arrays.binarySearch(viewNames, rs.getString(3)) >= 0) {
                            table = getTable(rs.getString(3));
                            if (table != null)
                                schema.addTable(table);
                        }
                    }
                }
            } catch (SQLException exp) {
                throw processException(exp);
            } finally {
                if (rs != null)
                    rs.close();
            }
        }
    }

    /**
     * Initializes the statement to get table columns.
     *
     * NOTE: This method doesn't do any thing for MySQL, because we are getting
     *       all information using DatabaseMetaData class of JDBC.
     * @throws SQLException
     */
    protected void initColumnStatement() throws SQLException {
        // Not preparing any SQL for columns, because we will get list using
        // DatabaseMetaData methods
    }

    /**
     * Retrievs information including columns' details, and returns in the
     * form of Table object.
     *
     * Returns null if specified table is not found in the database.
     * @param tableName String
     * @return Table
     * @throws SQLException
     */
    protected Table getTable(String tableName) throws SQLException {
        ResultSet rs = null;
        Table table = null;

        try {
			//No need to escape schema name for this method

			//We only need to escape patterns not exact values in DatabaseMetaData Class Methods.

            rs = metaData.getColumns(schema.getName() ,"%", escapeWildCharacters(tableName, metaData.getSearchStringEscape()) ,"%");

            while (rs.next()) {
                if (table == null)
                    table = new Table(schema, tableName, targetSchemaName);

                // check column case-sensitivity and enclose in double-quotes accordingly
                String colName = rs.getString(4);

                Column column = new Column(table, colName);
                // 4 = name, 6 = type name, 7=column_size/precision,
                // 9=decimal digits, 12=remarks/comments(null), 13=default(null)
                // 18=nullable
                
                table.addColumn(toEDBType(column, rs.getString(6), rs.getInt(7),
                                          rs.getInt(7), rs.getInt(9),
                                          rs.getString(18), isCaseSensitive(colName),
                                          rs.getString(13), rs.getString(12)));
            }
        } catch (SQLException se) {
            throw processException(se);
        } finally {
            if (rs != null) {
                rs.close();
            }
        }

        return table;
    }

    /**
     * Converts the MySQL sepcific data type to EnterpriseDB data type.
     * @param column Column
     * @param typeName String
     * @param length int
     * @param precision int
     * @param scale int
     * @param nullable String
     * @param caseSensitive boolean
     * @param defaultClause String
     * @param comments String
     * @return Column
     */
    private Column toEDBType(Column column, String typeName, int length,
                             int precision, int scale, String nullable,
                             boolean caseSensitive, String defaultClause,
                             String comments) {
        typeName = typeName.trim();
        if (typeName.equalsIgnoreCase("TINYINT UNSIGNED")
                || typeName.equalsIgnoreCase("TINYINT")) {
            typeName = "SMALLINT";
        } else if (typeName.equalsIgnoreCase("SMALLINT UNSIGNED")
                   || typeName.equalsIgnoreCase("MEDIUMINT")
                   || typeName.equalsIgnoreCase("MEDIUMINT UNSIGNED")) {
            typeName = "INT";
        } else if (typeName.equalsIgnoreCase("INT UNSIGNED")) {
            typeName = "BIGINT";
        } else if (typeName.equalsIgnoreCase("BIT")) {
            typeName = "BOOLEAN";
        } else if (typeName.equalsIgnoreCase("BIGINT UNSIGNED")) {
            typeName = "NUMERIC";
            precision = 20;
            scale = 0;
        } else if (typeName.equalsIgnoreCase("DOUBLE")
                   || typeName.equalsIgnoreCase("DOUBLE UNSIGNED")) {
            typeName = "DOUBLE PRECISION";
        } else if (typeName.equalsIgnoreCase("TINYTEXT")
                   || typeName.equalsIgnoreCase("TEXT")
                   || typeName.equalsIgnoreCase("MEDIUMTEXT")
                   || typeName.equalsIgnoreCase("LONGTEXT")) {
            typeName = "TEXT";
        } else if (typeName.equalsIgnoreCase("TINYBLOB")
        			|| typeName.equalsIgnoreCase("BLOB")
        			|| typeName.equalsIgnoreCase("MEDIUMBLOB")
        			|| typeName.equalsIgnoreCase("LONGBLOB")) {
            typeName = "BYTEA";
        } else if (typeName.equalsIgnoreCase("DATETIME")) {
        	typeName = "TIMESTAMP";
        }
        if (typeName.toUpperCase().indexOf("UNSIGNED") > 0) {
            // Remove unsigned from float/real/double because these are
            // not required to be specially cared
            typeName = typeName.substring(0, typeName.toUpperCase().indexOf("UNSIGNED"));
        }


        column.addDetail(typeName.trim(), length, precision, scale, nullable,
                         caseSensitive, defaultClause, comments);

        return column;
    }

    /**
     * Only initializes commaSepViewNames, SQL is generated inside getViews
     * method, because we can't set values using prepared statement.
     * It is used in getView() method after getting view names using
     * DatabaseMetaData.getTables(...., "VIEW") method.
     *
     * @param commaSepViewNames String
     * @throws SQLException
     */
    protected void initViewStatement(String commaSepViewNames) throws SQLException {
        this.commaSepViewNames = removeSingleQuotes(commaSepViewNames);
    }

    /**
     * Load view information including view source after modification for
     * EnterpriseDB and returns in the form of View object.
     *
     * @param viewName String
     * @return View
     * @throws SQLException
     */
    private View getView(String viewName) throws SQLException {
        View view = null;
        ResultSet rs = null;
        Statement stmt = null;

        try {
            getViewsStr = "SHOW CREATE TABLE "+escape(schema.getName())+"."+escape(viewName);
            stmt = conn.getConnection().createStatement();
            rs = stmt.executeQuery(getViewsStr);

            if (rs != null && rs.next()) {
                view = new View(viewName);
                String viewSource = rs.getString(2);

                // Remove the extra commands prepended in the view definition
                int index = viewSource.toUpperCase().indexOf("AS SELECT");
                if (index >= 0) {
                    viewSource = viewSource.substring(index+2);
                    viewSource = viewSource.replaceAll("`", "\"");
                }

                // remove escape character (that enclose column names) for case-insensitive cols to
                // fix the issue related with a view that is created using "SELECT *" pattern
                Table viewTable = getTable(view.getName());

                if (viewTable != null) {
                    for (int i = 0; i < viewTable.getColumns().size(); i++) {
                        Column viewTableCol = viewTable.getColumns().get(i);
                        if (!viewTableCol.isCaseSensitive() &&
                            Utility.isValidPGIdentifier(viewTableCol.getName())) {

                            viewSource = viewSource.replaceAll("\""+viewTableCol.getName()+"\"", viewTableCol.getName());
                        }
                    }
                }

                view.setSQL(viewSource);
            }
        } catch (SQLException se) {
            throw processException(se);
        } finally {
            if (stmt != null)
                stmt.close();
            if (rs != null) {
                rs.close();
            }
        }
        return view;
    }

    /**
     * Loads all views' information and adds them to schema object.
     *
     * @throws SQLException
     */
    protected void getViews() throws SQLException {
        writeLog("Getting View Definitions");
        View view = null;

        // if view names are already specified, then no need to
        // go to DatabaseMetaData
        if (commaSepViewNames != null && commaSepViewNames.trim().length() > 0) {
            String[] viewNames = commaSepViewNames.split(",");
            for (String name : viewNames) {
                view = getView(name);
                if (view != null) {
                    schema.addView(view);
                }
            }
        } else {
            ResultSet rs = null;
            try {
                rs = metaData.getTables(escapeWildCharacters(schema.getName(), metaData.getSearchStringEscape()),
                                        "%", "%", new String[] {"VIEW"});
                if (rs != null) {
                    while (rs.next()) {
                        view = getView(rs.getString(3));
                        if (view != null)
                            schema.addView(view);
                    }
                }
            } catch (SQLException exp) {
                throw processException(exp);
            } finally {
                if (rs != null)
                    rs.close();
            }
        }
    }

    /**
     * Only initializes the commaSepTableNames variable. Primary keys and
     * foreign keys are retrieved using getPrimaryKey() and getImportedKey()
     * methods whereas Unique key constraints query is initialized before getting
     * the constraints.
     *
     * @param commaSepTableNames String
     * @throws SQLException
     */
    protected void initConstraintStatement(String commaSepTableNames) throws SQLException {
        this.commaSepTableNames = removeSingleQuotes(commaSepTableNames);
    }

    /**
     * Gets all constraints defined on selected tables and adds them to schema
     * object.
     *
     * @throws SQLException
     */
    protected void getConstraints() throws SQLException {
        writeLog("Getting Constraint Definitions");
        if (commaSepTableNames != null && commaSepTableNames.length() > 0) {
            String[] tableNames = commaSepTableNames.split(",");
            for (String name : tableNames) {
                getTableConstraints(name);
            }
        } else {
            ResultSet rs = null;
            try {
				//No need to escape schema name for this method

				//We only need to escape patterns not exact values in DatabaseMetaData Class Methods.

                rs = metaData.getTables(schema.getName(),

                                        "%", "%", new String[] {"TABLE"});
                if (rs != null) {
                    while (rs.next())
                        getTableConstraints(rs.getString(3));
                }
            } catch (SQLException exp) {
                throw processException(exp);
            } finally {
                if (rs != null)
                    rs.close();
            }
        }

        // NOW set constraint name as null, if there are duplicate names because
        // EnterpriseDB doesn't support duplicate constraint names across tables.
        ConstraintList list = schema.getConstraints();
        if (list != null && list.size() > 0) {
            Constraint constraint = null;
            ArrayList<String> cnames = new ArrayList<String>();
            for (int i = 0; i < list.size(); i++) {
                constraint = (Constraint) list.get(i);
                if (!(constraint.getName().equalsIgnoreCase("PRIMARY")
                     || constraint.getName().equalsIgnoreCase("\"PRIMARY\""))
                    && cnames.contains(constraint.getName())) {

                    constraint.setName(null);
                } else {
                    cnames.add(constraint.getName());
                }
            }
        }
    }

    /**
     * Retrieves all constraints (Primary, Foreign, and Unique) against
     * sepcified table.
     *
     * @param tableName String
     * @throws SQLException
     */
    private void getTableConstraints(String tableName) throws SQLException {
        Constraint constraint = null;
        Hashtable<String, Constraint> cache = new Hashtable<String, Constraint>();
        String colName = null;
        Column column = null;
        ResultSet rs = null;

        // Get primary keys
        try {
			//No need to escape schema name for this method

			//We only need to escape patterns not exact values in DatabaseMetaData Class Methods.

            rs = metaData.getPrimaryKeys(schema.getName(),

                                         "%", tableName);
            if (rs != null) {
                // MySQL driver returns 'PRIMARY' as primary key name which is key
                // work and required to be translated.
                String pkOriginalName = null;
                String pkName = null;
                while (rs.next()) {
                    // Transform primary key name
                    pkOriginalName = rs.getString("PK_NAME");
                    pkName = pkOriginalName;
                    if (pkOriginalName == null){
                        pkName = "PRIMARY";
                    }

                    if (!cache.containsKey(pkName)) {
                        constraint = new Constraint(rs.getString("TABLE_NAME"),
                                                    pkName, isCaseSensitive(pkName));
                        constraint.setType(MTKConstants.CONST_PRIMARY);
                        cache.put(pkName, constraint);
                        schema.addConstraint(constraint);
                    } else {
                        constraint = (Constraint) cache.get(pkName);
                    }

                    // Add constraint columns
                    colName = rs.getString("COLUMN_NAME");
                    column = new Column(colName);
                    column.setCaseSensitive(isCaseSensitive(colName));
                    constraint.addColumn(column);
                }
            }
        } catch (SQLException exp) {
            throw processException(exp);
        } finally {
            if (rs != null)
                rs.close();
        }
        cache.clear(); // Clear Primary Key cache

        // Get foreign keys
        try {
			//No need to escape schema name for this method

			//We only need to escape patterns not exact values in DatabaseMetaData Class Methods.

            rs = metaData.getImportedKeys(schema.getName(),

                                          "%", tableName);
            if (rs != null) {
                String keyName = null;
                while (rs.next()) {
                    keyName = rs.getString("FK_NAME");
                    if (keyName == null) {
                        // TODO: If foreign key name is null and is defined against
                        //       more than one column then this will not work.
                        keyName = rs.getString("FKTABLE_NAME")+"_fk"+rs.getShort("KEY_SEQ");
                    }

                    if (!cache.containsKey(keyName)) {
                        constraint = new Constraint(rs.getString("FKTABLE_NAME"),
                                                    keyName, isCaseSensitive(keyName));
                        constraint.setType(MTKConstants.CONST_FOREIGN);
                        constraint.setDeleteRule(MTKConstants.translateDeleteRule(rs.getShort("DELETE_RULE")));

                        cache.put(keyName, constraint);
                        schema.addConstraint(constraint);
                    } else {
                        constraint = (Constraint) cache.get(keyName);
                    }

                    // Add foreign key columns
                    colName = rs.getString("FKCOLUMN_NAME");
                    column = new Column(colName);
                    column.setCaseSensitive(isCaseSensitive(colName));
                    constraint.addColumn(column);

                    // Add referenced columns and table name
                    constraint.setRefIntegrityTable(rs.getString("PKTABLE_NAME"));
                    colName = rs.getString("PKCOLUMN_NAME");
                    column = new Column(colName);
                    column.setCaseSensitive(isCaseSensitive(colName));
                    constraint.addRefIntegrityColumn(column);
                }
            }
        } catch (SQLException exp) {
            throw processException(exp);
        } finally {
            if (rs != null)
                rs.close();
        }
        cache.clear(); // clear cache

        // Get unique keys
        // 1=Table | 2=Non_unique | 3=Key_name | 4=Seq_in_index |
        // 5=Column_name | 6=Collation | 7=Cardinality | 8=Sub_part |
        // 9=Packed | 10=Null | 11=Index_type | 12=Comment
        // Query used to get unique constrainst ONLY
        getConstraintsStr = "SHOW KEYS FROM "+escape(schema.getName())+"."+escape(tableName);
        if (isVersion5OrGreater()) {
            getConstraintsStr +=   " WHERE KEY_NAME != 'PRIMARY' AND NON_UNIQUE=0";
        }
        try {
            rs = conn.getConnection().createStatement().executeQuery(getConstraintsStr);
            if (rs != null) {
                String keyName = null;
                while (rs.next()) {
                    keyName = rs.getString(3);
                    if (!cache.containsKey(keyName)) {
                        constraint = new Constraint(rs.getString(1),
                                                    keyName, isCaseSensitive(keyName));
                        constraint.setType(MTKConstants.CONST_UNIQUE);
                        cache.put(keyName, constraint);
                        schema.addConstraint(constraint);
                    } else {
                        constraint = (Constraint) cache.get(keyName);
                    }

                    // Add constraint columns
                    colName = rs.getString(5);
                    column = new Column(colName);
                    column.setCaseSensitive(isCaseSensitive(colName));
                    constraint.addColumn(column);
                }
            }
        } catch (SQLException exp) {
            throw processException(exp);
        } finally {
            if (rs != null)
                rs.close();
        }
        cache.clear(); // clear the cache
        cache = null;
    }

    /**
     * Used to set the parameters to get constraint columns. In MySQL case, this
     * method is not being used.
     *
     * @param constraint Constraint
     * @throws SQLException
     */
    protected void setConstraintColumnsPSParams(Constraint constraint) throws SQLException {
        // This method is used to initialize parameters to get constraint columns
        // For MySQL, we are getting columns in the same go to get constraints
    }

    /**
     * Only initializes commaSepTableNames variable, query is initialized
     * before getting indexes.
     *
     * @param commaSepTableNames String
     * @throws SQLException
     */
    protected void initIndexeStatement(String commaSepTableNames) throws SQLException {
        this.commaSepTableNames = removeSingleQuotes(commaSepTableNames);
    }

    /**
     * Gets all indexes information from database and adds to schema object.
     *
     * @throws SQLException
     */
    protected void getIndexes() throws SQLException {
        writeLog("Getting Index Definitions");
        if (commaSepTableNames != null
            && commaSepTableNames.trim().length() > 0) {
            String[] tableNames = commaSepTableNames.split(",");
            for (String name : tableNames) {
                getTableIndexes(name);
            }
        } else {
            ResultSet rs = null;
            try {
                rs = metaData.getTables(escapeWildCharacters(schema.getName(), metaData.getSearchStringEscape()),
                                        "%", "%", new String[] {"TABLE"});
                if (rs != null) {
                    while (rs.next()) {
                        getTableIndexes(rs.getString(3));
                    }
                }
            } catch (SQLException exp) {
                throw processException(exp);
            } finally {
                if (rs != null)
                    rs.close();
            }
        }

        // NOW rename index, if there are duplicate names because
        // EnterpriseDB doesn't support duplicate index names across tables.
        IndexList list = schema.getIndexes();
        if (list != null && list.size() > 0) {
            Index index = null;
            String name = null;

            ArrayList<String> indexNames = new ArrayList<String>();
            // Add constraint names to indexNames because duplication is required
            // to be checked accross constraints also
            ConstraintList constraints = schema.getConstraints();
            if (constraints != null && constraints.size() > 0) {
                for (int i = 0; i < constraints.size(); i++) {
                    indexNames.add(constraints.get(i).getName());
                }
            }

            int[] indexCount = new int[list.size()+indexNames.size()];
            for (int i = 0; i < list.size(); i++) {
                index = (Index) list.get(i);
                name = index.getName();
                if (indexNames.contains(name)) {
                    indexCount[indexNames.indexOf(name)] += 1;
                    index.setName(name + indexCount[indexNames.indexOf(name)]);
                } else {
                    indexNames.add(name);
                    indexCount[indexNames.indexOf(name)] = 0;
                }
            }
        }
    }

    /**
     * Get indexes of specified table and puts in schema object.
     *
     * @param tableName String
     * @throws SQLException
     */
    private void getTableIndexes(String tableName) throws SQLException {
        Hashtable<String, Index> cache = new Hashtable<String, Index>();
        Index index = null;
        String colName = null;
        Column column = null;

        // Get indexes information for specified table, skip unique indexes
        // 1=Table | 2=Non_unique | 3=Key_name | 4=Seq_in_index |
        // 5=Column_name | 6=Collation | 7=Cardinality | 8=Sub_part |
        // 9=Packed | 10=Null | 11=Index_type | 12=Comment
        getIndexesStr = "SHOW KEYS FROM "+escape(schema.getName())+"."+escape(tableName);
        if (isVersion5OrGreater()) {
            getIndexesStr +=   "  WHERE KEY_NAME != 'PRIMARY' AND NON_UNIQUE=1";
        }
        ResultSet rs = null;
        try {
            rs = conn.getConnection().createStatement().executeQuery(getIndexesStr);
            if (rs != null) {
                String indexName = null;
                while (rs.next()) {
                    indexName = rs.getString(3);
                    if (!cache.containsKey(indexName)) {

                        // Primary and unique indexes are filtered out becasue
                        // these will be automatically created in the process of
                        // constraint definition.
                        if (indexName.equalsIgnoreCase("PRIMARY")
                            || rs.getString(2).equals("0")
                            || rs.getString(2).equalsIgnoreCase("false")) {
                            continue;
                        }
                        index = new Index(rs.getString(1), indexName);
                        // to flag, that this is not unique
                        index.setUnique(false);
                        cache.put(indexName, index);
                        schema.addIndex(index);
                    } else {
                        index = (Index) cache.get(indexName);
                    }

                    // Add constraint columns
                    colName = rs.getString(5);
                    column = new Column(colName);
                    column.setCaseSensitive(isCaseSensitive(colName));
                    index.addColumn(column);
                }
            }
        } catch (SQLException exp) {
            throw processException(exp);
        } finally {
            if (rs != null)
                rs.close();
        }
        cache.clear(); // clear the cache
        cache = null;
    }

    /*
     * This function checks if an identifier name should be case-sensitive in the
     * EnterpriseDB database.
     * @return A boolean value of true if case-sensitive otherwise false.
     */
    public boolean isCaseSensitive(String identifierName) {
        return Utility.isCaseSensitive(identifierName, MTKConstants.DATABASE_TYPE.MYSQL);
    }

    /**
     * Excutes the provided SQL script using MySQL connection.
     * @param sql String
     * @throws SQLException
     */
    public void executeScript(String sql) throws SQLException {
        Statement stmt = null;

        try {
            if (sql.compareTo("") != 0) {
                out.println(sql);
                stmt = dbConn.createStatement();
                stmt.execute(sql);
            }
        } catch (SQLException se) {
            throw processException(se);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Processes exception to remove STACKTRACE from message.
     *
     * @param exp SQLException
     * @return SQLException
     */
    private SQLException processException(SQLException exp) {
        return Utility.processException(exp);
    }


    /**
     * Following features are not supported for MySQL migration.
     */
    public boolean supportsSynonyms() {
        return false;
    }
    public String getVersion() throws SQLException { return "" ; }
    protected void initPublicSynonymStatement(String commaSepSynNames) throws SQLException { }
    protected void initSequenceStatement(String commaSepSequenceNames) throws SQLException { }
    protected void initProcStatement(String commaSepProcNames) throws SQLException { }
    protected void initPackageStatement(String commaSepPackageNames) throws SQLException { }
    protected void initTriggerStatement(String commaSepTableNames) throws SQLException { }
    protected void getPublicSynonyms() throws SQLException { }
    protected void getTriggers() throws SQLException { }
    protected void getSequences() throws SQLException { }
    protected void getPackages() throws SQLException { }
    protected void getProcedures() throws SQLException { }
    protected void getFunctions() throws SQLException { }
}
