/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * ColumnList.java
 *
 * Created on February 27, 2006, 10:10 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */

import java.util.*;

public class ColumnList {

    private ArrayList<Column> list = null;
    
    /** Creates a new instance of ColumnList */
    public ColumnList() {
    }
    
    public void add(Column column) {
        if (list == null) 
            list = new ArrayList<Column>();
        
        list.add(column);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Column get(int index) {
        return (Column) list.get(index);
    }
    
}
