/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * ProcedureList.java
 *
 * Created on March 7, 2006, 12:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class ProcedureList {
    private ArrayList<Procedure> list = null;
    
    /** Creates a new instance of ProcedureList */
    public ProcedureList() {
    }

    public void add(Procedure proc) {
        if (list == null) 
            list = new ArrayList<Procedure>();
        
        list.add(proc);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Procedure get(int index) {
        return (Procedure) list.get(index);
    }
    
}
