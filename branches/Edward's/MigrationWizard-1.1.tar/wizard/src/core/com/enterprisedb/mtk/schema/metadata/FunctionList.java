/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * FunctionList.java
 *
 * Created on March 8, 2006, 8:22 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class FunctionList {
    private ArrayList<Function> list = null;
    
    /** Creates a new instance of FunctionList */
    public FunctionList() {
    }

    public void add(Function func) {
        if (list == null) 
            list = new ArrayList<Function>();
        
        list.add(func);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Function get(int index) {
        return (Function) list.get(index);
    }
    
}
