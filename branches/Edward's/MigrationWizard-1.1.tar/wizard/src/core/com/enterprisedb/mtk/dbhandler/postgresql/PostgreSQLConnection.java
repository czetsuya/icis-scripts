/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * PostgreSQLConnection.java
 *
 * Created on February 28, 2006, 8:11 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.dbhandler.postgresql;

import com.enterprisedb.mtk.common.MTKConnection;

import java.sql.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author jimm
 */
public class PostgreSQLConnection extends MTKConnection {
    private com.edb.Driver driver = null;

    public PostgreSQLConnection(String dbURL, String dbUser, String dbPassword) throws Exception {
        super(dbURL, dbUser, dbPassword);

        try {
            driver = new com.edb.Driver();

            Properties prop = new Properties();
            prop.setProperty("user", dbUser);
            prop.setProperty("password", dbPassword);
            prop.setProperty("loginTimeout", "10");
            prop.setProperty("detmsgencoding", "");
            conn = driver.connect(dbURL, prop);
        } catch(SQLException se) {
            throw new Exception(se.getMessage(), se);
        } catch(Exception e) {
            throw new Exception(e.getMessage(), e);
        }

    }

    /** Creates a new instance of PostgreSQLConnection */
    public PostgreSQLConnection(String propertiesFile) throws Exception {
        super(propertiesFile);

        try {
            // load the ini file
            Properties ini = new Properties();
            ini.load( new FileInputStream(propertiesFile));

            dbURL = ini.getProperty("EDBConnection");
            dbUser = ini.getProperty("EDBUser");
            dbPassword = ini.getProperty("EDBPassword");
            driver = new com.edb.Driver();

            Properties prop = new Properties();
            prop.setProperty("user", dbUser);
            prop.setProperty("password", dbPassword);
            prop.setProperty("loginTimeout", "10");
            prop.setProperty("detmsgencoding", "");
            conn = driver.connect(dbURL, prop);

        } catch(SQLException se) {
            throw new Exception(se.getMessage(), se);
        } catch(Exception e) {
            throw new Exception(e.getMessage(), e);
        }
    }
}
