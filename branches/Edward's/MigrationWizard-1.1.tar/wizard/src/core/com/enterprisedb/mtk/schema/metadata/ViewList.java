/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * ViewList.java
 *
 * Created on March 7, 2006, 9:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class ViewList {
    private ArrayList<View> list = null;
    
    /** Creates a new instance of ViewList */
    public ViewList() {
    }

    public void add(View view) {
        if (list == null) 
            list = new ArrayList<View>();
        
        list.add(view);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public View get(int index) {
        return (View) list.get(index);
    }
    
}
