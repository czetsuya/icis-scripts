/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * TableList.java
 *
 * Created on February 27, 2006, 9:56 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class TableList {
    private ArrayList<Table> list = null;
    
    /** Creates a new instance of TableList */
    public TableList() {
    }
    
    public void add(Table table) {
        if (list == null) 
            list = new ArrayList<Table>();
        
        list.add(table);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Table get(int index) {
        return (Table) list.get(index);
    }
}
