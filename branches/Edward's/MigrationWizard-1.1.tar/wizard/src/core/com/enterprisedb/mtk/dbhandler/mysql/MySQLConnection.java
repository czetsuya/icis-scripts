/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MySQLConnection.java
 *
 * Created on January 11, 2007, 6:30 PM
 *
 */
package com.enterprisedb.mtk.dbhandler.mysql;

import java.io.FileInputStream;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.enterprisedb.mtk.Utility;
import com.enterprisedb.mtk.common.MTKConnection;

/**
 * @author Aamir Yaseen
 *
 */
public class MySQLConnection extends MTKConnection {

    private static String mysqlDriver = "com.mysql.jdbc.Driver";

    /**
     * Creates a new instance of MySQLConnection
     * @param dbURL
     * @param dbUser
     * @param dbPassword
     * @throws Exception
     */
    public MySQLConnection(String dbURL, String dbUser, String dbPassword) throws
            Exception {
        super(dbURL, dbUser, dbPassword);
        try {
            // Register jdbcDriver
            Class.forName(mysqlDriver);

            // make connection
            conn = DriverManager.getConnection(appendParams(dbURL), dbUser, dbPassword);
        } catch (SQLException se) {
            Exception exp = Utility.processException(se);
            throw new Exception("Following problem occurred while connecting to MySQL server.\n"+exp.getMessage(), exp);
        } catch (Exception e) {
            e = Utility.processException(e);
            throw new Exception("Following problem occurred while connecting to MySQL server.\n"+e.getMessage(), e);
        }
    }

    /**
     * @param PropertiesFile
     * @throws Exception
     */
    public MySQLConnection(String propertiesFile) throws Exception {
        super(propertiesFile);

        try {
            // load the ini file
            Properties ini = new Properties();
            ini.load(new FileInputStream(propertiesFile));

            dbURL = appendParams(ini.getProperty("mysqlConnection"));
            dbUser = ini.getProperty("mysqlUser");
            dbPassword = ini.getProperty("mysqlPassword");

            // Register jdbcDriver
            Class.forName(mysqlDriver);

            // make connection
            conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
        } catch (SQLException se) {
            Exception exp = Utility.processException(se);
            throw new Exception("Following problem occurred while connecting to MySQL server.\n"+exp.getMessage(), exp);
        } catch (Exception e) {
            e = Utility.processException(e);
            throw new Exception("Following problem occurred while connecting to MySQL server.\n"+e.getMessage(), e);
        }
    }

    private String appendParams(String dbURL) {
        if (!dbURL.contains("?")) {
            dbURL += "?";
        } else {
            dbURL += "&";
        }
        dbURL += "yearIsDateType=false&connectTimeout=10000";
        return dbURL;
    }
}
