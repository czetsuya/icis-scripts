/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Table.java
 *
 * Created on February 27, 2006, 9:49 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

import com.enterprisedb.mtk.Utility;
import com.enterprisedb.mtk.common.MTKConstants;

/**
 *
 * @author jimm
 */
public class Table {
    private String tableName = null;
    private ColumnList columns = null;
    private Schema parentSchema = null;
    private String targetSchemaName = null;
    private int maxRowSize = 0;
    private boolean hasLargeObject = false;
    private boolean dataLoadFailure = false;
    private String whereClause = null;
	private boolean creationFailure;

    /** Creates a new instance of Table */
    public Table() {
    }

    public Table(Schema parentSchema, String tableName, String targetSchemaName) {
        this.parentSchema = parentSchema;
        this.tableName = tableName;
        this.targetSchemaName = targetSchemaName;
    }

    public String getName() {
        return tableName;
    }

    /**
     * It returns the table name that is compatible with EnterpriseDB default case.
     * The name is converted to lower case unless it's case sensitive.
     */
    public String getEDBCompatibleName() {
        // zahid: If table name is in upper case and is valid EDB identifier, change
        // from Upper (the default case for Oracle) to lower (for EDB)
        if (Utility.isValidPGIdentifier(tableName) &&
            tableName.toUpperCase().equals(tableName)) {
            return tableName.toLowerCase();
        }

        return tableName;
    }

    public String getFullName() {
        return parentSchema.getName() + "." + tableName;
    }

    /**
     * It returns the schema-qualified table name in case-sensitive pattern enclosed in
     * double quotes if param quoted is true otherwise in normal form.
     */
    public String getFullName(boolean quoted) {
        return parentSchema.getName(quoted) + "." + tableName;
    }

    public String getTargetSchemaQualifiedName() {
        return targetSchemaName + "." + tableName;
    }

    public String getTargetSchemaFullyQualifiedName(MTKConstants.DATABASE_TYPE sourceDBType,
            MTKConstants.DATABASE_TYPE targetDBType, boolean escapeSingleQuote){

        String tempTableName = tableName;
        // for Ora 2 EDB, check if the table is already enclosed in quotes
        // Don't change tableName
        if (!tableName.startsWith("\"")) {
            if (Utility.isCaseSensitive(tempTableName, targetDBType)) {
                tempTableName = "\"" + tempTableName + "\"";
            }
        }

        // Fully qualified name
        String fqn = Utility.isCaseSensitive(targetSchemaName, targetDBType) && !targetSchemaName.startsWith("\"") ? "\"" + targetSchemaName + "\"" : targetSchemaName;
        fqn += "." + tempTableName;

        if(escapeSingleQuote && fqn.contains("'")){
        	fqn = fqn.replace("'", "''");
        }

        return fqn;
    }

    public String getFullName(String schemaName) {
        return schemaName + "." + tableName;
    }

    public ColumnList getColumns() {
        return columns;
    }

    public void addColumn(Column column) {
        if (columns == null)
            columns = new ColumnList();

        columns.add(column);
        // to handle FB5402 where row length is calculated incorrectly,
        // so lets use MAX size limit for Date/Time/Timestamp and NUMERIC types
        //maxRowSize = maxRowSize + column.getLength();
        maxRowSize = maxRowSize + column.getBufferStorageSize();
        // since CLOB data will be loaded and saved via CLOB reference, so
        // set hasLargeObject to true to load such table separatly
        if (column.isLargeObject() ||
            column.isClob() || column.isNClob()) {
            hasLargeObject = true;
        }
    }

    public String getSelectSQL() {
        String sql = "SELECT ";
        String colName = null;

        for (int i=0; i<columns.size(); i++) {
            colName = columns.get(i).getName();
            sql = sql + colName;
            if (i < columns.size()-1)
                sql = sql + ", ";
        }
        sql = sql + " FROM " + parentSchema.getName(true) + "." + tableName;

        // check if the user has set where clause
        if (whereClause != null) {
           sql = sql + " WHERE " + whereClause;
        }
        return sql;
    }

    public String getSelectSQL(MTKConstants.DATABASE_TYPE sourceDatabaseType) {
        String sql = "SELECT ";
        String colName = null;
        Column column = null;
        for (int i=0; i<columns.size(); i++) {
            column = columns.get(i);
            colName = column.getName();
            if (column.isCaseSensitive() && colName.startsWith("\"")
                && colName.endsWith("\"")) {
                colName = colName.substring(1, (colName.length() - 1));
            }
            sql += Utility.escape(colName, sourceDatabaseType);
            if (i < columns.size()-1)
                sql = sql + ", ";
        }
        sql += " FROM " + Utility.escape(parentSchema.getName(), sourceDatabaseType) +
                "." + Utility.escape(tableName, sourceDatabaseType);

        // check if the user has set where clause
        if (whereClause != null) {
           sql = sql + " WHERE " + whereClause;
        }
        return sql;
    }

    public int getMaxRowSize() {
        return maxRowSize;
    }

    public boolean hasLargeObject() {
        return hasLargeObject;
    }

    public boolean hasDataLoadFailure() {
        return dataLoadFailure;
    }

    public void dataLoadFailed() {
        dataLoadFailure = true;
    }

    public boolean isCreationFailure() {
        return creationFailure;
    }

    public void setCreationFailure(boolean creationFailure) {
        this.creationFailure = creationFailure;
    }


    public String getWhereClause() {
        return this.whereClause;
    }

    public void setWhereClause(String whereClause) {
        this.whereClause = whereClause;
    }

    public String getTargetSchemaName() {
        return this.targetSchemaName;
    }

    public Schema getParentSchema() {
        return this.parentSchema;
    }

    /**
     * This method returns the number of binary large objects columns in the table.
     */
    public int getLargeObjectsColumnCount() {
        int lobjColCount = 0;

        for (int i=0; i<columns.size(); i++) {
            if (columns.get(i).isLargeObject()) {
                lobjColCount++;
            }
        }

        return lobjColCount;
    }

    /**
     * This method returns the number of BLOB columns in the table.
     */
    public int getBLOBColumnCount() {
        int blobColCount = 0;

        for (int i=0; i<columns.size(); i++) {
            if (columns.get(i).isBlob()) {
                blobColCount++;
            }
        }

        return blobColCount;
    }

    /**
     * This method returns the number of CLOB columns in the table.
     */
    public int getCLOBColumnCount() {
        int clobColCount = 0;

        for (int i=0; i<columns.size(); i++) {
            if (columns.get(i).isClob()) {
                clobColCount++;
            }
        }

        return clobColCount;
    }

    /**
     * This method checks if the table contains the given column
     * represented by colName.
     *
     * @return A boolean value of true if table contains the column otherwise false.
     */
    public boolean hasColumn(String colName) {
        for (int i=0; i<columns.size(); i++) {
            if (Utility.removeEnclosingQuotes(columns.get(i).getName()).equals(colName)) {
                return true;
            }
        }
        return false;
    }
}
