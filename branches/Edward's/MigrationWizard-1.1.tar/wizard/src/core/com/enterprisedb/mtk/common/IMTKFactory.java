/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * IMTKFactory.java
 *
 * Created on September 1, 2006, 10:52 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import com.enterprisedb.mtk.MTKException;

/**
 *
 * @author zahid
 */
public interface IMTKFactory {
    public MTKData createMTKData(MTKConstants.DATABASE_TYPE databaseType, IMTKConnection conn,int cpBatchSize) throws MTKException;
    public MTKMetaData createMTKMetaData(MTKConstants.DATABASE_TYPE databaseType, IMTKConnection conn) throws MTKException;
    public MTKMetaData createMTKMetaData(MTKConstants.DATABASE_TYPE databaseType, IMTKConnection conn, String targetSchema) throws MTKException;
    public MTKBridge createMTKBridge(MTKConstants.DATABASE_TYPE sourceDBType, MTKConstants.DATABASE_TYPE targetDBType, IMTKConnection srcConn, IMTKConnection targetConn)
                    throws MTKException;
    public MTKTransformDDL createMTKTransformDDL(MTKConstants.DATABASE_TYPE sourceDBType, MTKConstants.DATABASE_TYPE targetDBType) throws MTKException;
    public IMTKConnection createMTKConnection(MTKConstants.DATABASE_TYPE dbType, String dbURL, String dbUser, String dbPassword) throws MTKException;
    public IMTKConnection createMTKConnection(MTKConstants.DATABASE_TYPE dbType, String propertiesFile) throws MTKException;
}
