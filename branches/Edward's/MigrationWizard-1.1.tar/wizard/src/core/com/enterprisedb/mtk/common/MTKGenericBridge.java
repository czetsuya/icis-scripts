/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKGenericBridge.java
 *
 * Created on 11 January 2007, 20:27
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import java.sql.*;
import java.io.*;
import java.sql.Clob;
import java.sql.Blob;
import com.edb.util.PGInterval;
import com.enterprisedb.mtk.MigrationToolkit;
import com.enterprisedb.mtk.Utility;
import com.enterprisedb.mtk.common.IMTKConnection;
import com.enterprisedb.mtk.common.MTKBridge;
import com.enterprisedb.mtk.schema.metadata.Column;
import com.enterprisedb.mtk.schema.metadata.Table;
import com.enterprisedb.mtk.util.Logger;

/**
 *
 * @author mansoor
 */
public class MTKGenericBridge extends MTKBridge{

    /** Creates a new instance of MTKGenericBridge */
    private static final String BLOB_FILE_NAME = "mtk_blobdata";
    private static final String CLOB_FILE_NAME = "mtk_clobdata";
    private static final int BUFFER_SIZE = 1024; // Bytes
    private MTKConstants.DATABASE_TYPE sourceDatabaseType;
    private MTKConstants.DATABASE_TYPE targetDatabaseType;

    public MTKGenericBridge(IMTKConnection srcConn, IMTKConnection targetConn) {
        super(srcConn, targetConn);
    }
    public MTKGenericBridge(IMTKConnection srcConn, IMTKConnection targetConn,
                            MTKConstants.DATABASE_TYPE sourceDBType,
                            MTKConstants.DATABASE_TYPE targetDBType) {
    	
        super(srcConn, targetConn);
        this.sourceDatabaseType = sourceDBType;
        this.targetDatabaseType = targetDBType;
    }

    /**
     * set table data for batch execution
     * @param table Table
     * @param batchSize int
     * @return long
     * @throws Exception
     */
    public long setTableData(Table table, int batchSize) throws Exception {
        lastMigratedDataSize = 0;
        long committedRowCount = 0;
        boolean lastBatchFailure = false;
        PreparedStatement insertStmt = null;
        Statement sourceStmt = null;
        Statement destStmt = null;
        ResultSet rs =  null;
        String insertStr = "";

        // to handle multi-lob columns, use separate stream references
        // fetch LOB columns count from meta data and set the array size accordingly
        InputStream[] inputStreams = new InputStream[table.getLargeObjectsColumnCount()];
        Reader[] readers = new Reader[table.getCLOBColumnCount()];
        int isIndex = 0;
        int rIndex = 0;
        // Initialize bothh arrays with null values.
        for (int i = 0; i < inputStreams.length; i++) {
            inputStreams[i] = null;
        }
        for (int i = 0; i < readers.length; i++) {
            readers[i] = null;
        }

        int j = 0;
        try {
            targetConn.getConnection().setAutoCommit(false);
            insertStr = "INSERT INTO " + Utility.escape(table.getTargetSchemaName(), targetDatabaseType)+
                        "."+Utility.escape(table.getName(), targetDatabaseType) + " VALUES (";
            for (int i = 0; i < table.getColumns().size(); i++) {
                insertStr = insertStr + "?";
                if (i < table.getColumns().size()-1)
                    insertStr = insertStr + ", ";
            }
            insertStr = insertStr + ");";
            insertStmt  = targetConn.getConnection().prepareStatement(insertStr);

            destStmt = targetConn.getConnection().createStatement();
            destStmt.execute("TRUNCATE TABLE " + Utility.escape(table.getTargetSchemaName(), targetDatabaseType)+
                             "."+Utility.escape(table.getName(), targetDatabaseType));
            targetConn.getConnection().commit();

            if (table.getLargeObjectsColumnCount() > 0) {
                sourceStmt = srcConn.getConnection().createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                if (sourceDatabaseType == MTKConstants.DATABASE_TYPE.MYSQL) {
                    sourceStmt.setFetchSize(Integer.MIN_VALUE);
                } else {
                    sourceStmt.setFetchSize(1);
                }
            } else {
                sourceStmt = srcConn.getConnection().createStatement();
                if (MigrationToolkit.fetchSize > 0) {
                    sourceStmt.setFetchSize(MigrationToolkit.fetchSize);
                }
            }
            rs = sourceStmt.executeQuery(table.getSelectSQL(sourceDatabaseType));

            while (rs.next()) {
                for (int i=0; i<table.getColumns().size(); i++) {
                    Column column = table.getColumns().get(i);
                     switch (column.getDataType()) {
                        case BOOLEAN:
                            insertStmt.setBoolean(i+1, rs.getBoolean(i+1));
                            break;
                        case VARCHAR:
                        case NVARCHAR:
                        case ROWID:
                        case TEXT:
                            // handle binary data reading/writing via CLOB locators to resolve
                            // multil lob columns case, where getBytes() approach fails
                            if (column.isClob() || column.isNClob()) {

                                // Get the clob reference from the result set
                                Clob clob =  rs.getClob(i+1);
                                if (clob != null) {
                                    // number of bytes in the CLOB
                                    long clobLength = clob.length();
                                    lastMigratedDataSize += clobLength;
                                    // read clob data using Stream
                                    readers[rIndex] = clob.getCharacterStream();

                                    if (clobLength > 0) {
                                        // Don't use rIndex after this statement because it is moved forward
                                        insertStmt.setCharacterStream(i+1, readers[rIndex++], (int)clobLength);
                                    } else {
                                        insertStmt.setNull(i+1, java.sql.Types.CLOB);
                                    }
                                } else {
                                    insertStmt.setNull(i+1, java.sql.Types.CLOB);
                                }
                            } else {
                                insertStmt.setString(i+1, rs.getString(i+1));
                            }
                            break;
                        case FLOAT:
                            if (rs.getObject(i+1) != null) {
                                insertStmt.setDouble(i+1, rs.getDouble(i+1));
                            } else {
                                insertStmt.setNull(i+1,java.sql.Types.FLOAT) ;
                            }

                            break;
                        case INTEGER:
                        case NUMERIC:
                            // zahid: provided recommended mapping to avoid precision lose
                            // This is a bad way of ddoing it, but since rs.getFloat returns 0.0 for null values
                            // hence we have to check explicitly if the value is null then insert null
                            Object objVal = rs.getObject(i+1) ;

                            if (column.isReal()) {
                                if (objVal != null) {
                                    insertStmt.setFloat(i+1, rs.getFloat(i+1));
                                } else {
                                    insertStmt.setNull(i+1,java.sql.Types.FLOAT) ;
                                }
                            } else if (column.isDouble()) {
                                if (objVal != null) {
                                    insertStmt.setDouble(i+1, rs.getFloat(i+1));
                                } else {
                                    insertStmt.setNull(i+1,java.sql.Types.DOUBLE) ;
                                }
                            } else {
                                if (objVal != null) {
                                    insertStmt.setBigDecimal(i+1, rs.getBigDecimal(i+1));
                                } else {
                                    insertStmt.setNull(i+1,java.sql.Types.NUMERIC) ;
                                }
                            }
                            break;
                        case DATE:
                        case TIMESTAMP:
                        	insertStmt.setTimestamp(i+1, rs.getTimestamp(i+1));
                            break;
                        case TIME:
                            insertStmt.setTime(i+1, rs.getTime(i+1));
                            break;
                        case BYTEA:
                            // handle binary data reading/writing via BLOB locators to resolve
                            // multil lob columns case, where getBytes() approach fails
                            if (column.isBlob()) {
                                // Get the blob reference from the result set
                                Blob blob = rs.getBlob(i+1);
                                if (blob != null) {
                                    // number of bytes in the BLOB
                                    long blobLength = blob.length();
                                    lastMigratedDataSize += blobLength;

                                    // Read BLOB into a file, so that can be used
                                    //File blobFile = readLOBIntoFile(blob.getBinaryStream(), table.getFullName(), isIndex);
                                    //inputStreams[isIndex] = new FileInputStream(blobFile);

                                    // read blob data directly from binary stream
                                    inputStreams[isIndex] = rs.getBinaryStream(i+1);
                                    if (blobLength >= 0) {
                                        // Don't use isIndex after this statement because it is moved forward
                                        insertStmt.setBinaryStream(i+1, inputStreams[isIndex++], (int) blobLength);
                                    } else {
                                        insertStmt.setNull(i+1, java.sql.Types.BINARY);
                                    }
                                } else {
                                    insertStmt.setNull(i+1, java.sql.Types.BINARY);
                                }
                            // use getBytes() for handling RAW type that is not supported via getBlob()
                            } else {
                                byte[] b = rs.getBytes(i+1);
                                if (b != null) {
                                        lastMigratedDataSize += b.length;
                                        inputStreams[isIndex] = new ByteArrayInputStream(b);
                                        // Don't use isIndex after this statement because it is moved forward
                                        insertStmt.setBinaryStream(i+1, inputStreams[isIndex++], (int)b.length);
                                } else {
                                    insertStmt.setNull(i+1, java.sql.Types.BINARY);
                                }
                            }
                            break;
                        case INTERVAL:
                            // explicitly set value as there is bug reported for default implementation
                            // of PGInterval with passsing value to constructor
                            PGInterval pgInterval = new PGInterval();
                            String intervalValue = rs.getString(i+1);

                            if (intervalValue != null) {
                                intervalValue = convertToEDBIntervalFormat(intervalValue);
                                pgInterval.setValue(intervalValue);
                                lastMigratedDataSize += intervalValue.getBytes().length;
                            }

                            insertStmt.setObject(i+1, pgInterval);
                            //insertStmt.setString(i+1, intervalValue);
                            break;
                        default:
                            throw new Exception("Invalid DataType " + column.getDataTypeString());
                    }
                }
                insertStmt.addBatch();
                j++;
                if (( j % batchSize) == 0) {
                    try {
                        insertStmt.executeBatch();
                        lastBatchFailure = false;
                    } catch (SQLException ex) {
                        if (ex.getNextException() != null)
                            Logger.getInstance().println (ex.getNextException().getMessage () + ", Skipping Batch");
                        else
                            Logger.getInstance().println (ex.getMessage () + ", Skipping Batch");
                        MigrationToolkit.incrementFailureCount() ;
                        lastBatchFailure = true;
                    } catch (Exception ex) {
                        Logger.getInstance().println (ex.getMessage () + ", Skipping Batch");
                        MigrationToolkit.incrementFailureCount() ;
                        lastBatchFailure = true;
                    }

                    insertStmt.clearBatch();
                    targetConn.getConnection().commit();

                    if (!lastBatchFailure) {
                        committedRowCount += batchSize;
                    }

                    // Close streams/readers used to get BLOB/CLOB
                    for (int i = 0; i < inputStreams.length; i++) {
                        if (inputStreams[i] != null) {
                            inputStreams[i].close();
                            inputStreams[i] = null;
                            new File(System.getProperty("user.home") + File.separator + BLOB_FILE_NAME + "_" + table.getFullName() + i).delete();
                        }
                    }
                    for (int i = 0; i < readers.length; i++) {
                        if (readers[i] != null) {
                            readers[i].close();
                            readers[i] = null;
                            new File(System.getProperty("user.home") + File.separator + CLOB_FILE_NAME + "_" + table.getFullName() + i).delete();
                        }
                    }
                    isIndex = 0;
                    rIndex = 0;
                }
            }

            int[] lastBatchCmdCount = null;
            try {
                lastBatchCmdCount = insertStmt.executeBatch();
                lastBatchFailure = false;
            } catch (Exception ex) {
                Logger.getInstance().println (ex.getMessage () + ", Skipping Batch");
                MigrationToolkit.incrementFailureCount() ;
                lastBatchFailure = true;
            }
            insertStmt.clearBatch();
            targetConn.getConnection().commit();

            if (lastBatchCmdCount != null && lastBatchCmdCount.length > 0 && !lastBatchFailure) {
                committedRowCount += (j % batchSize == 0) ? batchSize : j % batchSize;
            }

            // Close streams/readers used to get BLOB/CLOB
            for (int i = 0; i < inputStreams.length; i++) {
                if (inputStreams[i] != null) {
                    inputStreams[i].close();
                    inputStreams[i] = null;
                    new File(System.getProperty("user.home") + File.separator + BLOB_FILE_NAME + "_" + table.getFullName() + i).delete();
                }
            }
            for (int i = 0; i < readers.length; i++) {
                if (readers[i] != null) {
                    readers[i].close();
                    readers[i] = null;
                    new File(System.getProperty("user.home") + File.separator + CLOB_FILE_NAME + "_" + table.getFullName() + i).delete();
                }
            }
        } catch ( SQLException SQLe) {
            targetConn.getConnection().rollback();
            throw Utility.processException(SQLe.getNextException());
        } catch (Exception ex) {
            targetConn.getConnection().rollback();
            throw ex;
        } finally {
            targetConn.getConnection().setAutoCommit(true);
            if (insertStmt != null) {
                insertStmt.close();
            }
            if (destStmt != null) {
                destStmt.close();
            }
            if (rs != null) {
                rs.close();
            }
            if (sourceStmt != null) {
                sourceStmt.close();
            }
        }
        return committedRowCount;
    }

    public long setTableDataInSafeMode(Table table) throws Exception {
        return -1;
    }

    /**
     * Reads LOB into a temporary file created in user home.
     *
     * @param in InputStream
     * @param tableName String
     * @param colIndex int
     * @return File
     * @throws Exception
     */
    @SuppressWarnings("unused")
	private File readLOBIntoFile(InputStream in, String tableName, int colIndex)
            throws Exception {
        // Read BLOB into a file, so that can be used
        byte[] buffer = new byte[BUFFER_SIZE];

        // write the lob data in a temp file
        File lobFile = new File(System.getProperty("user.home") + File.separator + BLOB_FILE_NAME + "_" + tableName + colIndex);
        FileOutputStream out = new FileOutputStream(lobFile);
        int length = -1;
        while ((length = in.read(buffer)) != -1) {
            out.write(buffer, 0, length);
        }
        in.close();
        out.close();
        return lobFile;
    }

    private String convertToEDBIntervalFormat(String intervalValue) {
        // if the interval format is Year to Month e.g. '6-3', convert it to
        // EDB specific format e.g. '6 years 3 months'
        if (intervalValue.indexOf('-') >= 0) {
            String[] yearMonthParts = intervalValue.split("-");
            String edbIntervalValue = null;

            if (yearMonthParts.length == 2) {
                edbIntervalValue = yearMonthParts[0] + " years " + yearMonthParts[1] + " months";
            }
            return edbIntervalValue;
        }
        return intervalValue;
    }
}