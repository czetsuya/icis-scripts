/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKData.java
 *
 * Created on August 31, 2006, 11:52 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import com.enterprisedb.mtk.MigrationToolkit;
import com.enterprisedb.mtk.schema.metadata.Column;
import com.enterprisedb.mtk.schema.metadata.LargeBufferInputStream;
import com.enterprisedb.mtk.schema.metadata.Table;

import java.io.InputStream;
import java.io.PipedOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author zahid
 */
abstract public class MTKData {
    protected static int MaxBufferSize = 1024*1024*8; //8MB
    protected Connection dbConn = null;
    protected Statement stmt = null;
    protected ResultSet rs = null;
    protected boolean hasMoreData = false;
    protected String lastTable = "";

    abstract public void setTableData(String tableName, InputStream pis, char copyDelimiter) throws Exception;

    /**
     * Commit the transaction. This method is called when the
     * auto-commit mode is off and explicit commit is required.
     */
    public void commit() throws SQLException {
        dbConn.commit();
    }

    /**
     * Rollback the transaction. This method is called when the
     * auto-commit mode is off and explicit commit is required.
     */
    public void rollback() throws SQLException {
        dbConn.rollback();
    }

    public void setLastTable(String lastTable) {
        this.lastTable = lastTable ;
    }

    public void reset() {
        hasMoreData = false;
        try {
            rs.close();
            stmt.close();
            rs = null;
            stmt = null;
        } catch (Exception ex) {
            // ignore for now
        }
    }

    public LargeBufferInputStream getTableData(Table table, char copyDelimeter, boolean escapeTabDelimiter) throws Exception {

        LargeBufferInputStream pis = new LargeBufferInputStream(MaxBufferSize);
        PipedOutputStream pos = new PipedOutputStream();
        String newLineSequence = "\\" + "\\n" ;
        String carriageReturnSequence = "\\" + "\\r" ;
        String columnTabDelimiter = "\\\\t";

        pis.connect(pos);
        try {
            if (!hasMoreData) {
                if (lastTable.compareToIgnoreCase(table.getFullName()) != 0) {
                    stmt = dbConn.createStatement();
                    rs = stmt.executeQuery(table.getSelectSQL());
                    lastTable = table.getFullName();
                } else {
                    return null;
                }
            }

            while (rs.next()) {
                for (int i=0; i<table.getColumns().size(); i++) {
                    String lastField = null;
                    boolean largeObjFlag = false;
                    switch (table.getColumns().get(i).getDataType()) {
                        case BOOLEAN:
                            if (rs.getObject (i+1) != null) {
                                lastField = String.valueOf(rs.getInt(i+1));
                            }
                            break;
                        case VARCHAR:
                        case TEXT:
                        case NVARCHAR:
                        case ROWID:
                            lastField = rs.getString(i+1);

                            // replace the carriage return and newlines with character sequences
                            // so the copy command doesn't fail
                            if (lastField != null) {
                                // check if to replace the NULL char
                                if (MigrationToolkit.replaceNullChar()) {
                                    lastField = lastField.replaceAll("\0", MigrationToolkit.nullReplacementChar());
                                }
                                
                                lastField = lastField.replaceAll("\n",newLineSequence);
                                lastField = lastField.replaceAll("\r",carriageReturnSequence) ;
                                if(escapeTabDelimiter){
                                	lastField = lastField.replaceAll("\t",columnTabDelimiter);
                                }
                                //Replace The Ending Blackslash with \\
                                //Otherwise it will just fail the copy command
                                if (lastField.endsWith("\\")) {
                                    lastField = lastField.concat("\\");
                                }
                            }
                            break;
                        case FLOAT:
                            if (rs.getObject (i+1) != null)
                                lastField = new Double( rs.getDouble (i+1)).toString () ;
                            break;
                        case INTEGER:
                        case NUMERIC:
                            // zahid: provided recommended mapping to avoid precision lose
                            Column column = table.getColumns().get(i);
                            if (rs.getObject (i+1) != null) {
                                if (column.isReal()) {
                                        lastField = new Float(rs.getFloat (i+1)).toString () ;
                                } else if (column.isDouble()) {
                                        lastField = new Double (rs.getDouble (i+1)).toString () ;
                                } else {
                                        lastField = rs.getBigDecimal (i+1).toString () ;
                                }
                            }
                            break;
                        case TIME:
                            if (rs.getTime(i+1) != null){
                                lastField = rs.getTime(i+1).toString();
                            }
                            break;
                        case DATE:
                        case TIMESTAMP:
                            if (rs.getTimestamp(i+1) != null){
                                lastField = rs.getTimestamp(i+1).toString();
                            }
                            break;
                        // for Large Object data types i.e. BLOB, CLOB and LONG RAW; insert null
                        case BYTEA:
                            largeObjFlag = true;
                            break;
                        case INTERVAL:
                            if (rs.getString(i+1) != null){
                                lastField = rs.getString(i+1);
                            }

                            break;

                        default:
                            if (rs.getMetaData().getColumnTypeName(i+1).equalsIgnoreCase("CLOB") ||
                                rs.getMetaData().getColumnTypeName(i+1).equalsIgnoreCase("NCLOB"))
                                throw new Exception("This Table Contains CLOB data, Marked for Bulk Insert Loading");
                            else
                                throw new Exception(rs.getMetaData().getColumnTypeName(i+1) + " is Not Supported by COPY");
                    } // switch

                    if (rs.wasNull() || largeObjFlag) {
                        pos.write(new String("\\N").getBytes());
                    }
                    else {
                        pos.write(lastField.getBytes());
                    }

                    if (i < table.getColumns().size()-1)
                        pos.write(copyDelimeter);
                } // for
                pos.write('\n');

                pis.addRowNum();

                // The buffer is full. Return this data and come back for more later
                if ((MaxBufferSize - pis.getLength()) < table.getMaxRowSize()) {
                    pos.flush();
                    pos.close();
                    hasMoreData = true;
                    return pis;
                }

            } // while
            rs.close();
            stmt.close();
            hasMoreData = false;
            pos.flush();
            pos.close();
        } catch (Exception ex) {
            // since if more data is available, cursor is used across
            // multiple method calls, hence in case of exception release the resources 
            // here instead of finally block (that otherwise is the proper place)
            if (rs != null) {
                rs.close();
            }

            if (stmt != null) {
                stmt.close();
            }
            
            throw ex;
        }

        return pis;
    }

}
