/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Constraint.java
 *
 * Created on March 8, 2006, 5:00 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
public class Constraint {
    private String contraintName = null;
    private String tableName = null;
    private String deleteRule = null ;
    private String refIntTableName = null;
    private char type;
    private String searchCondition = null;
    private ColumnList columns = null;
    private ColumnList refIntColumns = null;
    // represents if the constraint name is case-sensitive
    private boolean caseSensitive = false;

    /** Creates a new instance of Constraint */
    public Constraint() {
    }

    public Constraint(String TableName, String ConstraintName, boolean caseSensitive) {
        tableName = TableName;
        contraintName = ConstraintName;
        this.caseSensitive = caseSensitive;
    }

    public void setDeleteRule(String delRule) {
        deleteRule = delRule ;
    }

    public String getDeleteRule() {
        return deleteRule ;
    }
    public void setType(char Type) {
        type = Type;
    }

    public void setRefIntegrityTable(String RefIntegrityTable) {
        refIntTableName = RefIntegrityTable;
    }

    public void setSearchCondition(String SearchCondition) {
        searchCondition = SearchCondition;
    }

    public char getType() {
        return type;
    }

    public String getSearchCondition() {
        return searchCondition;
    }

    public String getName() {
        return contraintName;
    }

    public void setName(String name) {
        this.contraintName = null;
    }

    public String getTableName() {
        return tableName;
    }

    public String getRefIntegrityTable() {
        return refIntTableName;
    }

    public ColumnList getColumns() {
        if (columns == null)
            columns = new ColumnList();
        return columns;
    }

    public void addColumn(Column column) {
        if (columns == null)
            columns = new ColumnList();

        columns.add(column);
    }

    public ColumnList getRefIntegrityColumns() {
        if (refIntColumns == null)
            refIntColumns = new ColumnList();
        return refIntColumns;
    }

    public void addRefIntegrityColumn(Column column) {
        if (refIntColumns == null)
            refIntColumns = new ColumnList();

        refIntColumns.add(column);
    }

    /**
     * It returns the constraint name in case-sensitive pattern enclosed in
     * double quotes if param quoted is true otherwise in normal form.
     */
    public String getName(boolean quoted) {
        // constraintName can be null in case of MySQL
        if (caseSensitive && contraintName != null) {
            return "\"" + contraintName + "\"";
        }

        return contraintName;
    }

    public boolean isCaseSensitive() {
        return caseSensitive;
    }


}
