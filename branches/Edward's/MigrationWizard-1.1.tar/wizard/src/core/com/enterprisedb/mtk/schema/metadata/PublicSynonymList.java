/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * PublicSynonymList.java
 *
 * Created on May 23, 2006, 8:39 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author usama
 */
import java.util.*;

public class PublicSynonymList {
    private ArrayList<PublicSynonym> list = null;
    
    /** Creates a new instance of ViewList */
    public PublicSynonymList() {
    }

    public void add(PublicSynonym syn) {
        if (list == null) 
            list = new ArrayList<PublicSynonym>();
        
        list.add(syn);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public PublicSynonym get(int index) {
        return (PublicSynonym) list.get(index);
    }
    
}
