package com.enterprisedb.mtk.test;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("MySQL 2 PG Migrator Test Suite");
		//$JUnit-BEGIN$
		suite.addTestSuite(MySQL2PGMigratorTest.class);
		//$JUnit-END$
		return suite;
	}

}
