/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Index.java
 *
 * Created on March 10, 2006, 8:01 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
public class Index {
    private String indexName = null;
    private String tableName = null;
    private boolean unique = false;
    private ColumnList columns = null;
//    private ColumnList refIntColumns = null;

    /** Creates a new instance of Index */
    public Index() {
    }

    public Index(String TableName, String IndexName) {
        tableName = TableName;
        indexName = IndexName;
    }

    public void setUniqueness(String Uniqueness) {
        if (Uniqueness.compareToIgnoreCase("UNIQUE") == 0)
            unique = true;
        else
            unique = false;
    }

    public void setUnique(boolean value) {
        this.unique = value;
    }

    public boolean isUnique() {
        return unique;
    }

    public String getName() {
        return indexName;
    }

    public void setName(String name) {
        this.indexName = name;
    }

    public String getTableName() {
        return tableName;
    }

    public ColumnList getColumns() {
        if (columns == null)
            columns = new ColumnList();
        return columns;
    }

    public void addColumn(Column column) {
        if (columns == null)
            columns = new ColumnList();

        columns.add(column);
    }
}
