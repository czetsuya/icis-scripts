/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKConnection.java
 *
 * Created on September 12, 2006, 7:04 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author zahid
 */
public abstract class MTKConnection implements IMTKConnection {
    protected Connection conn = null;
    protected String dbURL = null;
    protected String dbUser = null;
    protected String dbPassword = null;
    
    /**
     * Creates a new instance of MTKConnection
     */
    public MTKConnection(String dbURL, String dbUser, String dbPassword) throws Exception {
        this.dbURL= dbURL;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
    }
    
    /** Creates a new instance of RedwoodConnection */
    public MTKConnection(String PropertiesFile) throws Exception{
    }
    
    public Connection getConnection() {
        return conn;
    }

     
    public void setTransactionIsolationLevel(int transactionIsolationLevel) throws SQLException {
        conn.setTransactionIsolation(transactionIsolationLevel);
    }
    
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        conn.setAutoCommit(autoCommit);
    }
    
    public boolean getAutoCommit() throws SQLException {
        return conn.getAutoCommit();
    }
    
    /**
     * Commit the transaction. This method is called when the
     * auto-commit mode is off and an explicit commit is required.
     */
    public void commit() throws SQLException {
        conn.commit();
    }
    
}
