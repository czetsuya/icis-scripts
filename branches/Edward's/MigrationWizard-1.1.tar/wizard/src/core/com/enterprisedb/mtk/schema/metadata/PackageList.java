/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * PackageList.java
 *
 * Created on March 8, 2006, 3:08 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class PackageList {
    private ArrayList<Package> list = null;
    
    /** Creates a new instance of PackageList */
    public PackageList() {
    }

    public void add(Package pack) {
        if (list == null) 
            list = new ArrayList<Package>();
        
        list.add(pack);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Package get(int index) {
        return (Package) list.get(index);
    }
    
}
