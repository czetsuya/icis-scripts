/**
 * 
 */
package com.enterprisedb.mtk;


/**
 * @author amir
 *
 */
public class MigrationProps {
	
	public enum MigrationType {
        FULL_MIGRATION,
        DATA_ONLY,
        SCHEMA_ONLY
    };
    
    private ConnectionProps sourceConn = null;
	private ConnectionProps targetConn = null;
    private MigrationType migrationType = MigrationType.FULL_MIGRATION;
    private boolean migrateConstraints = true;
    private String defaultDateTime = null;
	private boolean recreateSchema = false;
	private char copyDelimiter = '\t';
	private String[] schemas =null;
	private String[] tables = null; 

	public MigrationProps(ConnectionProps sourceConn, ConnectionProps targetConn, String[] schemas, String[] tables, String defaultDateTime, MigrationType migrationType, boolean migrateConstraints, boolean recreateSchema) {
		this.sourceConn = sourceConn;
		this.targetConn = targetConn;
		this.schemas = schemas;
		this.tables = tables;
		this.defaultDateTime = defaultDateTime;
		this.migrationType = migrationType;
		this.migrateConstraints = migrateConstraints;
		this.recreateSchema = recreateSchema;
	}
	
	public MigrationType getMigrationType() {
		return migrationType;
	}
	public void setMigrationType(MigrationType migrationType) {
		this.migrationType = migrationType;
	}
	public boolean isRecreateSchema() {
		return recreateSchema;
	}
	public void setRecreateSchema(boolean recreateSchema) {
		this.recreateSchema = recreateSchema;
	}
	public ConnectionProps getSourceConn() {
		return sourceConn;
	}
	public void setSourceConn(ConnectionProps sourceConn) {
		this.sourceConn = sourceConn;
	}
	public ConnectionProps getTargetConn() {
		return targetConn;
	}
	public void setTargetConn(ConnectionProps targetConn) {
		this.targetConn = targetConn;
	}
	public boolean isMigrateConstraints() {
		return migrateConstraints;
	}
	public void setMigrateConstraints(boolean migrateConstraints) {
		this.migrateConstraints = migrateConstraints;
	}

	public char getCopyDelimiter() {
		return copyDelimiter;
	}

	public void setCopyDelimiter(char copyDelimiter) {
		this.copyDelimiter = copyDelimiter;
	}
	public String[] getSchemas() {
		return schemas;
	}

	public void setSchemas(String[] schemas) {
		this.schemas = schemas;
	}

	public String[] getTables() {
		return tables;
	}

	public void setTables(String[] tables) {
		this.tables = tables;
	}

	public String getDefaultDateTime() {
		return defaultDateTime;
	}

	public void setDefaultDateTime(String defaultDateTime) {
		this.defaultDateTime = defaultDateTime;
	}
}
