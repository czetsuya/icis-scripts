/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * View.java
 *
 * Created on March 7, 2006, 9:33 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */

public class View {
    private String viewName = null;
    private String sql = "";
    
    /** Creates a new instance of View */
    public View() {
    }

    public View(String ViewName) {
        viewName = ViewName;
    }
    
    public String getName() {
        return viewName;
    }
    
    public void setSQL(String SQL) {
        sql = sql + SQL;
    }
    
    public String getSQL() {
        return sql;
    }
}

