/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * IMTKConnection.java
 *
 * Created on September 12, 2006, 7:04 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author zahid
 */
public interface IMTKConnection {
    Connection getConnection();

    void setTransactionIsolationLevel(int transactionIsolationLevel) throws SQLException;
    void setAutoCommit(boolean autoCommit) throws SQLException;
    boolean getAutoCommit() throws SQLException;

    /**
     * Commit the transaction. This method is called when the
     * auto-commit mode is off and an explicit commit is required.
     */
    void commit() throws SQLException;
    
}
