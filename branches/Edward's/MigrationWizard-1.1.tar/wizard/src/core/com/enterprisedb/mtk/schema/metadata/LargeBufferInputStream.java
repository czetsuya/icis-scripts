/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * LargeBufferInputStream.java
 *
 * Created on March 7, 2006, 8:37 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.io.*;

public class LargeBufferInputStream extends PipedInputStream {

        private int numRows;

        public LargeBufferInputStream(int bufferSize) {
            super();
            buffer = new byte[bufferSize];
            numRows = 0;
        }

        public LargeBufferInputStream(PipedOutputStream out, int bufferSize) {
            super();
            buffer = new byte[bufferSize];
            numRows = 0;
        }
        
        public int getLength() {
            return in + 1;
        }
        
        public int getNumRows() {
            return numRows;
        }
        
        public void addRowNum() {
            numRows = numRows + 1;
        }
}    
    
