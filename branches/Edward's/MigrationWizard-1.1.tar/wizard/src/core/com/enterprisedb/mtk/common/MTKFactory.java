/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKFactory.java
 *
 * Created on September 1, 2006, 11:04 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import com.enterprisedb.mtk.MTKException;

/**
 *
 * @author zahid
 */
public class MTKFactory implements IMTKFactory {

    /** Creates a new instance of MTKFactory */
    public MTKFactory() {
    }

    public MTKData createMTKData(MTKConstants.DATABASE_TYPE databaseType, IMTKConnection conn, int cpBatchSize) throws MTKException {
        switch (databaseType) {
            case POSTGRESQL:
                return new com.enterprisedb.mtk.dbhandler.postgresql.Data(conn,cpBatchSize);
            case MYSQL:
                return new com.enterprisedb.mtk.dbhandler.mysql.Data(conn,cpBatchSize, databaseType);
            default:
                throw new MTKException("The database type is not supported.");
        }
    }

    public MTKMetaData createMTKMetaData(MTKConstants.DATABASE_TYPE databaseType, IMTKConnection conn) throws MTKException {
        switch (databaseType) {
            case POSTGRESQL:
                try {
                    return new com.enterprisedb.mtk.dbhandler.postgresql.MetaData(conn);
                } catch (Exception e) {
                    throw new MTKException(e);
                }
            case MYSQL:
                try {
                    return new com.enterprisedb.mtk.dbhandler.mysql.MetaData(conn);
                } catch (Exception e) {
                    throw new MTKException(e);
                }
            default:
                throw new MTKException("The database type is not supported.");
        }
    }

    public MTKMetaData createMTKMetaData(MTKConstants.DATABASE_TYPE databaseType, IMTKConnection conn, String targetSchema) throws MTKException {
        switch (databaseType) {
            case POSTGRESQL:
                try {
                    return new com.enterprisedb.mtk.dbhandler.postgresql.MetaData(conn, targetSchema);
                } catch (Exception e) {
                    throw new MTKException(e);
                }
            case MYSQL:
                try {
                    return new com.enterprisedb.mtk.dbhandler.mysql.MetaData(conn, targetSchema);
                } catch (Exception e) {
                    throw new MTKException(e);
                }
            default:
                throw new MTKException("The database type is not supported.");
        }
    }

    public MTKBridge createMTKBridge(MTKConstants.DATABASE_TYPE sourceDBType,
                                     MTKConstants.DATABASE_TYPE targetDBType,
                                     IMTKConnection srcConn,
                                     IMTKConnection targetConn) 
    throws MTKException {
    	
        MTKBridge result = null;
        if (sourceDBType == MTKConstants.DATABASE_TYPE.MYSQL && targetDBType == MTKConstants.DATABASE_TYPE.POSTGRESQL ) {
                result = new com.enterprisedb.mtk.common.MTKGenericBridge(srcConn, targetConn, sourceDBType, targetDBType);
        } else {
        	throw new MTKException("The database type is not supported.");
        }
        return result;
    }

    public MTKTransformDDL createMTKTransformDDL(MTKConstants.DATABASE_TYPE sourceDBType, MTKConstants.DATABASE_TYPE targetDBType) throws MTKException {
        if (sourceDBType == MTKConstants.DATABASE_TYPE.MYSQL && targetDBType == MTKConstants.DATABASE_TYPE.POSTGRESQL) {
        	return new MTKGenericTransformDDL();
        } else {
            throw new MTKException("The database type is not supported.");
        }
    }

    public IMTKConnection createMTKConnection(MTKConstants.DATABASE_TYPE dbType, String dbURL, String dbUser, String dbPassword) throws MTKException {
        switch (dbType) {
            case POSTGRESQL:
                try {
                    return new com.enterprisedb.mtk.dbhandler.postgresql.PostgreSQLConnection(dbURL, dbUser, dbPassword);
                } catch (Exception e) {
                    throw new MTKException(e);
                }
            case MYSQL:
                try {
                    return new com.enterprisedb.mtk.dbhandler.mysql.MySQLConnection(dbURL, dbUser, dbPassword);
                } catch (Exception e) {
                    throw new MTKException(e);
                }
            default:
                throw new MTKException("The database type is not supported.");
        }
    }

    public IMTKConnection createMTKConnection(MTKConstants.DATABASE_TYPE dbType, String propertiesFile) throws MTKException {
        switch (dbType) {
            case POSTGRESQL:
                try {
                    return new com.enterprisedb.mtk.dbhandler.postgresql.PostgreSQLConnection(propertiesFile);
                } catch (Exception e) {
                    throw new MTKException(e);
                }
            case MYSQL:
                try {
                    return new com.enterprisedb.mtk.dbhandler.mysql.MySQLConnection(propertiesFile);
                } catch (Exception e) {
                    throw new MTKException(e);
                }
            default:
                throw new MTKException("The database type is not supported.");
        }
    }

}