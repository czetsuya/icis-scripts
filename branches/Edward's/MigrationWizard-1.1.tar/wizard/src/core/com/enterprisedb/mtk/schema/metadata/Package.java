/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Package.java
 *
 * Created on March 8, 2006, 3:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
public class Package {
    private String packageName = null;
    private String headerSQL = "";
    private String bodySQL = "";
    
    /** Creates a new instance of Package */
    public Package() {
    }

    public Package(String PackageName) {
        packageName = PackageName;
    }
    
    public String getName() {
        return packageName;
    }
    
    public void setHeaderSQL(String SQL) {
        headerSQL = headerSQL + SQL;
    }
    
    public String getHeaderSQL() {
        return headerSQL;
    }

    public void setBodySQL(String SQL) {
        bodySQL = bodySQL + SQL;
    }
    
    public String getBodySQL() {
        return bodySQL;
    }
}
