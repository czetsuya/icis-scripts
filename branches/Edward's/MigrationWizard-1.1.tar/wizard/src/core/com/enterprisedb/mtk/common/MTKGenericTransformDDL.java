/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKGenericTransformDDL.java
 *
 * Created on January 11, 2007, 8:30 PM
 * @author Aamir Yaseen
*/
package com.enterprisedb.mtk.common;

import com.enterprisedb.mtk.Utility;
import com.enterprisedb.mtk.schema.metadata.Column;
import com.enterprisedb.mtk.schema.metadata.Constraint;
import com.enterprisedb.mtk.schema.metadata.Function;
import com.enterprisedb.mtk.schema.metadata.Index;
import com.enterprisedb.mtk.schema.metadata.Package;
import com.enterprisedb.mtk.schema.metadata.Procedure;
import com.enterprisedb.mtk.schema.metadata.PublicSynonym;
import com.enterprisedb.mtk.schema.metadata.Table;
import com.enterprisedb.mtk.schema.metadata.Trigger;
import com.enterprisedb.mtk.schema.metadata.View;

/**
 * @author Aamir Yaseen
 *
 */
public class MTKGenericTransformDDL extends MTKTransformDDL {

    /**
     * Default Constructor
     */
    public MTKGenericTransformDDL() {
        super();
    }

    /**
     * It retruns DDL to create specified Table.
     *
     * @param table Table
     * @return String
     */
    public String getCreateScript(Table table) {
        // Form create table statement
        String sql = "CREATE TABLE " + escape(table.getName()) + " (\n";
        for (int i=0; i < table.getColumns().size(); i++) {
            sql += getColumnLine(table.getColumns().get(i));
            if (i < table.getColumns().size()-1)
                sql += ", ";
            sql += "\n";
        }
        sql += ");\n";

        //Add column comments
        sql += getColumnsComments(table);

        return sql;
    }

    /**
     * It retruns DDL to create specified View.
     *
     * @param view View
     * @return String
     */
    public String getCreateScript(View view) {
        return null;
    }

    /**
     * It retruns DDL to define comments on each of the table columns.
     * @param table Table
     * @return String
     */
    protected String getColumnsComments(Table table) {
        String sql = "";
        Column column = null;
        for (int i = 0; i < table.getColumns().size(); i++) {
            column = table.getColumns().get(i);
            if (column.getComments() != null) {
                sql += "COMMENT ON COLUMN " +
                        escape(table.getTargetSchemaName()) + "." + escape(table.getName()) + "." +
                        escape(column.getName(), column.isCaseSensitive()) + " IS '" +
                        table.getColumns().get(i).getComments().replaceAll("'", "\\\\'") + "';\n";
            }
        }
        return sql;
    }

    /**
     * It retruns DDL to define specified column.
     *
     * @param column Column
     * @return String
     */
    protected String getColumnLine(Column column) {
        String str = "";
        String colName = column.getName();

        // check if column name contains special char, enclose it in double-quotes
        colName = escape(colName, column.isCaseSensitive());

        str = str + getIndent() + colName;

        // check if custom type mapping is available, use it
        String customType = null;

        if ((customType = super.getCustomColType(column.getTableName(),
                                                 column.getName())) != null) {
            str += " " + customType;
        } else {
            if (column.isRowID()) {
                // although one of the reference documents created by Ernie mentions that rowid is mapped
                // to BIGINT, but that's not possible as rowid value is non-numeric, so map
                // it to VARCHAR
                str = str + " " + "VARCHAR";
            } else if (column.isInterval()) {
                str = str + " " + "INTERVAL";
            } else {
                str = str + " " + column.getDataTypeString();
            }

            if (column.getDataType() == Column.DataType.VARCHAR ||
                column.getDataType() == Column.DataType.NVARCHAR)
                str = str + "(" + column.getLength() + ")";

            if ((column.getDataType() == Column.DataType.INTEGER &&
                 !column.getDataTypeString().equalsIgnoreCase("INTEGER") &&
                 !column.isSmallint() &&
                 !column.getDataTypeString().equalsIgnoreCase("INT") &&
                 !column.getDataTypeString().equalsIgnoreCase("BIGINT") &&
                 !column.getDataTypeString().equalsIgnoreCase("SERIAL") &&
                 !column.getDataTypeString().equalsIgnoreCase("BIGSERIAL") &&
                 !column.getDataTypeString().equalsIgnoreCase("YEAR")) ||
                (column.getDataType() == Column.DataType.NUMERIC && !column.isReal())) {
                if (column.getPrecision() > 0) {
                    str = str + "(" + column.getPrecision();
                    if (column.getScale() > 0)
                        str = str + "," + column.getScale();
                    str = str + ")";
                }
            }
        }

        // define default clause if it's not null
        if (column.getDefaultClause() != null && column.getDefaultClause().trim().length() > 0) {
            String defaultValue = column.getDefaultClause();
            if (defaultValue != null && defaultValue.toLowerCase().contains("current")) {
                defaultValue = "now";
            }
            if ((column.isTimeStamp()) && defaultDateTime != null) {
                defaultValue = defaultDateTime.replace("_", " ");
                if (defaultValue.length() == 10) {
                    defaultValue += " 00:00:00";
                }
            }
            if (column.isDate() && defaultDateTime != null) {
                defaultValue = defaultDateTime.substring(0, 10);
            }
            str += " DEFAULT '"+defaultValue+"'";
        }

        if (!column.isNullable())
            str = str + " NOT NULL";

        return str;
    }

    /**
     * It retruns DDL to create specified Index.
     *
     * @param index Index
     * @return String
     */
    public String getCreateScript(Index index) {
        String sql = "";

        // Only create non-unique indexes since they are already created
        // as a unique constraint
        sql = sql + "CREATE "+(index.isUnique() ? "UNIQUE" : "") +" INDEX " + escape(index.getName()) + " ON " +
              escape(index.getTableName()) + " (";
        for (int i = 0; i < index.getColumns().size(); i++) {
            sql += escape(index.getColumns().get(i).getName(),
                          index.getColumns().get(i).isCaseSensitive());
            if (i < index.getColumns().size() - 1)
                sql = sql + ", ";
        }
        sql = sql + ");\n";
        return sql;
    }

    /**
     * It retruns DDL to create specified Constraint.
     *
     * @param constraint Constraint
     * @return String
     */
    public String getCreateScript(Constraint constraint) {
        String sql = "";
        // to handle contraints for a case-sensitive table,
        //enclose the table name in double quotes
        String constTableName = constraint.getTableName();
        constTableName = escape(constTableName);

        String constraintName = escape(constraint.getName(), constraint.isCaseSensitive());
        if (constraint.getType() == 'P') {
            sql = sql + "ALTER TABLE " + constTableName;

            sql += " ADD";
            if (!(constraintName == null
                  || constraintName.equalsIgnoreCase("PRIMARY")
                  || constraintName.equalsIgnoreCase("\"PRIMARY\""))){

                sql += " CONSTRAINT " + constraintName;
            }
            sql += " PRIMARY KEY (";
            for (int i = 0; i < constraint.getColumns().size(); i++) {
                sql += escape(constraint.getColumns().get(i).getName(),
                              constraint.getColumns().get(i).isCaseSensitive());
                if (i < constraint.getColumns().size() - 1)
                    sql = sql + ", ";
            }
            sql = sql + ");\n";
        }

        if (constraint.getType() == 'U') {
            sql = sql + "ALTER TABLE " + constTableName + " ADD";
            if (constraintName != null) {
                sql += " CONSTRAINT " + constraintName;
            }
            sql += " UNIQUE (";
            for (int i = 0; i < constraint.getColumns().size(); i++) {
                sql += escape(constraint.getColumns().get(i).getName(),
                              constraint.getColumns().get(i).isCaseSensitive());
                if (i < constraint.getColumns().size() - 1)
                    sql = sql + ", ";
            }
            sql = sql + ");\n";
        }

        if (constraint.getType() == 'C') {
            // Skip "is not null" constraints since they are already appliead
            // at table creation time
            if (!constraint.getSearchCondition().endsWith("IS NOT NULL")) {
                sql = sql + "ALTER TABLE " + constTableName + " ADD";
                if (constraintName != null)
                    sql += " CONSTRAINT " + constraintName;
                sql += " CHECK (" + constraint.getSearchCondition() + ");\n";
            }
        }

        if (constraint.getType() == 'R') {
            sql += "ALTER TABLE " + constTableName + " ADD";
            if (constraintName != null)
                sql += " CONSTRAINT " + constraintName;
            sql += " FOREIGN KEY (";
            for (int i = 0; i < constraint.getColumns().size(); i++) {
                sql += escape(constraint.getColumns().get(i).getName(),
                              constraint.getColumns().get(i).isCaseSensitive());
                if (i < constraint.getColumns().size() - 1)
                    sql = sql + ", ";
            }
            sql = sql + ") REFERENCES " + escape(constraint.getRefIntegrityTable()) +
                  " (";
            for (int i = 0; i < constraint.getRefIntegrityColumns().size(); i++) {
                sql += escape(constraint.getRefIntegrityColumns().get(i).getName(),
                              constraint.getRefIntegrityColumns().get(i).isCaseSensitive());
                if (i < constraint.getRefIntegrityColumns().size() - 1)
                    sql = sql + ", ";
            }
            sql = sql + ") MATCH FULL ON DELETE " + constraint.getDeleteRule() +
                  ";\n";
        }

        return sql;
    }

    /**
     * Escapes identifier according to EnterpriseDB rules. If caseSensitive is
     * true then it will not check for EnterpriseDB rules and will simply place
     * escape character.
     *
     * @param identifier String
     * @param casesensitive boolean
     * @return String
     */
    private String escape(String identifier, boolean caseSensitive) {
        // Check if identifier is already escaped for EnterpriseDB
        if (identifier != null && identifier.startsWith("\"") &&
            identifier.endsWith("\"")) {
            return identifier;
        }
        if (!caseSensitive) {
            return Utility.escape(identifier,
                                  MTKConstants.DATABASE_TYPE.POSTGRESQL);
        } else {
            return "\"" + identifier + "\"";
        }
    }

    /**
     * Escapes the identifier according to PostgreSQL rules.
     * @param identifier String
     * @return String
     */
    private String escape(String identifier) {
        return escape(identifier, false);
    }

    /**
     * Following Functions are not supported by MySQL
     */
    public String getCreateScript(Procedure proc) { return ""; }
    public String getCreateScript(Function func) { return ""; }
    public String getCreateScript(PublicSynonym syn) { return ""; }
    public String getCreateScript(Trigger trigger) { return ""; }
    public String getCreateScriptPackageSpec(Package pack) { return ""; }
    public String getCreateScriptPackageBody(Package pack) { return ""; }
}
