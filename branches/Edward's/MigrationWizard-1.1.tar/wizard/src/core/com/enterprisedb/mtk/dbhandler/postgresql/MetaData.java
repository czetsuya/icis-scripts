/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MetaData.java
 *
 * Created on February 28, 2006, 9:05 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.dbhandler.postgresql;

import com.enterprisedb.mtk.Utility;
import com.enterprisedb.mtk.common.IMTKConnection;
import com.enterprisedb.mtk.common.MTKConstants;
import com.enterprisedb.mtk.common.MTKMetaData;
import com.enterprisedb.mtk.schema.metadata.Column;
import com.enterprisedb.mtk.schema.metadata.Constraint;
import com.enterprisedb.mtk.schema.metadata.Index;
import com.enterprisedb.mtk.schema.metadata.Table;
import com.enterprisedb.mtk.util.Logger;
import java.io.PrintWriter;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class holds the meta data information for PostgreSQL schema and
 * provides the methods to access and manipulate this information.
 */
public class MetaData extends MTKMetaData {
	public static final String SQL_STATEMENT_DELIMITER = ";";
    private final String sqlIndexesDefs = "SELECT indexname, indexdef FROM pg_catalog.pg_indexes WHERE schemaname = ? AND tablename = ?";
    private final String sqlConsts = "SELECT conname FROM pg_catalog.pg_constraint a, pg_class b, pg_namespace c " +
                                     "WHERE a.connamespace = c.oid AND a.conrelid = b.oid AND c.nspname = ? AND b.relname = ?";
    private IMTKConnection conn = null;
    private PreparedStatement psIndexesDefs = null;
    private PreparedStatement psConsts = null;
    private HashMap<String, ArrayList> mapTableIndexesDefs = new HashMap<String, ArrayList>();

    /**
     * Creates a new instance of MetaData
     */
    public MetaData(IMTKConnection conn) throws Exception {
        super();
        this.conn = conn;
        this.dbConn = conn.getConnection();
    }

    /**
     * Creates a new instance of MetaData
     */
    public MetaData(IMTKConnection conn, String targetSchemaName) throws Exception {
        super();
        this.conn = conn;
        this.dbConn = conn.getConnection();
        this.targetSchemaName = targetSchemaName;
    }

    protected void initPublicSynonymStatement(String commaSepSynNames) throws SQLException {
    }

    protected void initTableStatement(String commaSepTableNames) throws SQLException {
        getTablesStr = "SELECT table_name FROM information_schema.tables " +
                "WHERE table_schema = ? ";

        if (commaSepTableNames != null){
            getTablesStr = getTablesStr + " AND table_name IN (" + commaSepTableNames + ") ";
        }

        getTablesStr = getTablesStr + " ORDER BY table_name ";
        getTables  = dbConn.prepareStatement(getTablesStr);

    }

    protected void initColumnStatement() throws SQLException {
        getColumnsStr = "SELECT column_name, data_type, character_maximum_length as data_length, numeric_precision as data_precision, numeric_scale as data_scale, is_nullable as nullable, column_default as data_default, col_description(('\"' || table_schema || '\".\"' || table_name  || '\"')::pg_catalog.regclass, ordinal_position) as comments, pg_catalog.format_type(c.atttypid, c.atttypmod) as ex_data_type " +
                        "FROM information_schema.columns a, pg_class b, pg_attribute c, pg_namespace d WHERE table_schema =  ? AND table_name = ? " +
                        "AND a.table_name = b.relname AND b.relnamespace = d.oid AND d.nspname = a.table_schema AND b.oid = c.attrelid AND a.column_name = c.attname " +
                        "ORDER BY ordinal_position";

        getColumns = dbConn.prepareStatement(getColumnsStr);

    }

    protected void initTriggerStatement(String commaSepTableNames) throws SQLException {
    }

    protected void initViewStatement(String commaSepViewNames) throws SQLException {
    }

    protected void initSequenceStatement(String commaSepSequenceNames) throws SQLException {
    }

    protected void initProcStatement(String commaSepProcNames) throws SQLException {
    }

    protected void initPackageStatement(String commaSepPackageNames) throws SQLException {

    }

    protected void initConstraintStatement(String commaSepTableNames) throws SQLException {
        getConstraintsStr = "SELECT a.conname constraint_name, a.contype constraint_type, b.relname table_name, " +
                            "a.consrc search_condition, '' r_constraint_name, confdeltype delete_rule " +
                            "FROM pg_constraint a, pg_class b, pg_namespace c " +
                            "WHERE a.connamespace = c.oid AND a.conrelid = b.oid AND contype IN ('p','u','c') " +
                            "AND c.nspname = ? ";

        if (commaSepTableNames != null){
            getConstraintsStr = getConstraintsStr + " AND b.relname IN (" + commaSepTableNames + ") ";
        }

        getConstraintsStr = getConstraintsStr + " UNION SELECT a.conname constraint_name, a.contype constraint_type, " +
                            "b.relname table_name, a.consrc search_condition, d.conname r_constraint_name, " +
                            "a.confdeltype delete_rule " +
                            "FROM pg_constraint a, pg_class b, pg_namespace c, pg_constraint d " +
                            "WHERE a.connamespace = c.oid AND a.conrelid = b.oid AND a.contype = 'f' " +
                            "AND a.confrelid = d.conrelid AND d.contype = 'p' AND c.nspname = ? ";

        if (commaSepTableNames != null){
            getConstraintsStr = getConstraintsStr + " AND b.relname IN (" + commaSepTableNames + ") ";
        }

        // query key_column_usage for contraint columns

        getConstraintColumnsStr = "SELECT column_name, ordinal_position \"position\", table_name " +
                                  "FROM information_schema.key_column_usage " +
                                  "WHERE table_schema = ? and constraint_name = ?";

        getConstraints  = conn.getConnection().prepareStatement(getConstraintsStr);
        getConstraintColumns  = conn.getConnection().prepareStatement(getConstraintColumnsStr);
    }

    protected void initIndexeStatement(String commaSepTableNames) throws SQLException {
        getIndexesStr = "SELECT b.relname index_name, c.relname table_name, indisunique uniqueness " +
                        "FROM pg_index a, pg_class b, pg_class c, pg_namespace d " +
                        "WHERE a.indisprimary = false AND a.indexrelid = b.oid AND a.indrelid = c.oid " +
                        "AND b.relnamespace = d.oid AND d.nspname = ? ";

        getIndexColumnsStr = "SELECT e.attname column_name, e.attnum column_position, c.relname table_name " +
                             "FROM pg_index a, pg_class b, pg_class c, pg_namespace d, pg_attribute e " +
                             "WHERE a.indexrelid = b.oid AND a.indrelid = c.oid " +
                             "AND b.relnamespace = d.oid AND d.nspname = ? " +
                             "AND a.indexrelid = e.attrelid AND b.relname = ? " +
                             "ORDER BY column_position ";

        if (commaSepTableNames != null){
            getIndexesStr = getIndexesStr + " AND c.relname IN (" + commaSepTableNames + ") ";
        }

        // skip Unique constraint based indexes
        getIndexesStr += " AND b.relname NOT IN (SELECT e.conname FROM pg_catalog.pg_constraint e, pg_class f, pg_namespace g " +
                        " WHERE e.connamespace = g.oid AND e.conrelid = f.oid AND g.nspname = d.nspname AND f.relname = c.relname and e.contype = 'u')";
        getIndexes  = conn.getConnection().prepareStatement(getIndexesStr);
        getIndexColumns  = conn.getConnection().prepareStatement(getIndexColumnsStr);
    }

    protected Table getTable(String TableName) throws SQLException {
        ResultSet rs = null;
        Table table = null;

        try {
            getColumns.setString(1, schema.getName());
            getColumns.setString(2, TableName);
            rs = getColumns.executeQuery();
            boolean colCaseSensitive = false;
//            boolean tabCaseSensitive = false;
            boolean isSimpleTableName = Utility.isValidPGIdentifier(TableName) ;

            //FB6400 - Since the current case-sensitive table name is used both for source and target
            // and Oracle doesn't allow a table name to start off with "_", so lets mark
            // such table as case-sensitive
            if (isCaseSensitive(TableName) || !isSimpleTableName || TableName.startsWith("_")) {
                TableName = "\"" + TableName + "\"" ;
            }

            while (rs.next()) {
                if (table == null)
                    table = new Table(schema, TableName, targetSchemaName);

                // check column case-sensitivity and enclose in double-quotes accordingly
                String colName = rs.getString("column_name");

                // see if it is a simple column name or needs double quoting
                boolean isSimpleColumnName = Utility.isValidPGIdentifier(colName) ;

                if (colCaseSensitive = isCaseSensitive(colName) || !isSimpleColumnName || colName.startsWith("_")) {
                    colName = "\"" + colName + "\"";
                }

                Column column = new Column(table, colName);
                String dataType = rs.getString("data_type");
                int dataLength = calculateEDBDataLength(dataType, rs.getInt("data_length"),
                                                    rs.getInt("data_precision"), rs.getInt("data_scale"));
                // if data_type is "interval", find the actual interval type mode i.e. month to year, day to sec etc.
                // so as to correctly map to corresponding Oracle type
                if (dataType.equalsIgnoreCase("INTERVAL")) {
                    dataType = rs.getString("ex_data_type");
                }

                column.addDetail(dataType, dataLength,
                        rs.getInt("data_precision"), rs.getInt("data_scale"),
                        rs.getString("nullable"), colCaseSensitive, rs.getString("data_default"), rs.getString("comments"));
                table.addColumn(column);
            }

        } catch (SQLException se) {
            throw se;
        }

        return table;
    }

    /**
     * This function calculates the data storage size for numeric types
     * since the dataLength attribute in information schema catalog belongs to
     * character types.
     */
    private int calculateEDBDataLength(String dataType, int dataLength, int dataPrecision, int dataScale) {
        if (dataType.equalsIgnoreCase("integer")) {
            // return max storage size for integer types
            return 8;
        } else if (dataType.equalsIgnoreCase("numeric")) {
            return dataPrecision;
        } else if (dataType.startsWith("timestamp")) {
            return 8;
        }

        return dataLength;
    }

    protected void getTables() throws SQLException {
        writeLog("Getting Table Definitions");
        ResultSet rs = null;

        try {
            getTables.setString(1, schema.getName());
            rs = getTables.executeQuery();

            while (rs.next()) {
                Table table = getTable(rs.getString("table_name"));
                if (table != null)
                    schema.addTable(table);
            }

        } catch (SQLException se) {
            throw se;
        }
    }

    protected void getProcedures() throws SQLException {
    }

    protected void getFunctions() throws SQLException {
    }

    protected void getViews() throws SQLException {
    }

    protected void getPublicSynonyms() throws SQLException {
    }

    protected void getTriggers() throws SQLException {
    }

    protected void getSequences() throws SQLException {
    }

    protected void getPackages() throws SQLException {
    }

    protected void getConstraints() throws SQLException {
        getConstraints.setString(1, schema.getName());
        getConstraints.setString(2, schema.getName());
        super.getConstraints();
    }

    protected void setConstraintColumnsPSParams(Constraint constraint) throws SQLException {
        getConstraintColumns.setString(1, schema.getName());
        getConstraintColumns.setString(2, constraint.getName());
    }


    protected void getIndexes() throws SQLException {
        writeLog("Getting Index Definitions");
        ResultSet rs = null;
        ResultSet irs = null;
        
        try {
            getIndexes.setString(1, schema.getName());
            rs = getIndexes.executeQuery();

            while (rs.next()) {
                Index index = new Index(rs.getString("table_name"),
                        rs.getString("index_name"));
                String indexUniqueness = rs.getBoolean("uniqueness") ? "UNIQUE" : "NONUNIQUE";
                index.setUniqueness(indexUniqueness);

                getIndexColumns.setString(1, schema.getName());
                getIndexColumns.setString(2, index.getName());
                irs = getIndexColumns.executeQuery();
                while (irs.next()) {
                    index.addColumn(new Column(irs.getString("column_name")));
                }
                
                irs.close();
                
                if (index != null)
                    schema.addIndex(index);
            }

        } catch (SQLException se) {
            throw se;
        } finally {
            if (irs != null) {
                irs.close();
            }

            if (rs != null) {
                rs.close();
            }
        }
    }

    // for backward compatibity reasons we need to find if the DB version supports synonyms
    public boolean supportsSynonyms() {
        String sql = "select count(*) from pg_tables where tablename = 'pg_synonym'" ;
        try {
            Statement stmt= conn.getConnection().createStatement() ;
            ResultSet rs = stmt.executeQuery(sql);
            rs.next() ;
            int i = rs.getInt(1) ;
            if (i > 0)
                return true ;
        }catch (Exception e) {
            e.printStackTrace(new PrintWriter(Logger.getInstance(),true));
            //Logger.getInstance().printErrorLn(""+e);
        }
        return false;
    }

    // Need to get Server Version to support version specific features.
    public String getVersion() throws SQLException {

            String sql="select version()" ;
            Statement stmt=conn.getConnection().createStatement() ;
            ResultSet rs = stmt.executeQuery(sql) ;
            rs.next() ;
            return(rs.getString(1)) ;
    }

    /*
     * This function checks if an identifier name is case-sensitive in the
     * EnterpriseDB database.
     * @return A boolean value of true if case-sensitive otherwise false.
     */
    public boolean isCaseSensitive(String identifierName) {
        if (!identifierName.equals(identifierName.toLowerCase())  ||
            !Utility.isValidPGIdentifier(identifierName)) {
            return true;
        }

        return false;

    }

    /**
     * This method restore the table indexes by loading the definitions from
     * in the memory and drops each of the indexes for the given table from the database.
     *
     */
    @SuppressWarnings("unchecked")
	public void restoreTableIndexesDefs(Table table) throws SQLException {
        // load the indexes definition from in-memory map structure
        ArrayList<String> listTableIndexesDefs = mapTableIndexesDefs.get(table.getTargetSchemaQualifiedName());

        // restore (re-create) the indexes in the database
        if (listTableIndexesDefs != null) {
            for (String tableIndexesDefs: listTableIndexesDefs) {
                executeScript(tableIndexesDefs);
            }
        }
    }

    /**
     * This method loads the table indexes definition (DDL) from EnterpriseDB pg_indexes
     * view for a given schema and table. If createBackup is true, it creates a backup
     * in the memory and then drops each index for the given table from the database.
     *
     * @return An ArrayList that contains index definitions for all the indexes in the table.
     */
    protected ArrayList<String> dropTableIndexesDefs(Table table, boolean createBackup) throws SQLException {
        ResultSet rs = null;
        ArrayList<String> listTableIndexesDefs = null;
        
        if (createBackup) {
            listTableIndexesDefs = new ArrayList<String>();
        }


        try {
            // if psIndexDefs is not initialized yet, do it now
            if (psIndexesDefs == null) {
                psIndexesDefs = conn.getConnection().prepareStatement(sqlIndexesDefs);
            } else {
                psIndexesDefs.clearParameters();
            }

            psIndexesDefs.setString(1, Utility.removeEnclosingQuotes(table.getTargetSchemaName()));
            psIndexesDefs.setString(2, Utility.removeEnclosingQuotes(table.getEDBCompatibleName()));
            rs = psIndexesDefs.executeQuery();

            String targetSchemaName = table.getTargetSchemaName();
            if (isCaseSensitive(targetSchemaName)) {
                targetSchemaName = "\"" + targetSchemaName + "\"";
            }

            while (rs.next()) {
                String indexName = rs.getString(1);
                // save index construction defintion in list
                if (createBackup) {
                    listTableIndexesDefs.add(rs.getString(2));
                }

                if (isCaseSensitive(indexName)) {
                    indexName = "\"" + indexName + "\"";
                }
                // drop the index from the database
                executeScript("DROP INDEX " + targetSchemaName+ "." + indexName + " CASCADE");
            }

            if (createBackup && listTableIndexesDefs.size() > 0) {
                // save in the in-memory structure
                mapTableIndexesDefs.put(table.getTargetSchemaQualifiedName(), listTableIndexesDefs);
            }

            return listTableIndexesDefs;
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }

    /**
     * This method drops all constraints for the given table from the database.
     *
     */
    protected void dropTableConsts(MTKConstants.DATABASE_TYPE sourceDBType, Table table) throws SQLException {
        ResultSet rs = null;

        try {

            // if psIndexDefs is not initialized yet, do it now
            if (psConsts == null) {
                psConsts = conn.getConnection().prepareStatement(sqlConsts);
            } else {
                psConsts.clearParameters();
            }

            psConsts.setString(1, Utility.removeEnclosingQuotes(table.getTargetSchemaName()));
            psConsts.setString(2, Utility.removeEnclosingQuotes(table.getEDBCompatibleName()));
            rs = psConsts.executeQuery();

            while (rs.next()) {
                String constName = rs.getString(1);

                if (isCaseSensitive(constName)) {
                    constName = "\"" + constName + "\"";
                }
                // drop the constraint from the database
                executeScript("ALTER TABLE " + table.getTargetSchemaFullyQualifiedName(sourceDBType, MTKConstants.DATABASE_TYPE.POSTGRESQL,false) + " DROP CONSTRAINT " + constName);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }

    /**
     * This method drops constraints and indexes for the given table from the database.
     */
    public void dropTableConstsAndIndexes(MTKConstants.DATABASE_TYPE sourceDBType, Table table) throws SQLException {
        // first drop table constraints
        this.dropTableConsts(sourceDBType, table);
        // drop table indexes
        this.dropTableIndexesDefs(table, false);
    }

}
