/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * PostgreSQLTransformDDL.java
 *
 * Created on September 12, 2006, 3:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.dbhandler.postgresql;

import com.enterprisedb.mtk.common.MTKTransformDDL;
import com.enterprisedb.mtk.schema.metadata.Column;
import com.enterprisedb.mtk.schema.metadata.Constraint;
import com.enterprisedb.mtk.schema.metadata.Function;
import com.enterprisedb.mtk.schema.metadata.Index;
import com.enterprisedb.mtk.schema.metadata.Procedure;
import com.enterprisedb.mtk.schema.metadata.PublicSynonym;
import com.enterprisedb.mtk.schema.metadata.Table;
import com.enterprisedb.mtk.schema.metadata.Trigger;

/**
 * This class transforms EDB meta data information and generates DDL scripts for 
 * execution in a target EDB database.
 *
 * @author zahid
 */
public class PostgreSQLTransformDDL extends MTKTransformDDL {
    
    /** Creates a new instance of PostgreSQLTransformDDL */
    public PostgreSQLTransformDDL() {
    }

    public String getCreateScript(Table table) {
        String sql = super.getCreateScript(table);
        sql = sql + ";\n";
        return sql;
    }
    
    protected String getColumnLine(Column column) {
        String str = "";
        String colName = column.getName();
        
        // check if column name contains special char, enclose it in double-quotes
        if (!column.isCaseSensitive() && colName.indexOf('#') >= 0) {
            colName = "\"" + colName.toLowerCase() + "\"";
        }
        
        str = str + getIndent() + colName + 
              " " + column.getDataTypeString();
        
        if ((column.getDataType() == Column.DataType.VARCHAR || column.getDataType() == Column.DataType.NVARCHAR) &&
             column.getLength() > 0)
            str = str + "(" + column.getLength() + ")";
                
        if ((column.getDataType() == Column.DataType.INTEGER && 
             !column.getDataTypeString().equalsIgnoreCase("INTEGER") && !column.isSmallint()) ||
              (column.getDataType() == Column.DataType.NUMERIC && !column.isReal())) {
            if (column.getPrecision() > 0) {
                str = str + "(" + column.getPrecision();
                if (column.getScale() > 0)
                    str = str + "," + column.getScale();
                str = str + ")";
            }
        }
        
        // define default clause if it's not null
        if (column.getDefaultClause() != null) {
            str += " DEFAULT " + column.getDefaultClause();
        }
        
        if (!column.isNullable())
            str = str + " NOT NULL";
        
        return str;
    }    
    
    public String getCreateScript(Constraint constraint) {
        String sql = "";
        String constraintType = String.valueOf(constraint.getType());
        
        if (constraintType.equalsIgnoreCase("P")) {
            sql = sql + "ALTER TABLE " + constraint.getTableName() + 
                    " ADD CONSTRAINT " + constraint.getName(true) + " PRIMARY KEY (";
            for (int i = 0; i < constraint.getColumns().size(); i++) {
                sql = sql + constraint.getColumns().get(i).getName();
                if (i < constraint.getColumns().size()-1)
                    sql = sql + ", ";
            }
            sql = sql + ");\n";
        } else if (constraintType.equalsIgnoreCase("U")) {
            sql = sql + "ALTER TABLE " + constraint.getTableName() + 
                    " ADD CONSTRAINT " + constraint.getName(true) + " UNIQUE (";
            for (int i = 0; i < constraint.getColumns().size(); i++) {
                sql = sql + constraint.getColumns().get(i).getName();
                if (i < constraint.getColumns().size()-1)
                    sql = sql + ", ";
            }
            sql = sql + ");\n";
        } else if (constraintType.equalsIgnoreCase("C")) {
            // Skip "is not null" constraints since they are already appliead
            // at table creation time
            if (!constraint.getSearchCondition().endsWith("IS NOT NULL")) {
                sql = sql + "ALTER TABLE " + constraint.getTableName() + 
                        " ADD CONSTRAINT " + constraint.getName(true) + " CHECK (" +
                        constraint.getSearchCondition();
                sql = sql + ");\n";
            }
        } else if (constraintType.equalsIgnoreCase("R")) {
            sql = sql + "ALTER TABLE " + constraint.getTableName() + 
                    " ADD CONSTRAINT " + constraint.getName(true) + " FOREIGN KEY (";
            for (int i = 0; i < constraint.getColumns().size(); i++) {
                sql = sql + constraint.getColumns().get(i).getName();
                if (i < constraint.getColumns().size()-1)
                    sql = sql + ", ";
            }
            sql = sql + ") REFERENCES " + constraint.getRefIntegrityTable() + " ("; 
            for (int i = 0; i < constraint.getRefIntegrityColumns().size(); i++) {
                sql = sql + constraint.getRefIntegrityColumns().get(i).getName();
                if (i < constraint.getRefIntegrityColumns().size()-1)
                    sql = sql + ", ";
            }            
            sql = sql + ") MATCH FULL ON DELETE " + constraint.getDeleteRule() + ";\n";
        }        
        return sql;
    }

    public String getCreateScript(Index index) {
        String sql = "";

        // Only create non-unique indexes since they are already created
        // as a unique constraint
        if (!index.isUnique()) {
            sql = sql + "CREATE INDEX " + index.getName() + " ON " + 
                    index.getTableName() + " (";
            for (int i = 0; i < index.getColumns().size(); i++) {
                sql = sql + index.getColumns().get(i).getName();
                if (i < index.getColumns().size()-1)
                    sql = sql + ", ";
            }            
            sql = sql + ");\n";            
        }
        
        return sql;
    }
    
    public String getCreateScript(Trigger trigger) {
        // TODO - provide the handling after initial testing
        String sql = "";
        return sql;
    }
    
    public String getCreateScript(PublicSynonym syn) {
    	return null;
    }
    
    public String getCreateScript(Procedure proc) {
    	return null;
    }

    public String getCreateScript(Function func) {
    	return null;
    }
      
    public String getCreateScriptPackageSpec(com.enterprisedb.mtk.schema.metadata.Package pack) {
    	return null;
    }

    public String getCreateScriptPackageBody(com.enterprisedb.mtk.schema.metadata.Package pack) {
    	return null;
    }        
}