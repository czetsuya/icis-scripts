/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * PublicSynonym.java
 *
 * Created on May 23, 2006, 8:05 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author usama
 */
public class PublicSynonym {
    private String synname ;
    private String synowner; 
    private String synobjname;
    /**
     * Creates a new instance of PublicSynonym
     */
    public PublicSynonym() {
    }    

    public String getSynname() {
        return synname;
    }

    public void setSynname(String synname) {
        this.synname = synname;
    }

    public String getSynowner() {
        return synowner;
    }

    public void setSynowner(String synowner) {
        this.synowner = synowner;
    }

    public String getSynobjname() {
        return synobjname;
    }

    public void setSynobjname(String synobjname) {
        this.synobjname = synobjname;
    }
 
    
}
