/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * SequenceList.java
 *
 * Created on March 8, 2006, 12:40 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class SequenceList {
    private ArrayList<Sequence> list = null;
    
    /** Creates a new instance of SequenceList */
    public SequenceList() {
    }

    public void add(Sequence sequence) {
        if (list == null) 
            list = new ArrayList<Sequence>();
        
        list.add(sequence);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Sequence get(int index) {
        return (Sequence) list.get(index);
    }
    
}
