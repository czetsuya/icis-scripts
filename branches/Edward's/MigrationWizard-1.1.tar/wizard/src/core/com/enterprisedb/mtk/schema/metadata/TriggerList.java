/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * TriggerList.java
 *
 * Created on March 7, 2006, 10:12 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class TriggerList {
    private ArrayList<Trigger> list = null;
    
    /** Creates a new instance of TriggerList */
    public TriggerList() {
    }

    public void add(Trigger trigger) {
        if (list == null) 
            list = new ArrayList<Trigger>();
        
        list.add(trigger);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Trigger get(int index) {
        return (Trigger) list.get(index);
    }
    
}
