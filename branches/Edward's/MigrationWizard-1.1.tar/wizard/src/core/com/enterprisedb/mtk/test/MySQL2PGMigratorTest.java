package com.enterprisedb.mtk.test;

import com.enterprisedb.mtk.ConnectionProps;
import com.enterprisedb.mtk.MigrationProps;
import com.enterprisedb.mtk.MigrationToolkit;
import com.enterprisedb.mtk.MigrationProps.MigrationType;

import junit.framework.TestCase;

public class MySQL2PGMigratorTest extends TestCase {
	
	MigrationToolkit mtk = null;
	MigrationProps mtkProps = null;
	ConnectionProps sourceProps = null;
	ConnectionProps targetProps = null;
	String[] schemas = null;
	String[] tables = null;		
	String defaultDateTime = null;
	MigrationType migrationType = null;
	boolean migrateConstraints;
	boolean recreateSchema;

    public MySQL2PGMigratorTest(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
		
    	sourceProps = new ConnectionProps("jdbc:mysql://localhost:3306/test","root","root");
		targetProps = new ConnectionProps("jdbc:edb://localhost:5432/postgres","postgres","edb");

		schemas = new String[1];
		schemas[0] = "sugercrm";
		
		tables = new String[5];
		tables[0] = "sugercrm.accounts";
		tables[1] = "sugercrm.accounts_audit";
		tables[2] = "sugercrm.accounts_bugs";
		tables[3] = "sugercrm.accounts_cases";
		tables[4] = "sugercrm.accounts_contacts";
		
		defaultDateTime = "2007-01-01";
		migrationType =  MigrationType.FULL_MIGRATION;
		migrateConstraints = true;
		recreateSchema = true;
    }

    protected void tearDown() throws Exception {
    	sourceProps = null;
    	targetProps = null;
    	schemas = null;
    	tables = null;		
    	defaultDateTime = null;
    	migrationType = null;
    }

	public void testMigration() throws Exception{
		mtkProps = new MigrationProps(sourceProps, targetProps,schemas,tables,defaultDateTime, migrationType, migrateConstraints, recreateSchema);
		mtk = new MigrationToolkit(mtkProps);
		mtk.startMigration();
	}
}
