/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * CLParser.java
 *
 * Created on March 24, 2006, 10:39 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/**
 *
 * @author zahid
 */
public class CLParser {
    private Hashtable<String, String> optionsList = new Hashtable<String, String>();
    private Vector paramsList = new Vector();
//    private int optionIndex = 0;
    private int paramIndex = 0;
    
    /** Creates a new instance of CLParser */
    public CLParser() {
        
    }
    
    public boolean parseArgs(String[] args) {
        String optName = null;
//        String optValue = null;
        boolean invalidArgs = false;
        
        for (int i = 0; i < args.length; i++) {
            if (args[i].startsWith("--")) {
                invalidArgs = true;
                break;
            } else if (args[i].startsWith("-")) {
                optName = args[i].substring(1);
                optionsList.put(optName.toLowerCase(), "");
            } else {
                // if the value is not followed by an option and it's
                // not the last argument that represents schema name, it is invalid.
                if (optName == null) {
                    if (i < args.length - 1) {
                        invalidArgs = true;
                    }
                    break;
                }
                
                optionsList.put(optName.toLowerCase(), args[i]);
                optName = null;
            }
        }
        
        return (!invalidArgs);
    }
    
    public boolean hasOption(String optName) {
        return optionsList.containsKey(optName.toLowerCase());
    }
    
    public String getOption(String optName) {
        return (String) optionsList.get(optName.toLowerCase());
    }
    
    public String nextOption(String optName) {
        return (String) optionsList.get(optName.toLowerCase());
    }
    
    public Enumeration getOptionNames() {
        return optionsList.keys();
    }
    public String nextParam() {
        if (paramIndex < paramsList.size()) {
            return (String) paramsList.elementAt(paramIndex++);
        }
        return null;
    }
    
}
