/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Utility.java
 *
 * Created on June 19, 2006, 11:43 AM
 *
 */

package com.enterprisedb.mtk;

import com.enterprisedb.mtk.common.MTKConstants;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Properties;
import java.sql.SQLException;

/**
 * This class provides utility functions that are used across the all the application
 * classes. This class is non-instantiable and each method is accessible at class level.
 *
 * @author zahid
 */
public class Utility {

    /**
     * Usama : This is a regular expression for a valid PG Identifier
     * according to PostgreSQL documentation a valid identifier is
     * - Must begin with a letter or an underscore
     * - Can contain A-Z;a-z;0-9 ,_ or $ and # (Zahid: though not documented but # can also be part of valid identifier)
     * we will enclose in double quotes anytime the column name doesnt meet this criteria
     */
    private static String validPGIdentifierPattern = "^[a-zA-Z_]([a-zA-Z0-9_$#])*+$" ;

    /** Since this class provides static methods, so prevent any instantiation
     * of this class via private access modifier.
     */
    private Utility() {
    }

    /**
     * It formats a given java.util.Date using the specified format pattern. If
     * formatPattern is null, then the default date pattern is used.
     */
    public static String formatDate(java.util.Date date, String formatPattern) {
        if (formatPattern == null) {
            formatPattern = "MMM dd, yyyy hh:mm:ss";
        }

        SimpleDateFormat sdf = new SimpleDateFormat(formatPattern);

        return (sdf.format(date));
    }

    /**
     * It saves a properties list in a file.
     */
    public static void saveProperties(Properties prop, String propComments, String filePath) throws FileNotFoundException, IOException {
        FileOutputStream fos = new FileOutputStream(System.getProperty("user.home") + File.separator + filePath);
        prop.store(fos, propComments);
        fos.close();
    }
    // Check if the passed parameter is a valid PG Identifier
    public static boolean isValidPGIdentifier(String Identifier) {
        boolean isValidId = Identifier.matches(validPGIdentifierPattern) ;
        return(isValidId) ;
    }

    /*
     * This function checks if an identifier name is case-sensitive for the
     * given database.
     * @return A boolean value of true if case-sensitive otherwise false.
     */
    public static boolean isCaseSensitive(String identifierName, MTKConstants.DATABASE_TYPE dbType) {
        if (identifierName == null)
            return false;
        switch (dbType) {
            case POSTGRESQL:
                if (!identifierName.equals(identifierName.toLowerCase())  ||
                    !Utility.isValidPGIdentifier(identifierName)) {
                    return true;
                }
                break;
            default:
                return false;
        }
        return false;
    }
    
    public static String getValidFileNamePrefixFor(String schemaName, String tableName) {
        String fileNamePrefix = schemaName +"."+ tableName ;
        //
        // Remove all invalid characters which are considered invalid when any one of them are part of
        // a file name.
        //
        fileNamePrefix = fileNamePrefix.replaceAll("\\\\", "");
        fileNamePrefix = fileNamePrefix.replaceAll("/", "");
        fileNamePrefix = fileNamePrefix.replaceAll(":", "");
        fileNamePrefix = fileNamePrefix.replaceAll("\\?", "");
        fileNamePrefix = fileNamePrefix.replaceAll("\\\"", "");
        fileNamePrefix = fileNamePrefix.replaceAll("<", "");
        fileNamePrefix = fileNamePrefix.replaceAll(">", "");
        fileNamePrefix = fileNamePrefix.replaceAll("\\|", "");
        return fileNamePrefix;
    }

    /**
     * Escapes identifier with appropriate escape character, if required
     * otherwise doesn't change identifier.
     *
     * @param identifierName String
     * @param dbType DATABASE_TYPE
     * @return String
     */
    public static String escape(String identifierName, MTKConstants.DATABASE_TYPE dbType) {
        String value = identifierName;
        switch (dbType) {
        case POSTGRESQL:
            if (isCaseSensitive(identifierName, dbType)) {
                if (!identifierName.startsWith("\"") && !identifierName.endsWith("\"")) {
                    value = "\"" + value + "\"";
                }
            }
            break;
        case MYSQL:
            value = "`"+value+"`";
            break;
        }
        return value;
    }

    /*
     * This function converts the given identifierName to the default case
     * for the target database.
     * @return A String value representing the identifier name.
     */
    public static String convertToDefaultCase(String identifierName, MTKConstants.DATABASE_TYPE targetDbType) {
        switch (targetDbType) {
            case POSTGRESQL:
                return identifierName.toLowerCase();
            default:
                return identifierName;
        }

    }

    /**
     * Removes stack trace from the exception. MySQL driver prints stack trace
     * in message of exception.
     *
     * @param exp SQLException
     * @return SQLException
     */
    public static SQLException processException(Exception exp) {
        String message = exp.getMessage();
        if (message.indexOf("STACKTRACE:") > 0) {
            message = message.substring(0, message.indexOf("STACKTRACE:"));
        }
        return new SQLException(message);
    }
    
    /**
     * This method removes enclosing quotes from the identifier name. If there are
     * no enclosing quotes, the name is returned unchanged.
     */
    public static String removeEnclosingQuotes(String identifierName) {
        String nonQuotedName = identifierName;
        
        if (nonQuotedName.substring(0,1).equals("\"")) {
            // trim off enclosing quotes
            nonQuotedName = nonQuotedName.replaceFirst("\"", "");
            nonQuotedName = nonQuotedName.substring(0, nonQuotedName.length()-1);
        }        
        return nonQuotedName;
    }   
}