/**
 * 
 */
package com.enterprisedb.mtk.util;

import java.io.IOException;
import java.io.OutputStream;
import javax.swing.JTextArea;

/**
 * @author amir
 *
 */
public class Logger extends OutputStream {
    
	private Logger(){
            super();
        }
    
	private JTextArea textArea = null;
        private static Logger logger = null;
        
        public static Logger getInstance() {
            if(logger == null)
                logger = new Logger();
            return logger;
        }
	
	public void print(String output){
		if (textArea != null){
			textArea.append(output);
                        textArea.validate();
		}else{
			System.out.print(output);
		}
	}

	public void println(String output){
		print(output+System.getProperty("line.separator"));
	}

	public void printError(String error){
		if (textArea != null){
			textArea.append(error);
		}else{
			System.err.print(error);
		}
	}

	public void printErrorLn(String error){
		printError(error+System.getProperty("line.separator"));
	}
	
	public void setTextArea(JTextArea textArea) {
		this.textArea = textArea;
	}

        public void write(int b) throws IOException {
            write(new byte[]{(byte)b});
        }

        public void write(byte[] b) throws IOException {
            print(new String(b));
        }   
    

}
