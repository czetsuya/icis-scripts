/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKBridge.java
 *
 * Created on August 31, 2006, 11:43 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import com.enterprisedb.mtk.schema.metadata.Table;

/**
 *
 * @author zahid
 */
abstract public class MTKBridge {
    protected static IMTKConnection srcConn = null;
    protected static IMTKConnection targetConn = null;
    // it represents the data size in bytes of the last data chunk (1 or more rows) migrated
    protected long lastMigratedDataSize = 0;
    abstract public long setTableData(Table table, int batchSize) throws Exception;
    abstract public long setTableDataInSafeMode(Table table) throws Exception;
    
    /**
     * Creates a new instance of MTKBridge
     */
    public MTKBridge(IMTKConnection srcConn, IMTKConnection targetConn) {
    	MTKBridge.srcConn = srcConn;
    	MTKBridge.targetConn = targetConn;
    }

    /**
     * It returns the data size in bytes of the rows that are migrated via last
     * call to setTableData(). If no data was migrated, zero is returned.
     * NOTE: To avoid any performance loss, the data size calculation accomodates only
     * text/binary type attributes (where size is readily available) and skips size calculation
     * for other types.
     *
     * @return A long value representing data size in bytes.
     */
    public long getLastMigratedDataSize() {
        return lastMigratedDataSize;
    }
    
}
