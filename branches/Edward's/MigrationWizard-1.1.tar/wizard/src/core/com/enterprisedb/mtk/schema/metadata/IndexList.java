/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * IndexList.java
 *
 * Created on March 10, 2006, 8:08 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class IndexList {
    private ArrayList<Index> list = null;
    
    /** Creates a new instance of IndexList */
    public IndexList() {
    }

    public void add(Index index) {
        if (list == null) 
            list = new ArrayList<Index>();
        
        list.add(index);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Index get(int indexNum) {
        return (Index) list.get(indexNum);
    }
    
    public void clear() {
        if (list != null) {
            list.clear();
        }
    }
    
}
