/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKMetaData.java
 *
 * Created on August 31, 2006, 11:53 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import com.enterprisedb.mtk.MTKException;
import com.enterprisedb.mtk.schema.metadata.Column;
import com.enterprisedb.mtk.schema.metadata.Constraint;
import com.enterprisedb.mtk.schema.metadata.Schema;
import com.enterprisedb.mtk.schema.metadata.Table;
import com.enterprisedb.mtk.util.Logger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author zahid
 */
abstract public class MTKMetaData {
    protected Schema schema = null;
    protected Connection dbConn = null;
    protected PreparedStatement getTables;
    protected PreparedStatement getColumns;
    protected PreparedStatement getProcs;
    protected PreparedStatement getViews;
    protected PreparedStatement getTriggers;
    protected PreparedStatement getSequences;
    protected PreparedStatement getPackages;
    protected PreparedStatement getConstraints;
    protected PreparedStatement getConstraintColumns;
    protected PreparedStatement getIndexes;
    protected PreparedStatement getIndexColumns;
    protected PreparedStatement getPublicSynonyms;

    protected String getTablesStr = null;
    protected String getColumnsStr = null;
    protected String getProcsStr = null;
    protected String getViewsStr = null;
    protected String getTriggersStr = null;
    protected String getSequencesStr = null;
    protected String getPackagesStr = null;
    protected String getConstraintsStr = null;
    protected String getConstraintColumnsStr = null;
    protected String getIndexesStr = null;
    protected String getIndexColumnsStr = null;
    protected String getPublicSynonymStr = null;

    protected String targetSchemaName = null;
    protected boolean debugFlag = false;
    protected static PrintStream out = null;
    protected static FileOutputStream fout = null;

    /** Creates a new instance of MTKMetaData */
    public MTKMetaData() throws Exception {
        try {
            fout = new FileOutputStream(System.getProperty("user.home") + File.separator + "MigrationToolkit.log");
            out = new PrintStream(fout);
        } catch (Exception ex) {
            throw ex;
        }
    }

    abstract public boolean supportsSynonyms();
    abstract public String getVersion() throws SQLException;
    abstract protected void initPublicSynonymStatement(String commaSepSynNames) throws SQLException;
    abstract protected void initTableStatement(String commaSepTableNames) throws SQLException;
    abstract protected void initColumnStatement() throws SQLException;
    abstract protected void initTriggerStatement(String commaSepTableNames) throws SQLException;
    abstract protected void initViewStatement(String commaSepViewNames) throws SQLException;
    abstract protected void initSequenceStatement(String commaSepSequenceNames) throws SQLException;
    abstract protected void initProcStatement(String commaSepProcNames) throws SQLException;
    abstract protected void initPackageStatement(String commaSepPackageNames) throws SQLException;
    abstract protected void initConstraintStatement(String commaSepTableNames) throws SQLException;
    abstract protected void initIndexeStatement(String commaSepTableNames) throws SQLException;
    abstract protected void getTables() throws SQLException;
    abstract protected void getProcedures() throws SQLException;
    abstract protected void getFunctions() throws SQLException;
    abstract protected void getViews() throws SQLException;
    abstract protected void getPublicSynonyms() throws SQLException;
    abstract protected void getTriggers() throws SQLException;
    abstract protected void getSequences() throws SQLException;
    abstract protected void getPackages() throws SQLException;
    abstract protected void getIndexes() throws SQLException;
    abstract protected Table getTable(String TableName) throws SQLException;
    /*
     * This function checks if an identifier name is case-sensitive in the
     * relavant database.
     * @return A boolean value of true if case-sensitive otherwise false.
     */
    abstract public boolean isCaseSensitive(String identifierName);

    protected void writeLog(String str) {
        if (debugFlag)
            Logger.getInstance().println(str);
    }

    private void initPreparedStatments() throws Exception{
        try {
            initTableStatement(null);
            initColumnStatement();
            initProcStatement(null);
            initViewStatement(null);
            initTriggerStatement(null);
            initSequenceStatement(null);
            initPackageStatement(null);
            initConstraintStatement(null);
            initIndexeStatement(null);
            initPublicSynonymStatement(null);
        } catch (Exception ex) {
            throw ex;
        }
    }

    private String getCommaSepStr(String[] strArray) throws SQLException {
        StringBuffer commaSepStr = new StringBuffer();

        for (int i = 0; i < strArray.length; i++) {

            if (i > 0) {
                commaSepStr.append(",");
            }

            commaSepStr.append(strArray[i]);
        }

        return commaSepStr.toString();
    }

    /**
     * This method loads meta data information for all of the schema objects.
     *
     */
    private void getSchemaMetaData() throws Exception {
        initPreparedStatments();

        getTables();
        getProcedures();
        getFunctions();
        getViews();
        getTriggers();
        getSequences();
        getPackages();
        getConstraints();
        getIndexes();
    }

    public Schema getSchema() {
        return schema;
    }

    public void getTables(String[] tableNames, boolean importViewAsTable) throws SQLException {
        String commaSepTableNames =  getCommaSepStr(tableNames);
        getTables(commaSepTableNames, importViewAsTable);
    }

    public void getTables(String commaSepTableNames, boolean importViewAsTable) throws SQLException {
        initTableStatement(commaSepTableNames);
        initColumnStatement();
        getTables();
    }

    public void getAllTables() throws SQLException {
        initTableStatement(null);
        initColumnStatement();
        getTables();
    }


    public void getProcedures(String[] procNames) throws SQLException {
        String commaSepProcNames = getCommaSepStr(procNames);
        getProcedures(commaSepProcNames);
    }

    public void getProcedures(String commaSepProcNames) throws SQLException {
        initProcStatement(commaSepProcNames);
        getProcedures();
    }

    public void getAllProcedures() throws SQLException {
        initProcStatement(null);
        getProcedures();
    }


    public void getFunctions(String[] funcNames) throws SQLException {
        String commaSepFuncNames = getCommaSepStr(funcNames);
        getFunctions(commaSepFuncNames);
    }

    public void getFunctions(String commaSepFuncNames) throws SQLException {
        initProcStatement(commaSepFuncNames);
        getFunctions();
    }

    public void getAllFunctions() throws SQLException {
        initProcStatement(null);
        getFunctions();
    }


    public void getViews(String[] viewNames) throws SQLException {
        String commaSepViewNames = getCommaSepStr(viewNames);
        getViews(commaSepViewNames);
    }

    public void getViews(String commaSepViewNames) throws SQLException {
        initViewStatement(commaSepViewNames);
        getViews();
    }

    public void getAllViews() throws SQLException {
        initViewStatement(null);
        getViews();
    }

    public void getPublicSynonyms(String[] tableNames) throws SQLException {
        String commaSeptabNames = getCommaSepStr(tableNames);
        getPublicSynonyms(commaSeptabNames) ;
    }

    public void getPublicSynonyms(String commaSepSynNames) throws SQLException {
        initPublicSynonymStatement(commaSepSynNames) ;
        getPublicSynonyms() ;
    }


    public void getTriggers(String[] tableNames) throws SQLException {
        String commaSepTableNames = getCommaSepStr(tableNames);
        getTriggers(commaSepTableNames);
    }

    public void getTriggers(String commaSepTableNames) throws SQLException {
        initTriggerStatement(commaSepTableNames);
        getTriggers();
    }

    public void getAllTriggers() throws SQLException {
        initTriggerStatement(null);
        getTriggers();
    }

    public void getSequences(String[] sequenceNames) throws SQLException {
        String commaSepSequenceNames = getCommaSepStr(sequenceNames);
        getSequences(commaSepSequenceNames);
    }

    public void getSequences(String commaSepSequenceNames) throws SQLException {
        initSequenceStatement(commaSepSequenceNames);
        getSequences();
    }

    public void getAllSequences() throws SQLException {
        initSequenceStatement(null);
        getSequences();
    }

    protected void getConstraints() throws SQLException {
        writeLog("Getting Constraint Definitions");
        ResultSet rs = null;
        ResultSet crs = null;
        ResultSet fkrs = null;
        
        try {
            rs = getConstraints.executeQuery();
            //Zahid: FB6196, if Oracle table is created using "create table tablename of type"
            // syntax, Oracle creates a unique constraint that is based on sys col e.g. SYS_NC_OID$ column
            // that will not be available in EnterpriseDB. Hence skip such constraint from migration.
            boolean skipSysColBasedConst = false;

            while (rs.next()) {
                skipSysColBasedConst = false;

                boolean consNameCaseSensitive = isCaseSensitive(rs.getString("constraint_name"));
                Constraint constraint = new Constraint(rs.getString("table_name"),
                        rs.getString("constraint_name"), consNameCaseSensitive);
                constraint.setType(rs.getString("constraint_type").charAt(0));
                constraint.setSearchCondition(rs.getString("search_condition"));
                constraint.setDeleteRule(rs.getString("delete_rule")) ;

//                getConstraintColumns.setString(1, schema.getName());
//                getConstraintColumns.setString(2, constraint.getName());
                setConstraintColumnsPSParams(constraint);
                crs = getConstraintColumns.executeQuery();
                while (crs.next()) {
                    // fix for where a constraint on case-sensitive column is not migrated
                    String constColumn = crs.getString("column_name");

                    // check if constColumn is Oracle system generated column e.g. SYS_NC_OID$
                    try {
                        if (!schema.hasTableColumn(constraint.getTableName(), constColumn)) {
                            skipSysColBasedConst = true;
                            break;
                        }
                    // in case table metadata information is not available, ignore the check
                    } catch (MTKException mtke) {
                    }

                    // check if column name needs double quoting
                    if (isCaseSensitive(constColumn)) {
                        constColumn = "\"" + constColumn + "\"";
                    }

                    constraint.addColumn(new Column(constColumn));
                }
                
                crs.close();
                
                String refConstName = rs.getString("r_constraint_name");
                if (!rs.wasNull()) {
                    getConstraintColumns.setString(2, refConstName);
                    fkrs = getConstraintColumns.executeQuery();
                    while (fkrs.next()) {
                        constraint.setRefIntegrityTable(fkrs.getString("table_name"));
                        constraint.addRefIntegrityColumn(new Column(fkrs.getString("column_name")));
                    }                    
                    fkrs.close();
                }
                if (constraint != null && !skipSysColBasedConst) {
                    schema.addConstraint(constraint);
                }
            }
        } catch (SQLException se) {
            throw se;
        } finally {
            if (fkrs != null) {
                fkrs.close();
            }
            
            if (crs != null) {
                crs.close();
            }

            if (rs != null) {
                rs.close();
            }
        }
    }

    abstract protected void setConstraintColumnsPSParams(Constraint constraint) throws SQLException;

    public void getPackages(String[] packageNames) throws SQLException {
        String commaSepPackageNames = getCommaSepStr(packageNames);
        getSequences(commaSepPackageNames);
    }

    public void getPackages(String commaSepPackageNames) throws SQLException {
        initPackageStatement(commaSepPackageNames);
        getPackages();
    }

    public void getAllPackages() throws SQLException {
        initPackageStatement(null);
        getPackages();
    }

    public void getConstraints(String[] tableNames) throws SQLException {
        String commaSepTableNames = getCommaSepStr(tableNames);
        getConstraints(commaSepTableNames);
    }

    public void getConstraints(String commaSepTableNames) throws SQLException {
        try {
            initConstraintStatement(commaSepTableNames);
            getConstraints();
        } finally {
            // fix for too many cursors open, close ps objects
            closeConstraintStatement();   
        }
    }

    public void getAllConstraints() throws SQLException {
        try {
            initConstraintStatement(null);
            getConstraints();
        } finally {
            // fix for too many cursors open, close ps objects
            closeConstraintStatement();   
        }
    }

    /**
     * It releases the database resources by closing the PreparedStatement objects
     * used to load constraints meta data.
     */ 
    private void closeConstraintStatement() throws SQLException {
        if (getConstraints != null) {
            getConstraints.close();
        }
        
        if (getConstraintColumns != null) {
            getConstraintColumns.close();
        }
    }
    
    public void getIndexes(String[] tableNames) throws SQLException {
        String commaSepTableNames = getCommaSepStr(tableNames);
        getIndexes(commaSepTableNames);
    }

    public void getIndexes(String commaSepTableNames) throws SQLException {
        try {
            initIndexeStatement(commaSepTableNames);
            getIndexes();
        } finally {
            // fix for too many cursors open, close ps objects
            closeIndexStatement();   
        }
    }

    public void getAllSynonyms() throws SQLException {
        initPublicSynonymStatement(null) ;
        getPublicSynonyms() ;
    }
    public void getAllIndexes() throws SQLException {
        try {
            initIndexeStatement(null);
            getIndexes();
        } finally {
            // fix for too many cursors open, close ps objects
            closeIndexStatement();   
        }
    }

    /**
     * It releases the database resources by closing the PreparedStatement objects
     * used to load indexes meta data.
     */ 
    private void closeIndexStatement() throws SQLException {
        if (getIndexes != null) {
            getIndexes.close();
        }
        
        if (getIndexColumns != null) {
            getIndexColumns.close();
        }
    }

    public void setDebug(boolean DebugFlag) {
        debugFlag = DebugFlag;
    }

    public void setSchema(String schemaName, boolean loadMetaData) throws Exception {
        schema = new Schema(schemaName, isCaseSensitive(schemaName));

        if (loadMetaData) {
            getSchemaMetaData();
        }
    }

    /*
     * This method is useful when the user wants to add only a specific table in the
     * schema.
     *
     */
    public void addTable(String tableName) throws SQLException {

        try {
            Table table = getTable(tableName);
            if (table != null)
                schema.addTable(table);
        } catch (SQLException se) {
            throw se;
        }
    }

    public void addTables(String[] tableNames) throws SQLException {
        try {
            for (int i = 0; i < tableNames.length; i++) {
                String tableName = tableNames[i];
                if (tableName != null) {
                    addTable(tableName);
                }
            }
        } catch (SQLException se) {
            throw se;
        }
    }

    public void executeScript(String sql) throws SQLException {
        Statement stmt = null;

        try {
            if (sql.compareTo("") != 0) {
                out.println(sql);
                stmt = dbConn.createStatement();
                // check if this is a multi-query string, use executeSimpleQuery()
                // to process it as EDB JDBC driver fails to execute a multi-query DDL
                // via execute() method
                if (sql.split(";").length > 2) {
                    ((com.edb.jdbc2.AbstractJdbc2Statement)stmt).executeSimpleQuery(sql);
                } else {
                    stmt.execute(sql);
                }
            }
        } catch (SQLException se) {
            throw se;
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public boolean schemaExists(String schemaName) throws SQLException {
        boolean schemaFlag = false;
        ResultSet rs = null;

        try {
            rs = dbConn.getMetaData().getSchemas();

            while (rs.next()) {
                if (rs.getString("TABLE_SCHEM").equals(schemaName)) {
                    schemaFlag = true;
                    break;
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
        }

        return schemaFlag;
    }

    /**
     * Removes single quote from object names. This can used when you are getting
     * meta data information from JDBC interfaces not using DBMS sepcific queries.
     *
     * @param commaSepObjNames String
     * @return String
     */
    protected String removeSingleQuotes(String commaSepObjNames) {
        String value = commaSepObjNames;
        if (value != null && value.length() > 0) {
            String[] names = value.split(",");
            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < names.length; i++) {
                if (names[i].startsWith("'") && names[i].endsWith("'")) {
                    builder.append(names[i].substring(1, names[i].length()-1));
                } else {
                    builder.append(names[i]);
                }
                if (i < (names.length -1)) {
                    builder.append(",");
                }
            }
            value = builder.toString();
        }
        return value;
    }

    public void clearConstraintsList() {
        if (schema != null) {
            schema.clearConstraintsList();
        }
    }

    public void clearIndexesList() {
        if (schema != null) {
            schema.clearIndexesList();
        }
    }

    /**
     * This method drops constraints and indexes for the given table from the database.
     * Override this method in the child class to provide the database specific implementation.
     */
    public void dropTableConstsAndIndexes(MTKConstants.DATABASE_TYPE sourceDBType, Table table) throws SQLException {};

}
