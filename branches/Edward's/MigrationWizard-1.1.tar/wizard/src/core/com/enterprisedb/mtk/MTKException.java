/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Created on July 12, 2006
 *
 */
package com.enterprisedb.mtk;

/**
 * @author zahid
 *
 */
@SuppressWarnings("serial")
public class MTKException extends Exception {
    
    /**
     *
     */
    public MTKException() {
        super();
    }
    
    /**
     * @param message
     */
    public MTKException(String message) {
        super(message);
    }
    
    /**
     * @param cause
     */
    public MTKException(Throwable cause) {
        super(cause);
    }
    
    /**
     * @param message
     * @param cause
     */
    public MTKException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
