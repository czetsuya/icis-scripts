/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Column.java
 *
 * Created on February 27, 2006, 10:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

import com.enterprisedb.mtk.util.Logger;

/**
 *
 * @author jimm
 */
public class Column {

    public enum DataType {
        VARCHAR,
        NVARCHAR,
        INTEGER,
        NUMERIC,
        FLOAT,
        DATE,
        TIME,
        TIMESTAMP,
        TEXT,
        BYTEA,
        ROWID,
        INTERVAL,
        BOOLEAN
    };

    private String  columnName = null;
    private String  dataTypeStr = null;
    private int     dataLength = 0;
    private int     dataPrecision = 0;
    private int     dataScale = 0;
    private boolean nullable = false;
    private DataType dataType = null;
    // indicates if the column name is case-sensitive in the database
    private boolean caseSensitive = false;
    // represents column default clause
    private String defaultClause = null;
    // represents column comments
    private String comments = null;
    private Table parentTable = null;

    /** Creates a new instance of Column */
    public Column() {
    }

    public Column(String ColumnName) {
        columnName = ColumnName;
    }

    public Column(Table parentTable, String ColumnName) {
        this.parentTable = parentTable;
        columnName = ColumnName;
    }

    public void addDetail(String DataTypeStr, int DataLength, int DataPrecision,
            int DataScale, String Nullable, boolean caseSensitive, String defaultClause, java.lang.String comments) {
        dataTypeStr = DataTypeStr;
        dataLength = DataLength;
        dataPrecision = DataPrecision;
        dataScale = DataScale;
        this.caseSensitive = caseSensitive;
        this.defaultClause = defaultClause;
        this.comments = comments;
        // also compare for "YES" as edb catalog returns "YES" for nullable attribute
        // compare for "1" as syabse returns 1 or 0 for nullable attribute
        if (Nullable.compareToIgnoreCase("Y") == 0 || Nullable.compareToIgnoreCase("YES") == 0 || Nullable.compareToIgnoreCase("1") == 0)
            nullable = true;
        else
            nullable = false;

        if (isBit()) {
            dataType = DataType.BOOLEAN;
        } else if (isVarchar()) {
            dataType = DataType.VARCHAR;
        } else if (isNVarchar()) {
            dataType = DataType.NVARCHAR;
            //??? assuming that Oracle NCHAR/NVARCHAR2 maps to EDB CHAR/VARCHAR2
            // trim 'N', make correction after verification
            dataTypeStr = dataTypeStr.substring(1, dataTypeStr.length());
            // for nchar and nvarchar2, the returned length is doubled so make
            // it half to conform to original DDL definition
            dataLength = dataLength / 2;
        } else if (isText()) {
            dataType = DataType.TEXT;
            // map nclob to clob
            if (dataTypeStr.toUpperCase().startsWith("NCLOB")) {
                dataTypeStr = "CLOB";
            }
        } else if (isDate()) {
            dataType = DataType.DATE;
        } else if (isNumeric()) {
            if (isFloat())
                dataType = DataType.FLOAT;
            else if (isInteger())
                dataType = DataType.INTEGER;
            else
                dataType = DataType.NUMERIC;
        } else if (isTime()) {
            dataType = DataType.TIME;
        } else if (isTimeStamp()) {
            dataType = DataType.TIMESTAMP;
        } else if (isLargeObject()) {
            dataType = DataType.BYTEA;
        } else if (isRowID()) {
            dataType = DataType.ROWID;
        } else if (isInterval()) {
            dataType = DataType.INTERVAL;
        } else {
            //TODO throw exception or handle a scenario with non-matching type
            Logger.getInstance().println("The data type " + DataTypeStr + " is not handled in Column " + getName() + " of Table " + getTableName());

        }
    }

    public String getName() {
        return columnName;
    }

    public String getDataTypeString() {
        return dataTypeStr;
    }

    public DataType getDataType() {
        return dataType;
    }

    public int getLength() {
        return dataLength;
    }

    public int getPrecision() {
        return dataPrecision;
    }

    public int getScale() {
        return dataScale;
    }

    public boolean isNullable() {
        return nullable;
    }

    public boolean isBit() {
        return dataTypeStr.equalsIgnoreCase("BOOLEAN");
    }

    public boolean isVarchar() {
        if (dataTypeStr.compareToIgnoreCase("VARCHAR2")==0 || dataTypeStr.compareToIgnoreCase("VARCHAR")==0 ||
                dataTypeStr.compareToIgnoreCase("CHAR")==0 || dataTypeStr.equalsIgnoreCase("CHARACTER") ||
                dataTypeStr.equalsIgnoreCase("CHARACTER VARYING") ) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isNVarchar() {
        if (dataTypeStr.compareToIgnoreCase("NVARCHAR2")==0 ||
            dataTypeStr.compareToIgnoreCase("NCHAR")==0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isText() {
        if (dataTypeStr.compareToIgnoreCase("LONG")==0 || dataTypeStr.compareToIgnoreCase("LONG VARCHAR")==0 ||
            dataTypeStr.compareToIgnoreCase("CLOB")==0 || dataTypeStr.compareToIgnoreCase("NCLOB")==0 ||
            // zahid: handling for EDB "TEXT" type"
            dataTypeStr.equalsIgnoreCase("TEXT")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isNumeric() {
        if (dataTypeStr.equalsIgnoreCase("NUMBER") ||
            dataTypeStr.equalsIgnoreCase("NUMERIC") ||
            dataTypeStr.equalsIgnoreCase("FLOAT") ||
            dataTypeStr.equalsIgnoreCase("DOUBLE") ||
            dataTypeStr.equalsIgnoreCase("DECIMAL") ||
            dataTypeStr.equalsIgnoreCase("INTEGER") ||
            dataTypeStr.equalsIgnoreCase("INT") ||
            dataTypeStr.equalsIgnoreCase("SMALLINT") ||
            dataTypeStr.equalsIgnoreCase("BOOLEAN") ||
            // Handlig of Mysql data types : tinyint,mediumint,bigint
            dataTypeStr.equalsIgnoreCase("TINYINT") ||
            dataTypeStr.equalsIgnoreCase("MEDIUMINT") ||
            dataTypeStr.equalsIgnoreCase("BIGINT") ||
            // zahid: handling for EDB "REAL" type
            dataTypeStr.equalsIgnoreCase("REAL") ||
            dataTypeStr.equalsIgnoreCase("DOUBLE PRECISION") ||
            dataTypeStr.equalsIgnoreCase("YEAR") ||
            // Handlig of SQL Server data types : INT IDENTITY
            dataTypeStr.equalsIgnoreCase("SERIAL") ||
            dataTypeStr.equalsIgnoreCase("BIGSERIAL") ){
            return true;
        }

        return false;
    }

    public boolean isFloat() {
        if (dataTypeStr.compareToIgnoreCase("FLOAT")==0
            || dataTypeStr.equalsIgnoreCase("DOUBLE PRECISION")
            || dataTypeStr.equalsIgnoreCase("REAL")
            || dataTypeStr.equalsIgnoreCase("DOUBLE")
            || dataTypeStr.equalsIgnoreCase("DECIMAL"))
            return true;
        return false;
    }

    public boolean isInteger() {
        if (isNumeric() && (dataScale == 0 || isSmallint()))
            return true;
        return false;
    }

    public boolean isDate() {
        if (dataTypeStr.compareToIgnoreCase("DATE") == 0)
            return true;
        return false;
    }

    public boolean isTime() {
        if (dataTypeStr.compareToIgnoreCase("TIME")==0 ||
            // to handle postgres "TIME WITHOUT TIME ZONE" (TIME) type (identified during ofbiz test)    
            dataTypeStr.equalsIgnoreCase("TIME WITHOUT TIME ZONE") ||
            dataTypeStr.equalsIgnoreCase("TIME WITH TIME ZONE"))
            return true;
        return false;
    }

    public boolean isTimeStamp() {
        if (dataTypeStr.compareToIgnoreCase("DATETIME")==0) {
            return true;
        }

        // extract TIMESTAMP part so that comparison is performed only once
        if (dataTypeStr != null &&  dataTypeStr.trim().length() >= 9) {
            String typeName =  dataTypeStr.trim().substring(0,9);

            if (typeName.compareToIgnoreCase("TIMESTAMP")==0) {
                return true;
            }
        }

        return false;
    }

    public boolean isLargeObject() {
        if (dataTypeStr.compareToIgnoreCase("LONG RAW") == 0 ||
            dataTypeStr.compareToIgnoreCase("BLOB") == 0 ||
            dataTypeStr.compareToIgnoreCase("RAW") == 0 ||
            dataTypeStr.compareToIgnoreCase("BYTEA") == 0 ||
            dataTypeStr.compareToIgnoreCase("BINARY") == 0 ||
            dataTypeStr.compareToIgnoreCase("VARBINARY") == 0) {

            return true;
        } else {
            return false;
        }
    }

    public boolean isRowID() {
        if (dataTypeStr.equalsIgnoreCase("ROWID") || dataTypeStr.equalsIgnoreCase("UROWID")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isInterval() {
        if (dataTypeStr.toUpperCase().startsWith("INTERVAL")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isDecimal() {
        if (dataTypeStr.compareToIgnoreCase("DECIMAL")==0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isDouble() {
        if (dataTypeStr.toUpperCase().startsWith("DOUBLE")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isReal() {
        if (dataTypeStr.toUpperCase().startsWith("REAL")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isCaseSensitive() {
        return caseSensitive;
    }

    public boolean isSmallint() {
        if (dataTypeStr.equalsIgnoreCase("SMALLINT") ||
            dataTypeStr.equalsIgnoreCase("TINYINT")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isBlob() {
        if (dataTypeStr.equalsIgnoreCase("BLOB")) {
            return true;
        }

        return false;
    }

    public boolean isLongRaw() {
        if (dataTypeStr.equalsIgnoreCase("LONG RAW")) {
            return true;
        }

        return false;
    }

    public boolean isClob() {
        if (dataTypeStr.equalsIgnoreCase("CLOB")) {
            return true;
        }

        return false;
    }

    public boolean isNClob() {
        if (dataTypeStr.equalsIgnoreCase("NCLOB")) {
            return true;
        }

        return false;
    }

    /**
     * It returns the storage size to hold column values in the in-memory stream buffer.
     * For certain column type e.g. timestamp, the db storage size is different than
     * the size consumed to represent value in buffer, for example for Date/Timestamp
     * the db storage size is 7-9 bytes, whereas buffer consumes 9 to 30 bytes.
     */
    public int getBufferStorageSize() {
        if (isNumeric()) {
            return 38;
        } else if (isDate() || isTime() || isTimeStamp()) {
            return 30;
        }

        return dataLength;
    }


    public String getDefaultClause() {
        return defaultClause;
    }

    public String getComments() {
        return comments;
    }

    /**
     * It retruns name of this column parent table. If parent table
     * reference is not available, null is returned.
     */
    public String getTableName() {
        return (parentTable != null) ? parentTable.getName() : null;
    }

    /**
     * Sets value of casesensitive.
     * @param value boolean
     */
    public void setCaseSensitive(boolean value) {
        this.caseSensitive = value;
    }

    public boolean isBigInt() {
        if (dataTypeStr.equalsIgnoreCase("BIGINT")) {
            return true;
        }
        
        return false;
    }

}
