/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKTransformDDL.java
 *
 * Created on August 31, 2006, 11:53 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import com.enterprisedb.mtk.schema.metadata.Column;
import com.enterprisedb.mtk.schema.metadata.Constraint;
import com.enterprisedb.mtk.schema.metadata.Function;
import com.enterprisedb.mtk.schema.metadata.Index;
import com.enterprisedb.mtk.schema.metadata.Procedure;
import com.enterprisedb.mtk.schema.metadata.PublicSynonym;
import com.enterprisedb.mtk.schema.metadata.Schema;
import com.enterprisedb.mtk.schema.metadata.Sequence;
import com.enterprisedb.mtk.schema.metadata.Table;
import com.enterprisedb.mtk.schema.metadata.Trigger;
import com.enterprisedb.mtk.schema.metadata.View;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Pattern;

/**
 *
 * @author zahid
 */
abstract public class MTKTransformDDL {
    protected static BigInteger maxSeqenceValue = new BigInteger("9223372036854775807");
    abstract public String getCreateScript(Procedure proc);
    abstract public String getCreateScript(Function func);
    abstract public String getCreateScript(PublicSynonym syn);
    abstract public String getCreateScript(Trigger trigger);
    abstract public String getCreateScript(Constraint constraint);
    abstract public String getCreateScript(Index index);
    abstract public String getCreateScriptPackageSpec(com.enterprisedb.mtk.schema.metadata.Package pack);
    abstract public String getCreateScriptPackageBody(com.enterprisedb.mtk.schema.metadata.Package pack);
    abstract protected String getColumnLine(Column column);
    // it holds custom type mapping as col-name/target db type key value pair
    protected Map<String, String> customColTypeMapping = null;
    protected String defaultDateTime = null;

    /** Creates a new instance of MTKTransformDDL */
    public MTKTransformDDL() {
    }

    public String getCreateScript(Schema schema) {
        return getCreateSchemaScript(schema.getName(true));
    }

    public String getCreateSchemaScript(String schemaName) {
        String sql = "CREATE SCHEMA " + schemaName + ";\n";
        return sql;
    }

    public String getDropSchemaScript(String schemaName) {
        String sql = "DROP SCHEMA " + schemaName + " CASCADE;\n";
        return sql;
    }

    public String getDropScript(Schema schema) {
        return (getDropSchemaScript(schema.getName(true)));
    }

    public String getCreateScript(Table table) {
        String sql = "CREATE TABLE " + table.getName() + " (\n";

        for (int i=0; i < table.getColumns().size(); i++) {
            sql = sql + getColumnLine(table.getColumns().get(i));
            if (i < table.getColumns().size()-1)
                sql = sql + ", ";
            sql = sql + "\n";
        }

        sql = sql + ")";
        return sql;
    }

    public String getCreateScript(View view) {
        String sql = "CREATE VIEW " + view.getName() + " AS \n";
        sql = sql + view.getSQL() + "\n";

        return sql;
    }

    public String getCreateScript(Sequence sequence) {
        String sql = "CREATE SEQUENCE " + sequence.getName(true) + " \n";

        sql = sql + " MINVALUE " + sequence.getMinVal().toString() + " \n";

        if (maxSeqenceValue.compareTo(sequence.getMaxVal()) < 0)
            sql = sql + " MAXVALUE " + maxSeqenceValue.toString() + " \n";
        else
            sql = sql + " MAXVALUE " + sequence.getMaxVal().toString() + " \n";

        sql = sql + " START " + sequence.getLastNumber().toString() + " \n";
        sql = sql + " INCREMENT BY " + sequence.getIncrement ().toString () + "\n" ;

        if (sequence.getCacheSize() >= 1)
            sql = sql + " CACHE " + sequence.getCacheSize() + " \n";

        if (sequence.isCycle())
            sql = sql + " CYCLE \n";

        sql = sql + ";";
        return sql;
    }

    protected String getIndent() {
        return "    ";
    }

    protected String stripDefaultClause(String header) {

        while(header.toUpperCase().contains(" DEFAULT")) {
            int startClause = 0;
            int endClause = 0;

            startClause = header.toUpperCase().indexOf(" DEFAULT");
            endClause = header.substring(startClause).indexOf(",");

            // Check if its the end of the header then use the ) as the end of string
            if (endClause < 0)
                endClause = header.substring(startClause).indexOf(")");

            if (endClause < 0)
                endClause = header.substring(startClause).indexOf(";");

            // Need to check that the default value is not a comma
            String testStr = header.substring(startClause, startClause + endClause);
            if (testStr.contains("'")) {
                int nextEnd = 0;
                String tailStr = header.substring(startClause + endClause);
                int nextEnd1 = tailStr.indexOf(",");
                int nextEnd2 = tailStr.indexOf(")");
                if ((nextEnd1 < nextEnd2) && (nextEnd1 > 0))
                    nextEnd = nextEnd1;
                else
                    nextEnd = nextEnd2;

                endClause = endClause + nextEnd;
            }

            header = header.substring(0, startClause) + header.substring(startClause + endClause);
        }

        return header;
    }

    /**
     * It retruns DDL to define comments on each of the table columns. Override the class to provide
     * database specific DDL.
     */
    protected String getColumnsComments(Table table) {
        return "";
    }

    public void setCustomColTypeMapping(Map<String, String> customColTypeMapping) {
        this.customColTypeMapping = customColTypeMapping;
    }

    /**
     * It iterates over the custom col type mapping list and retrives the
     * custom type for the given colName. If custom type is not found,
     * a null is returned.
     *
     * @return A String value representing custom type.
     */
    protected String getCustomColType(String tableName, String colName) {
        if (customColTypeMapping == null) {
            return null;
        }

        String customColType = null;
        Iterator customColTypeMappingIter = customColTypeMapping.keySet().iterator();
        String[] tableColName = null;

        while (customColTypeMappingIter.hasNext()) {
            String colNamePattern = (String) customColTypeMappingIter.next();
            // check if the col is table qualified, since "." is a reserved char in
            // reg expression, "\." is used as the delimiter char between table and col name
            if ((tableColName = colNamePattern.split("\\\\\\.")).length == 2) {
                if (Pattern.compile(tableColName[0], Pattern.CASE_INSENSITIVE).matcher(tableName).matches() &&
                    Pattern.compile(tableColName[1], Pattern.CASE_INSENSITIVE).matcher(colName).matches()) {
                    return customColTypeMapping.get(colNamePattern);
                }
            } else if (Pattern.compile(colNamePattern, Pattern.CASE_INSENSITIVE).matcher(colName).matches()) {
                return customColTypeMapping.get(colNamePattern);
            }
        }

        return customColType;
    }

    public String getDefaultDateTime() {
        return defaultDateTime;
    }

    public void setDefaultDateTime(String value) {
        this.defaultDateTime = value;
    }
}
