/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Function.java
 *
 * Created on March 8, 2006, 7:59 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
public class Function {
    private String funcName = null;
    private String sql = "";
    
    /** Creates a new instance of Function */
    public Function() {
    }

    public Function(String FuncName) {
        funcName = FuncName;
    }
    
    public String getName() {
        return funcName;
    }
    
    public void setSQL(String SQL) {
        String str = "";
        if (SQL.contains("/*-")) {
            str = SQL.replaceFirst("/*-", " -");
        } else
            str = SQL;
            
        sql = sql + str;
    }
    
    public String getSQL() {
        return sql;
    }
}
