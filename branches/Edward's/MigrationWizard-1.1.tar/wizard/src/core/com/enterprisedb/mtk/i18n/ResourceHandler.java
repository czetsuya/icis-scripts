/**
 * This class helps in managing resource bundles. Once a resource bundle is
 * loaded, it is cached in and following requests are honored through cached
 * bundle.
 *
 * It also provides the facilities to use parameterized strings in the bundle.
 * If user provides parameter values, these are replaced in the string and then
 * returned. While defined .properties file or any kind of bundle you can use
 * {n} pattern for parameters where n denotes the paramter number.
 */
package com.enterprisedb.mtk.i18n;

import java.util.Hashtable;
import java.util.ResourceBundle;
import java.text.MessageFormat;

/**
 * @author Shahid Faiz
 * @version 1.0
 */
public class ResourceHandler {

    private static Hashtable resourceBundles = new Hashtable();

    private ResourceHandler() {
    }

    /**
     * Returns object of ResourceBundle for specified name. It uses
     * <code>ResourceBundle.getBundle(String) method to get the resource bundle.
     * @param resourceName String
     * @return ResourceBundle
     * @see java.util.ResourceBundle
     */
    public static ResourceBundle getBundle(String resourceName) {
        ResourceBundle bundle = (ResourceBundle) resourceBundles.get(resourceName);
        if (bundle == null) {
            bundle = ResourceBundle.getBundle(resourceName);
        }
        return bundle;
    }

    /**
     * Returns the value of key from specified resource bundle after parameter
     * value substitution.
     *
     * @param resourceName String
     * @param key String
     * @param paramValues String[]
     * @return String
     */
    public static String getValue(String resourceName, String key, Object[] paramValues) {
        return MessageFormat.format(getBundle(resourceName).getString(key), paramValues);
    }
}
