/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Sequence.java
 *
 * Created on March 8, 2006, 12:33 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.math.*;

public class Sequence {
    private String sequenceName = null;
    private BigInteger minVal = null;
    private BigInteger maxVal = null;
    private BigInteger increment = null;
    private BigInteger lastNumber = null;
    private boolean cycle = false;
    private long cacheSize = 0;            
    // represents if the seq name is case-sensitive
    private boolean caseSensitive = false;
    
    /** Creates a new instance of Sequence */
    public Sequence() {
    }

    public Sequence(String SequenceName, boolean caseSensitive) {
        this.sequenceName = SequenceName;
        this.caseSensitive = caseSensitive;
    }
    
    public void setRange(String MinVal, String MaxVal) {
        minVal = new BigInteger(MinVal);
        maxVal = new BigInteger(MaxVal);
    }
    
    public void setIncrement(String Increment) {
        increment = new BigInteger(Increment);        
    }

    public void setLastNumber(String LastNumber) {
        lastNumber = new BigInteger(LastNumber);        
    }

    public void setCacheSize(long CacheSize) {
        cacheSize = CacheSize;
    }

    public void setCycleFlag(String cycleFlag) {
        if (cycleFlag.compareToIgnoreCase("Y") == 0)
            cycle = true;
        else
            cycle = false;
    }
    
    public BigInteger getMinVal() {
        return minVal;
    }

    public BigInteger getMaxVal() {
        return maxVal;
    }

    public BigInteger getIncrement() {
        return increment;
    }

    public BigInteger getLastNumber() {
        return lastNumber;
    }

    public long getCacheSize() {
        return cacheSize;
    }

    public boolean isCycle() {
        return cycle;
    }
    
    public String getName() {
        return sequenceName;
    }
    
    /**
     * It returns the sequence name in case-sensitive pattern enclosed in
     * double quotes if param quoted is true otherwise in normal form.
     */
    public String getName(boolean quoted) {
        if (caseSensitive) {
            return "\"" + sequenceName + "\"";
        }
        
        return sequenceName;
    }

    public boolean isCaseSensitive() {
        return caseSensitive;
    }
    
}

