/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Trigger.java
 *
 * Created on March 7, 2006, 10:06 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
public class Trigger {
    private String triggerName = null;
    private String type = null;
    private String event = null;
    private String tableName = null;
    private String body = "";
    
    /** Creates a new instance of Trigger */
    public Trigger() {
    }

    public Trigger(String TriggerName) {
        triggerName = TriggerName;
    }
    
    public void setDetails(String TableName, String Type, String Event) {
        tableName = TableName;
        type = Type;
        event = Event;
    }
    
    public String getName() {
        return triggerName;
    }
    
    public void setBody(String Body) {
        body = body + Body;
    }
    
    public String getTableName() {
        return tableName;
    }
    
    public String getType() {
        return type;
    }
    
    public String getEvent() {
        return event;
    }
    
    public String getBody() {
        return body;
    }
    
    public boolean isBeforeTrigger() {
        if (type.startsWith("BEFORE"))
            return true;
        return false;
    }

    public boolean isAfterTrigger() {
        if (type.startsWith("AFTER"))
            return true;
        return false;
    }
    
    public boolean isRowLevelTrigger() {
        if (type.endsWith("EACH ROW"))
            return true;
        return false;
    }
}
