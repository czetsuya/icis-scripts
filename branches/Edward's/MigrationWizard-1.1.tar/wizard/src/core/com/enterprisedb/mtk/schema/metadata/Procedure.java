/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Procedure.java
 *
 * Created on March 7, 2006, 12:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
public class Procedure {
    private String procName = null;
    private String sql = "";
    // represents if the proc name is case-sensitive
    private boolean caseSensitive = false;
    
    /** Creates a new instance of Procedure */
    public Procedure() {
    }

    public Procedure(String ProcName, boolean caseSensitive) {
        procName = ProcName;
        this.caseSensitive = caseSensitive;
    }
    
    public String getName() {
        return procName;
    }
    
    public void setSQL(String SQL) {
        sql = sql + SQL;
    }
    
    public String getSQL() {
        return sql;
    }

    public boolean isCaseSensitive() {
        return caseSensitive;
    }
    
}
