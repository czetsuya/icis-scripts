/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Data.java
 *
 * Created on March 3, 2006, 3:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.dbhandler.postgresql;

/**
 *
 * @author jimm
 * @modified : usama
 */
import java.io.*;
import com.edb.copy.CopyManager;
import com.edb.PGConnection;
import com.enterprisedb.mtk.common.IMTKConnection;
import com.enterprisedb.mtk.common.MTKData;

public class Data extends MTKData {

    private IMTKConnection conn  = null;

    /**
     * Creates a new instance of Data
     */
    public Data(IMTKConnection conn,int cpBatchSize) {
        this.conn = conn;
        dbConn = conn.getConnection();
        if (cpBatchSize !=0) {
        	MTKData.MaxBufferSize = 1024*1024*cpBatchSize ;
        }
    }

    public void setTableData(String tableName, InputStream pis, char copyDelimiter) throws Exception {
        PGConnection copyConn = (PGConnection)conn.getConnection();
        CopyManager copy =  copyConn.getCopyAPI();
        copy.copyIn(tableName, pis, copyDelimiter);
    }
}
