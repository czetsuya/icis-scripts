/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * ConstraintList.java
 *
 * Created on March 8, 2006, 5:16 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

/**
 *
 * @author jimm
 */
import java.util.*;

public class ConstraintList {
    private ArrayList<Constraint> list = null;
    
    /** Creates a new instance of ConstraintList */
    public ConstraintList() {
    }

    public void add(Constraint constraint) {
        if (list == null) 
            list = new ArrayList<Constraint>();
        
        list.add(constraint);
    }
    
    public int size() {
        return ((list != null) ? list.size() : 0);
    }
    
    public Constraint get(int index) {
        return (Constraint) list.get(index);
    }

    public void clear() {
        if (list != null) {
            list.clear();
        }
    }
    
}
