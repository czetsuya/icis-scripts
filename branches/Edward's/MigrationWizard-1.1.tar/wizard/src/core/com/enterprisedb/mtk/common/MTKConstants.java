/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MTKConstants.java
 *
 * Created on September 1, 2006, 11:01 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.common;

import java.sql.DatabaseMetaData;

/**
 *
 * @author zahid, Aamir Yaseen
 */
abstract public class MTKConstants {
    // Constraint types
    public static char CONST_PRIMARY = 'P';
    public static char CONST_FOREIGN = 'R';
    public static char CONST_UNIQUE  = 'U';
    public static char CONST_CHECK   = 'C';

    public static String translateDeleteRule(short rule) {
        switch (rule) {
        case DatabaseMetaData.importedKeyNoAction:
            return "NO ACTION";
        case DatabaseMetaData.importedKeyCascade:
            return "CASCADE";
        case DatabaseMetaData.importedKeySetNull:
            return "SET NULL";
        case DatabaseMetaData.importedKeyRestrict :
            return "RESTRICT";
        case DatabaseMetaData.importedKeySetDefault:
            return "SET DEFAULT";
        default:
            return "";
        }
    }

    // represents database vendor type
    public enum DATABASE_TYPE {
        POSTGRESQL,
        MYSQL;

        // Return string representation
        public String getString(){
            switch(this) {
                case POSTGRESQL:
                    return "PostgreSQL";
                case MYSQL:
                    return "MySQL";
            }
            throw new AssertionError("Unknown option: " + this);
        }

    };
}
