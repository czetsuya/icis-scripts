/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Data.java
 */

package com.enterprisedb.mtk.dbhandler.mysql;

/**
 *
 * @author Shahid Faiz
 */

import java.io.InputStream;
import java.io.PipedOutputStream;

import com.enterprisedb.mtk.MigrationToolkit;
import com.enterprisedb.mtk.common.*;
import com.enterprisedb.mtk.schema.metadata.*;

import java.sql.Timestamp;

public class Data extends MTKData {

    @SuppressWarnings("unused")
	private IMTKConnection conn  = null;
    private MTKConstants.DATABASE_TYPE sourceDBType;

    /**
     * Creates a new instance of Data
     */
    public Data(IMTKConnection conn, int cpBatchSize, MTKConstants.DATABASE_TYPE sourceDBType) {
        this.conn = conn;
        dbConn = conn.getConnection();
        if (cpBatchSize !=0) {
        	MTKData.MaxBufferSize = 1024*1024*cpBatchSize ;
        }
        this.sourceDBType = sourceDBType;
    }

    public void setTableData(String tableName, InputStream pis, char copyDelimiter) throws Exception {
        throw new Exception("This class doesn't support set method.");
    }

    public LargeBufferInputStream getTableData(Table table, char copyDelimeter, boolean escapeTabDelimiter) throws Exception {

        LargeBufferInputStream pis = new LargeBufferInputStream(MaxBufferSize);
        PipedOutputStream pos = new PipedOutputStream();
        String newLineSequence = "\\" + "\\n" ;
        String carriageReturnSequence = "\\" + "\\r" ;
        String columnTabDelimiter = "\\\\t";

        pis.connect(pos);
        try {
            if (!hasMoreData) {
                if (lastTable.compareToIgnoreCase(table.getFullName()) != 0) {
                    stmt = dbConn.createStatement();
                    if (MigrationToolkit.fetchSize > 0) {
                        stmt.setFetchSize(MigrationToolkit.fetchSize);
                    }
                    rs = stmt.executeQuery(table.getSelectSQL(sourceDBType));
                    lastTable = table.getFullName();
                } else {
                    return null;
                }
            }

            while (rs.next()) {
                for (int i=0; i<table.getColumns().size(); i++) {
                    String lastField = null;
                    boolean largeObjFlag = false;
                    switch (table.getColumns().get(i).getDataType()) {
                        case BOOLEAN:
                            if (rs.getObject (i+1) != null) {
                                lastField = String.valueOf(rs.getInt(i+1));
                            }
                            break;
                        case VARCHAR:
                        case TEXT:
                        case NVARCHAR:
                        case ROWID:
                            lastField = rs.getString(i+1);
                            // replace the carriage return and newlines with character sequences
                            // so the copy command doesn't fail
                            if (lastField != null) {
                                lastField = lastField.replaceAll("\n",newLineSequence);
                                lastField = lastField.replaceAll("\r",carriageReturnSequence) ;
                                if(escapeTabDelimiter){
                                	lastField = lastField.replaceAll("\t",columnTabDelimiter);
                                }
                                //Replace The Ending Blackslash with \\
                                //Otherwise it will just fail the copy command
                                if (lastField.endsWith("\\")) {
                                    lastField = lastField.concat("\\");
                                }
                            }
                            break;
                        case FLOAT:
                            if (rs.getObject (i+1) != null)
                                lastField = new Double( rs.getDouble (i+1)).toString () ;
                            break;
                        case INTEGER:
                        case NUMERIC:
                            // zahid: provided recommended mapping to avoid precision lose
                            Column column = table.getColumns().get(i);
                            if (rs.getObject (i+1) != null) {
                                if (column.isReal()) {
                                        lastField = new Float(rs.getFloat (i+1)).toString () ;
                                } else if (column.isDouble()) {
                                        lastField = new Double (rs.getDouble (i+1)).toString () ;
                                } else {
                                        lastField = rs.getBigDecimal (i+1).toString () ;
                                }
                            }
                            break;
                        case TIME:
                            if (rs.getTime(i+1) != null){
                                lastField = rs.getTime(i+1).toString();
                            }
                            break;
                        case DATE:
                        case TIMESTAMP:
                            //TODO Refer FB6174
                            //Fetching Timestaamp Data as String For SQL Server Only
                            //We can Remove this try catch blocck Once we have SourceDBType Available in this method
                            //SQL Server throws Exception when retrieving Timestamp Data as Timestamp
                            //as SQL Server stores Timestamp as binary data
                            try {
                                if (rs.getTimestamp(i + 1) != null) {
                                    lastField = rs.getTimestamp(i + 1).toString();
                                }
                            } catch (Exception exp) {
                                lastField = new Timestamp(Long.parseLong(rs.getString(i + 1))).toString();
                            }
                            break;
                        // for Large Object data types i.e. BLOB, CLOB and LONG RAW; insert null
                        case BYTEA:
                            largeObjFlag = true;
                            break;
                        case INTERVAL:
                            if (rs.getString(i+1) != null){
                                lastField = rs.getString(i+1);
                            }

                            break;

                        default:
                            if (rs.getMetaData().getColumnTypeName(i+1).equalsIgnoreCase("CLOB") ||
                                rs.getMetaData().getColumnTypeName(i+1).equalsIgnoreCase("NCLOB"))
                                throw new Exception("This Table Contains CLOB data, Marked for Bulk Insert Loading");
                            else
                                throw new Exception(rs.getMetaData().getColumnTypeName(i+1) + " is Not Supported by COPY");
                    } // switch

                    if (rs.wasNull() || largeObjFlag) {
                        pos.write(new String("\\N").getBytes());
                    }
                    else {
                        pos.write(lastField.getBytes());
                    }

                    if (i < table.getColumns().size()-1)
                        pos.write(copyDelimeter);
                } // for
                pos.write('\n');

                pis.addRowNum();

                // The buffer is full. Return this data and come back for more later
                if ((MaxBufferSize - pis.getLength()) < table.getMaxRowSize()) {
                    pos.flush();
                    pos.close();
                    hasMoreData = true;
                    return pis;
                }

            } // while
            rs.close();
            stmt.close();
            hasMoreData = false;
            pos.flush();
            pos.close();
        } catch (Exception ex) {
            throw ex;
        }

        return pis;
    }
}
