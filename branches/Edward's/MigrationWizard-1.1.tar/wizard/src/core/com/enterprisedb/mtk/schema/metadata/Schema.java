/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * Schema.java
 *
 * Created on February 27, 2006, 9:46 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk.schema.metadata;

import com.enterprisedb.mtk.MTKException;
import com.enterprisedb.mtk.Utility;

/**
 *
 * @author jimm
 */
public class Schema {
    private String schemaName = null;
    private TableList tables = null;
    private ProcedureList procs = null;
    private ViewList views = null;
    private TriggerList triggers = null;
    private FunctionList functions = null;
    private SequenceList sequences = null;
    private PackageList packages = null;
    private ConstraintList constraints = null;
    private IndexList indexes = null;
    private PublicSynonymList synonyms = null;
    // represents if the schema name is case-sensitive
    private boolean caseSensitive = false;
    
    /** Creates a new instance of Schema */
    public Schema(String SchemaName, boolean caseSensitive) {
        schemaName = SchemaName;
        this.caseSensitive = caseSensitive;
    }
    
    public String getName() {
        return schemaName;
    }
    
    public TableList getTables() {
        return tables;
    }
    
    public void addTable(Table table) {
        if (tables == null)
            tables = new TableList();
        
        tables.add(table);
    }

    public ProcedureList getProcedures() {
        if (procs == null)
            procs = new ProcedureList();        
        return procs;
    }
    
    public void addProcedure(Procedure proc) {
        if (procs == null)
            procs = new ProcedureList();
        
        procs.add(proc);
    }

    public ViewList getViews() {
        if (views == null)
            views = new ViewList();
        return views;
    }
    
    public void addView(View view) {
        if (views == null)
            views = new ViewList();
        
        views.add(view);
    }
    
    public void addSynonym(PublicSynonym syn) {
        if (synonyms == null)
            synonyms = new PublicSynonymList() ;
        synonyms.add(syn) ;
    }
    
    public TriggerList getTriggers() {
        if (triggers == null)
            triggers = new TriggerList();
        return triggers;
    }
    
    public void addTrigger(Trigger trigger) {
        if (triggers == null)
            triggers = new TriggerList();
        
        triggers.add(trigger);
    }

    public FunctionList getFunctions() {
        if (functions == null)
            functions = new FunctionList();
        return functions;
    }
    
    public void addFunction(Function function) {
        if (functions == null)
            functions = new FunctionList();
        
        functions.add(function);
    }

    public SequenceList getSequences() {
        if (sequences == null)
            sequences = new SequenceList();
        return sequences;
    }
    
    public void addSequence(Sequence sequence) {
        if (sequences == null)
            sequences = new SequenceList();
        
        sequences.add(sequence);
    }

    public PackageList getPackages() {
        if (packages == null)
            packages = new PackageList();
        return packages;
    }
    
    public void addPackage(Package pack) {
        if (packages == null)
            packages = new PackageList();
        
        packages.add(pack);
    }

    public PublicSynonymList getSynonyms() {
        if (synonyms == null)
            synonyms = new PublicSynonymList();
        return synonyms ;            
    }
    public ConstraintList getConstraints() {
        if (constraints == null)
            constraints = new ConstraintList();
        return constraints;
    }
    
    public void addConstraint(Constraint constraint) {
        if (constraints == null)
            constraints = new ConstraintList();
        
        constraints.add(constraint);
    }

    public void clearConstraintsList() {
        if (constraints != null) {
            constraints.clear();
        }
    }
    
    public IndexList getIndexes() {
        if (indexes == null)
            indexes = new IndexList();
        return indexes;
    }
    
    public void addIndex(Index index) {
        if (indexes == null)
            indexes = new IndexList();
        
        indexes.add(index);
    }

    public void clearIndexesList() {
        if (indexes != null) {
            indexes.clear();
        }
    }
    
    /**
     * It returns the schema name in case-sensitive pattern enclosed in
     * double quotes if param quoted is true otherwise in normal form.
     */
    public String getName(boolean quoted) {
        if (caseSensitive) {
            return "\"" + schemaName + "\"";
        }
        
        return schemaName;
    }

    public boolean isCaseSensitive() {
        return caseSensitive;
    }
    
    /**
     * This method checks if the table contains the given column
     * represented by colName.
     *
     * @return A boolean value of true if table contains the column otherwise false.
     * @throws MTKException in case table metadata information is not available.
     */
    public boolean hasTableColumn(String tableName, String colName) throws MTKException {
        Table table = null;
        
        // iterate over tablelist to get a reference of the table
        if (tables != null) {
            for (int i = 0; i < tables.size(); i++) {
                if (Utility.removeEnclosingQuotes(tables.get(i).getName()).equals(tableName)) {
                    table = tables.get(i);
                    break;
                }
            }
            
            if (table != null) {
                return table.hasColumn(colName);
            } else {
                throw new MTKException("The table metadeta information is not available.");
            }
        } else {
            throw new MTKException("Tables list is not initialized yet.");
        }
        
    }
    
}
