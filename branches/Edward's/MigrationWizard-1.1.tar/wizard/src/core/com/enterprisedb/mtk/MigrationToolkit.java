/******************************************************************************
 **  Copyright (c) 2004-2007 - EnterpriseDB Corporation.  All Rights Reserved.
 ******************************************************************************/

/*
 * MigrationToolkit.java
 *
 * Created on March 16, 2006, 8:43 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.enterprisedb.mtk;

import com.enterprisedb.mtk.common.IMTKConnection;
import com.enterprisedb.mtk.common.IMTKFactory;
import com.enterprisedb.mtk.common.MTKBridge;
import com.enterprisedb.mtk.common.MTKConstants;
import com.enterprisedb.mtk.common.MTKData;
import com.enterprisedb.mtk.common.MTKFactory;
import com.enterprisedb.mtk.i18n.ResourceHandler;
import com.enterprisedb.mtk.schema.metadata.Table;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import com.enterprisedb.mtk.util.Logger;
import javax.swing.JTextArea;
/**
 *
 * @author zahid
 * @modified : Aamir Yaseen
 */
public class MigrationToolkit {
    // controls logging messages on the standard output
    public static boolean VERBOSE = true;
    public final static String APP_VERSION = "EnterpriseDB Migration Toolkit (Build 21)";

    // constant that represent command-line switches
    public final static String OPT_HELP = "help";
    public final static String OPT_VERSION = "version";
    public final static String OPT_SCHEMA_ONLY = "schemaOnly";
    public final static String OPT_DATA_ONLY = "dataOnly";
    public final static String OPT_CONSTRAINTS = "constraints";
    public final static String OPT_INDEXES = "indexes";
    public final static String OPT_TRIGGERS = "triggers";
    public final static String OPT_ALL_TABLES = "allTables";
    public final static String OPT_ALL_SEQUENCES = "allSequences";
    public final static String OPT_ALL_FUNCS = "allFuncs";
    public final static String OPT_ALL_PROCS = "allProcs";
    public final static String OPT_ALL_PACKAGES = "allPackages";
    public final static String OPT_ALL_VIEWS = "allViews";
    public final static String  OPT_ALL_SYNONYMS = "allSynonyms" ;
    // option to specify if to perform VACUUM ANALYZE on EnterpriseDB after snapshot
    public final static String  OPT_VACUUM_ANALYZE = "vacuumAnalyze" ;
    // option to specify if to perform ANALYZE on EnterpriseDB after snapshot
    public final static String  OPT_ANALYZE = "analyze" ;
    // replicator specific option that when set will cause the MTK to exit as soon as
    // first error is encountered
    public final static String  OPT_EXIT_ON_ERROR = "exitOnError" ;
    // Specify default data time to be used while creating tables
    // Used for MySQL for now because in MySQL can have ZERO date time
    public final static String OPT_DEFAULT_DATETIME = "defaultDateTime";
    private static SimpleDateFormat DATETIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
    private static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static String defaultDateTime = null;
    // fetchSize for result set, used while fetching records from source DB
    public final static String OPT_FETCH_SIZE = "fetchSize";
    public static int fetchSize = 0;


    // This option is going to be used to provide the user flexibility
    // of reducing the bulk insert batch size from 1000. This needs to
    // be done since there have been complaints about Out of Memory Exceptions
    // on bulk inserts. User can reduce the batch size to find out what works for him/her
    public final static String OPT_BATCH_SIZE="batchSize" ;

    // This option is going to be used to provide the user flexibility
    // of increasing or decreasing the Copy Command batch size. Currently
    // copy command uses a batch size of 8 MB, however users with large datasets
    // and lot of memory might want to increase it to reduce migration time
    public final static String OPT_CP_BATCH_SIZE="cpBatchSize" ;

    // constant that represent command-line option names
    public final static String OPT_SOURCE_SCHEMA = "schema";
    public final static String OPT_TARGET_SCHEMA = "targetSchema";
    public final static String OPT_VERBOSE = "verbose";
    public final static String OPT_DROP_SCHEMA = "dropSchema";
    public final static String OPT_TABLES = "tables";
    public final static String OPT_VIEWS = "views";
    public final static String OPT_SEQUENCES = "sequences";
    public final static String OPT_PROCS = "procs";
    public final static String OPT_FUNCS = "funcs";
    public final static String OPT_PACKAGES = "packages";
    public final static String OPT_SYNONYMS = "synonyms" ;
    public final static String OPT_PROP = "prop";

    //User can specify the conn for source and target database 
    public final static String OPT_SRC_DB_URL = "srcdburl";
    public final static String OPT_SRC_USER = "srcuser";
    public final static String OPT_SRC_PASS = "srcpass";
    public final static String OPT_TARGET_DB_URL = "targetdburl";
    public final static String OPT_TARGET_USER = "targetuser";
    public final static String OPT_TARGET_PASS = "targetpass";

    public final static String OPT_TRUNC_BEFORE_LOAD = "truncLoad" ;
    public final static String OPT_SAFE_MODE = "safeMode" ;
    public final static String OPT_COPY_DELIMITER = "copyDelimiter" ;
    public final static String OPT_ESCAPE_TAB_DELIMITER = "escapeTabDelimiter" ;
    // Option to specify filter clause (row filtering criteria) for tables.
    // The criteria is represented as key/value pairs (table/where clause) in a properties file
    public final static String OPT_FILTER_PROP_FILE = "filterProp";
    // this option is meant to be used by Redwood Replicator and generates
    // statistics that are saved in a .properties file
    public final static String OPT_GEN_STATS = "genStats";
    public final static String OPT_STATS_FILE = "statsFile";
    // set custom transaction isolation level for Oracle to TRANSACTION_SERIALIZABLE,
    // it ensures that any changes performed in rows after snapshot query execution
    // are not reflected in the snapshot query set and tables data state is valid in
    // enterprisedb after snapshot is completed.
//    public final static String OPT_ORA_TX_LEVEL_SERIALIZABLE = "oraTxLevelSerializable";
    // use this option to import Oracle VIEW as an EnterpriseDB table. Currently this option
    // is undocumented and will be used from Redwood Replicator context.
    public final static String OPT_IMPORT_VIEW_AS_TABLE = "importViewAsTable";
    // represents the source database type, supported type is "MySQL",
    // "Sybase" and "SQL Server"
    public final static String OPT_SOURCE_DB_TYPE = "sourceDBType";
    // represents the target database type, supported type is "PostgreSQL"
    public final static String OPT_TARGET_DB_TYPE = "targetDBType";
    // use this option to skip migration of FK constraints. By default
    // the FK constraints will be migrated.
    public final static String OPT_SKIP_FK_CONST = "skipFKConst";
    // use this option to skip migration of column DEFAULT clause specifically useful in context of replicator,
    // as this is required for 2 reasons; 1. since the subscriber database is in read-only
    // mode so DEFAULT clause serves no purpose as it's already applied on the pub database
    // 2. sequences are not migrated during replication and in case DEFAULT clause is dependent
    // on sequence it'll fail. By default the DEFAULT clause is migrated.
    public final static String OPT_SKIP_COL_DEFAULT_CLAUSE = "skipColDefaultClause";
    /* This option when specified will perform the COPY operation in an optimized way so as to
     * skip the WAL during data migration. The WAL logging is bypassed when COPY is performed
     * via one of the following 2 approaches.
     * 1. CREATE TABLE and COPY is performed in the same database transaction.
     * 2. TRUNCATE and COPY is performed in the same database transaction (will be supported
     * in EnterpriseDB 8.2).
    */

    // Since EnterpriseDB currently doesn't support NULL char as part of the column value,
    // so a quick work-around is to replace NULL char with a white-space char at the MTK
    // level. However this solution may not work in case NULL has significance in the column
    // value. By default the data will not be parsed to replace NULL char.
    public final static String OPT_REPLACE_NULL_CHAR = "replaceNullChar";
    public final static String OPT_NULL_REPLACEMENT_CHAR = "nullReplacementChar";

    public final static String OPT_FAST_COPY = "fastCopy";
    // the following two options let the user choose a custom type mapping based on column name,
    // so for example user can choose to map each col name with "_ID" suffix to a
    // specific target db type other than the default one. With the first option, custom mappings
    // specified on the command-line where the 2nd one reads the mappings from an input file.
    public final static String OPT_CUSTOM_COL_TYPE_MAPPING = "customColTypeMapping";
    public final static String OPT_CUSTOM_COL_TYPE_MAPPING_FILE = "customColTypeMappingFile";

    // the following contants are related to snapshot stats that are required
    // by Redwood Replicator
    public final static String RREP_STATS_PROP_FILE = "snapshot_stats.properties";
    public static final String RREP_STATS_PROP_START_TIME = "START_TIME";
    public static final String RREP_STATS_PROP_END_TIME = "END_TIME";
    public static final String RREP_STATS_PROP_DURATION = "DURATION";
    public static final String RREP_STATS_PROP_STATUS = "STATUS";
    public static final String RREP_STATS_PROP_ROW_COUNT = "ROW_COUNT";
    public static final String RREP_STATS_PROP_ERROR_MESSAGE = "ERROR_MESSAGE";
    public final static String RREP_STATUS_SUCCESS = "S";
    public final static String RREP_STATUS_FAILED = "F";
    // snapshot process completed with warnings
    public final static String RREP_STATUS_WARNING = "W";

    //Following variables are used for handling i18n/ILO Requirements
    public static final String DEFAULT_RES_BUNDLE_NAME = "com.enterprisedb.mtk.i18n.MTKResources";
    private static String[] rbParameters = new String[]{};


    @SuppressWarnings("unused")
	private String propFile = null;
    private String srcDBURL = null;
    private String srcDBUser = null;
    // set default password to empty to handle (EDB) trust authentication,
    // when the password is not required and login info is passed via command-line args
    private String srcDBPassword = "";

    private String targetDBURL = null;
    private String targetDBUser = null;
    // set default password to empty to handle (EDB) trust authentication,
    // when the password is not required and login info is passed via command-line args
    private String targetDBPassword = "";

    
    // schema to copy
    @SuppressWarnings("unused")
	private String sourceSchema = null;
    // target schema
    private String targetSchema = null;

    // Migrating schemas
    private String[] migratingSchemas = null;
    // Migrating tables
    private String[] migratingTables = null;

    private String[] tableNames = null;

    private char copyDelimiter = '\t' ;
    private boolean escapeTabDelimiter = true;
    private static int batchSize = 1000;
    private static int cpBatchSize  ;

    private IMTKConnection srcConn = null;
    private IMTKConnection targetConn = null;
    private com.enterprisedb.mtk.common.MTKMetaData sourceMD = null;
    private com.enterprisedb.mtk.common.MTKMetaData targetMD = null;
    private com.enterprisedb.mtk.common.MTKTransformDDL tddl = null;
    private static int failureCount = 0;
    private Properties filterProp = null;
    private boolean flagGenStats = false;
    @SuppressWarnings("unused")
	private String statsFileName = RREP_STATS_PROP_FILE;
    @SuppressWarnings("unused")
	private boolean flagOraTxLevelSerializable = false;
    private Properties propRepStats = null;
    private boolean flagVacuumAnalyze = false;
    private boolean flagExitOnError = false;
    private boolean flagImportViewAsTable = false;
    private MTKConstants.DATABASE_TYPE sourceDBType = MTKConstants.DATABASE_TYPE.MYSQL;
    private MTKConstants.DATABASE_TYPE targetDBType = MTKConstants.DATABASE_TYPE.POSTGRESQL;
    private IMTKFactory mtkFactory = null;
    private boolean flagAnalyze = false;
    private boolean flagSkipFKConst = false;
    // The fast copy feature is disabled by default.
    private boolean flagFastCopy = false;
    // it holds custom type mapping as col-name/target db type key value pair
    // e.g. *_ID=INTEGER
    @SuppressWarnings("unused")
	private Map<String, String> customColTypeMapping = null;
    // flag indicates if the user explicitly specified target schema name
    private boolean flagUserSpecifiedTargetSchemaName = false;
    private static boolean skipColDefaultClause = false;
    private static boolean replaceNullChar = false;
    private static String nullReplacementChar = "";

    boolean schemaOnlyMode = false;
    boolean dataOnlyMode = false;
    boolean copyTableData = true;
    boolean copyTableDDL = true;
    boolean importTables = true;
    boolean importConstraints = true;
    boolean importIndexes = true;
    boolean importTriggers = true;
    boolean importViews = true;
    boolean importSequences = true;
    boolean importProcs = true;
    boolean importFuncs = true;
    boolean importSynonyms = true;
    boolean importPackages = true;
    boolean dropSchema = false;
    boolean truncBeforeLoad = false;
    boolean safeMode = false;

    
    public  MigrationToolkit(MigrationProps migrationProps) {
    	
    	mtkFactory = new MTKFactory();
        failureCount=0 ;
        propFile = System.getProperty("prop");

        try {
        	String targetSchemaName = "";                
            this.dropSchema = migrationProps.isRecreateSchema();
            
            this.sourceDBType = MTKConstants.DATABASE_TYPE.MYSQL;
            this.targetDBType = MTKConstants.DATABASE_TYPE.POSTGRESQL;
            
//              --------- Set Connection Info -------------
            setSourceDBConnInfo(migrationProps.getSourceConn().getUrl(), migrationProps.getSourceConn().getUser(), migrationProps.getSourceConn().getPassword());
            setTargetDBConnInfo(migrationProps.getTargetConn().getUrl(), migrationProps.getTargetConn().getUser(), migrationProps.getTargetConn().getPassword());
                
//              --------- Lists of Objects to be Migrated -------------
			this.setMigratingSchemas(migrationProps.getSchemas());
			this.setMigratingTables(migrationProps.getTables());
			this.importConstraints = migrationProps.isMigrateConstraints();
			this.copyDelimiter = migrationProps.getCopyDelimiter();
			
			if(migrationProps.getMigrationType() == MigrationProps.MigrationType.DATA_ONLY){
				this.dataOnlyMode = true;
                this.copyTableDDL = false;
                this.importConstraints = false;
                this.importIndexes = false;
                this.importTriggers = false;
                this.dropSchema = false;
                this.importSynonyms = false;
			} else if (migrationProps.getMigrationType() == MigrationProps.MigrationType.SCHEMA_ONLY){
				this.schemaOnlyMode = true;
				this.copyTableData = false;
			} 
			
			
	        // validate defaultDateTime option
	        if (migrationProps.getDefaultDateTime() != null) {
	            Date date = null;
	            try {
	                date = DATETIME_FORMAT.parse(migrationProps.getDefaultDateTime());
	                MigrationToolkit.defaultDateTime = DATETIME_FORMAT.format(date);
	            } catch (Exception exp) {}
	            
	            try {
	                date = DATE_FORMAT.parse(migrationProps.getDefaultDateTime());
	                MigrationToolkit.defaultDateTime = DATE_FORMAT.format(date);
	            } catch (Exception exp) {
                	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_DEF_DATETIME_FORMAT", null));
                	throw exp;
	            }

	        }
						
			// If source database is MySQL. Make following options false
			importTriggers = false;
			importSequences = false;
			importProcs = false;
			importFuncs = false;
			importPackages = false;
			importSynonyms = false;
			importViews = false;
			
            if (targetSchemaName.equals(targetSchemaName.toUpperCase())) {
            	targetSchemaName = targetSchemaName.toLowerCase();
            }
            //this.setMigratingSchemas(migratingSchemas);
            this.setFlagUserSpecifiedTargetSchemaName(true);

//            //Check if the targetSchema selected is not any of dbo, sys, information_schema, pg_catalog
//        	if (this.migratingSchemas.equals("information_schema")
//        			|| this.migratingSchemas.equals("dbo")
//                    || this.migratingSchemas.equals("sys")
//                    || this.migratingSchemas.equals("pg_catalog")) {
//                	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_SYSTEM_SCHEMA", null));
//                    return;
//        	}
        } catch (Exception e) {
        	rbParameters = new String[]{e.getMessage()};
            Logger.getInstance().printError(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_ERROR_WITH_MESSAGE", rbParameters));
        } finally {}

    }
    
    public void startMigration() throws Exception{        
        try {        	
			initToolkit(propFile);
        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_IMPORT_MYSQL_SCHEMA", null));
        	
        	if(!this.dataOnlyMode)
        		createSchemas(migratingSchemas, dropSchema);
			
			dropSchema = false;
			ArrayList<String> tempTablesList = null;
			if (migratingSchemas != null){
	    		for (int i = 0; i < migratingSchemas.length; i++) {
	    			String currentSchema = migratingSchemas[i];
	    			this.setTargetSchema(currentSchema);
	    			this.setSourceSchema(currentSchema);
	    			
	    			//Filtering tables List for current Schema to populate 
	    			tempTablesList = new ArrayList<String>();
	    			for (int j = 0; j < migratingTables.length; j++) {
						if(migratingTables[j].startsWith(currentSchema+".")){
							tempTablesList.add(migratingTables[j].substring(currentSchema.length()+1));
						}
					}
	    			
	    			this.setTableNames(tempTablesList.toArray(new String[0]));
	    			
	                this.sourceMD = mtkFactory.createMTKMetaData(sourceDBType, srcConn, Utility.isCaseSensitive(targetSchema, targetDBType) ? "\"" + targetSchema + "\"" : targetSchema);
	                this.targetMD = mtkFactory.createMTKMetaData(targetDBType, targetConn, Utility.isCaseSensitive(targetSchema, targetDBType) ? "\"" + targetSchema + "\"" : targetSchema);
	                this.tddl = mtkFactory.createMTKTransformDDL(sourceDBType, targetDBType);
	                
	                this.tddl.setDefaultDateTime(defaultDateTime);
	    			
	                this.sourceMD.setSchema(currentSchema, false);
	                this.targetMD.setSchema(currentSchema, false);
	                
	                if(tableNames != null && tableNames.length > 0 ){
		                logMessage("");
	                	importSchema(currentSchema, copyTableDDL, copyTableData, dropSchema, importTables,
	                			importConstraints, importIndexes, importSynonyms,importTriggers, importViews, importSequences, importProcs,
	                			importFuncs, importPackages, truncBeforeLoad, safeMode);
	                }
	    		}
			}
			if (failureCount == 0) {
            	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_MIGRATION_PROCESS_COMPLETED_SUCC", null));
            } else {
            	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_MIGRATION_PROCESS_COMPLETED_FAIL", null));
            }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(new PrintWriter(Logger.getInstance(),true));
                    //Logger.getInstance().printErrorLn(""+e);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace(new PrintWriter(Logger.getInstance(),true));
                        //Logger.getInstance().printErrorLn(""+e);
		} finally {
			//close the JDBC connections
			if (srcConn != null) {
				srcConn.getConnection().close();
			}
			if (targetConn != null) {
				targetConn.getConnection().close();
			}
		}
    }
    /**
     * It prints the command-line usage guidelines on the standard output.
     *
     */
    @SuppressWarnings("unused")
	private static void usage() {
        Logger.getInstance().println("");
        Logger.getInstance().println(APP_VERSION);
        Logger.getInstance().println("");
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_USAGE_OPTIONS", null));
        Logger.getInstance().println("");
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_IF_NO_OPTION_SPECIFIED", null));
        Logger.getInstance().println("");
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_WHERE_OPTIONS_INCLUDED", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_HELP_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_VERSION_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_VERBOSE_SWITCH_INFO", null));
        Logger.getInstance().println("");
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_SCHEMAONLY_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_DATAONLY_SWITCH_INFO", null));
        Logger.getInstance().println("");
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_ALLTABLES_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_TABLESLIST_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_CONSTRAINTS_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_INDEXES_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_TRIGGERS_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_ALLVIEWS_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_VIEWS_LIST_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_ALLPROCS_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_PROCS_LIST_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_ALL_FUNCS_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_FUNCS_LIST_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_ALL_PACKAGES_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_PACKAGES_LIST_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_ALL_SEQUENCES_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_SEQUENCES_LIST_SWITCH_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_TARGET_SCHEMA_NAME_SWITCH_INFO", null));
        Logger.getInstance().println("");
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_DROP_SCHEMA_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_TRUNC_LOAD_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_SAFE_MODE_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_COPY_DELIMIT_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_BATCH_SIZE_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_CP_BATCH_SIZE_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_FETCH_SIZE_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_DEFAULT_DATE_TIME_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_FILTER_PROP_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_SKIP_FK_CONST_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_FAST_COPY_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_CUST_COLTYPE_MAPPING_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_CUST_COLTYPE_MAPPING_FILE_INFO", null));
        Logger.getInstance().println("");
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_DB_CONNECTION_INFO", null));
        Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "HLP_DB_CONNECTION_INFO_DETAILS", null));
        Logger.getInstance().println("");
    }

    /**
     * It performs a validation check on the command-line arguments to check if the
     * option has a valid name and value.
     *
     * @returns true if validation passed otherwise false
     */
    
    private static void logMessage(String msg) {
        if (VERBOSE) {
            Logger.getInstance().println(msg);
        }
    }
    /** Creates a new instance of MigrationToolkit */
    public MigrationToolkit() {
        mtkFactory = new MTKFactory();
    }

    public void setTableNames(String[] tableNames) {
        this.tableNames = tableNames;
    }

    /**
     *  Set the schema names for the Migration Schemas.
     */
    public void setMigratingSchemas(String[] migratingSchemas) {
        this.migratingSchemas = migratingSchemas;
    }


    /**
     * Set the value for flagExitOnError that when set to true will
     * abort MTK to perform any further operations.
     */
    public void setExitOnError(boolean flagExitOnError) {
        this.flagExitOnError = flagExitOnError;
    }

    public MTKConstants.DATABASE_TYPE getTargetDBType() {
        return targetDBType;
    }

    /**
     * The default source db type is "MYSQL".
     */
    public void setSourceDBType(String sourceDBType) {
    	if (sourceDBType.equalsIgnoreCase("MYSQL")) {
            this.sourceDBType = MTKConstants.DATABASE_TYPE.MYSQL;
        }
    }

    /**
     * Set the targetDBType value to either "POSTGRESQL".
     * The default target db type is "POSTGRESQL".
     */
    public void setTargetDBType(String targetDBType) {
        if (targetDBType.equalsIgnoreCase("POSTGRESQL")) {
            this.targetDBType = MTKConstants.DATABASE_TYPE.POSTGRESQL;
        }
    }

    public void readPropFile(String propFile) throws Exception {
        try {

            // load the ini file
            if (propFile != null){
                Properties ini = new Properties();
                ini.load(new FileInputStream(propFile));
                srcDBURL = ini.getProperty("SRC_DB_URL");
                srcDBUser = ini.getProperty("SRC_DB_USER");
                srcDBPassword = ini.getProperty("SRC_DB_PASSWORD");
                targetDBURL = ini.getProperty("TARGET_DB_URL");
                targetDBUser = ini.getProperty("TARGET_DB_USER");
                targetDBPassword = ini.getProperty("TARGET_DB_PASSWORD");
            }
            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_SRC_DB_CONNECT_INFO", null));
            rbParameters = new String[]{srcDBURL};
            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DB_URL", rbParameters));
            rbParameters = new String[]{srcDBUser};
            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DB_USER", rbParameters));
            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DB_PASS", null));
            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_TARGET_DB_CONNECT_INFO", null));
            rbParameters = new String[]{targetDBURL};
            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DB_URL", rbParameters));
            rbParameters = new String[]{targetDBUser};
            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DB_USER", rbParameters));
            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DB_PASS", null));
        } catch(Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public void setSourceDBConnInfo(String url, String userName, String password) {
        this.srcDBURL = url;
        this.srcDBUser = userName;
        this.srcDBPassword = password;
    }

    public void setTargetDBConnInfo(String url, String userName, String password) {
        this.targetDBURL = url;
        this.targetDBUser = userName;
        this.targetDBPassword = password;
    }

    private void initToolkit(String propFile) throws SQLException {
        try {
            readPropFile(propFile);

            //  check if the Source and Target database connection info is already set
            if (srcDBURL == null || srcDBUser == null) {
                // TODO - throw a custom exception e.g. MTException
                throw new SQLException("Connectivity information for source database is not available.");
            }

            if (targetDBURL == null || targetDBUser == null) {
                // TODO - throw a custom exception e.g. MTException
                throw new SQLException("Connectivity information for target database is not available.");
            }

            srcConn = mtkFactory.createMTKConnection(sourceDBType, srcDBURL, srcDBUser, srcDBPassword);
            targetConn = mtkFactory.createMTKConnection(targetDBType, targetDBURL, targetDBUser, targetDBPassword);
            
            // if fastCopy option is specified, set the auto-commit for target connection to false
            // to peform the CREATE TABLE/TRUNCATE and COPY in the same transaction
            if (flagFastCopy) {
                targetConn.setAutoCommit(false);
            }

            sourceMD = mtkFactory.createMTKMetaData(sourceDBType, srcConn);
            targetMD = mtkFactory.createMTKMetaData(targetDBType, targetConn);
            tddl = mtkFactory.createMTKTransformDDL(sourceDBType, targetDBType);
            tddl.setDefaultDateTime(defaultDateTime);
        } catch (SQLException se) {
            throw se;
        } catch (Exception e) {
            throw new SQLException(e.getMessage());
        }
    }
    
    public void createSchemas(String[] schemas, boolean dropSchema) throws Exception {
    	if (schemas != null){
    		for (int i = 0; i < schemas.length; i++) {
				String currentSchema = schemas[i];

				this.setSourceSchema(currentSchema);
				this.setTargetSchema(currentSchema);
				
				
				this.sourceMD.setSchema(currentSchema, false);
				this.targetMD.setSchema(currentSchema, false);
				
				//check if the schema already exists    	
		        boolean schemaExists = targetMD.schemaExists(currentSchema);
		        // determine if the current schema name is case-sensitive
		        String tempTargetSchemaName = currentSchema;
		        if (flagUserSpecifiedTargetSchemaName) {
		            tempTargetSchemaName = targetMD.isCaseSensitive(tempTargetSchemaName) ? "\"" + tempTargetSchemaName + "\"" : tempTargetSchemaName;
		        } else {
		            tempTargetSchemaName = sourceMD.isCaseSensitive(tempTargetSchemaName) ? "\"" + tempTargetSchemaName + "\"" : tempTargetSchemaName;
		        }

		        if (dropSchema && schemaExists) {
		            try {
		            	rbParameters = new String[]{currentSchema};
		                logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DROPPING_SCHEMA", rbParameters));
		                targetMD.executeScript(tddl.getDropSchemaScript(tempTargetSchemaName));
		            } catch (Exception ex) {
		                throw new SQLException(ex.getMessage());
		            }
		        }

		        if (dropSchema || !schemaExists) {
		        	rbParameters = new String[]{currentSchema};
		        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATING_SCHEMA", rbParameters));
		            targetMD.executeScript(tddl.getCreateSchemaScript(tempTargetSchemaName));
		        }				
			}
    	}
    }
    
    public void importSchema(String currSourceSchema, boolean copyTableDDL, boolean copyTableData,
            boolean dropSchema, boolean importTables, boolean importConstraints, boolean importIndexes, boolean importSynonyms,
            boolean importTriggers, boolean importViews, boolean importSequences, boolean importProcs,
            boolean importFuncs, boolean importPackages, boolean truncateBeforeLoad, boolean safeMode) throws Exception {

        try {
        	
        	targetMD.executeScript("SET search_path=" + (Utility.isCaseSensitive(currSourceSchema, targetDBType) ? "\"" + currSourceSchema + "\"" : currSourceSchema)  + " \n");

            // copy table data
            if (importTables) {
                try {
                    copyTables(tableNames, copyTableDDL, copyTableData, truncateBeforeLoad, safeMode,copyDelimiter);
                } catch (SQLException sqle) {
                    failureCount++;
                    //Externalize This message for ILO Support
                    rbParameters = new String[]{sqle.getMessage()};
                    Logger.getInstance().printError(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_IN_COPY_TABLES", rbParameters));
                }
            }

            // copy table constraints
            if (importConstraints) {
                copyConstraints(tableNames);
            }

            // copy table indexes
            if (importIndexes) {
                copyIndexes(tableNames);
            }
            
//            logMessage("");

        } catch(Exception e){
        	e.printStackTrace(new PrintWriter(Logger.getInstance(),true));
            //Logger.getInstance().printErrorLn(""+e);
        }
    }

    public void createSchema(boolean dropSchema) throws SQLException {
        // check if the schema already exists
        boolean schemaExists = targetMD.schemaExists(targetSchema);
        // determine if the target schema name is case-sensitive
        String tempTargetSchemaName = targetSchema;
        if (flagUserSpecifiedTargetSchemaName) {
            tempTargetSchemaName = targetMD.isCaseSensitive(tempTargetSchemaName) ? "\"" + tempTargetSchemaName + "\"" : tempTargetSchemaName;
        } else {
            tempTargetSchemaName = sourceMD.isCaseSensitive(tempTargetSchemaName) ? "\"" + tempTargetSchemaName + "\"" : tempTargetSchemaName;
        }

        if (dropSchema && schemaExists) {
            try {
            	rbParameters = new String[]{targetSchema};
                logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DROPPING_SCHEMA", rbParameters));
                targetMD.executeScript(tddl.getDropSchemaScript(tempTargetSchemaName));
            } catch (Exception ex) {
                throw new SQLException(ex.getMessage());
            }
        }

        if (dropSchema || !schemaExists) {
        	rbParameters = new String[]{targetSchema};
        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATING_SCHEMA", rbParameters));
            targetMD.executeScript(tddl.getCreateSchemaScript(tempTargetSchemaName));
        }

    }

    public void copyTables(final String[] sourceTableNames, boolean copyTableDDL, boolean copyTableData,
            boolean truncateBeforeLoad, boolean safeMode, char copyDelimeter) throws SQLException, MTKException {

        long totalRows = 0;
        double totalTime = 0;

        try {
            MTKData sourceData = mtkFactory.createMTKData(sourceDBType, srcConn,cpBatchSize);
            MTKData targetData = mtkFactory.createMTKData(targetDBType, targetConn,cpBatchSize);

            String commaSepTableNames = getCommaSepObjectNames(sourceTableNames);
            if  (commaSepTableNames != null) {
            	rbParameters = new String[]{targetSchema,commaSepTableNames.toString()};
            	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_TABLE_LIST", rbParameters));
                sourceMD.getTables(commaSepTableNames, flagImportViewAsTable);
            } else {
                // load all tables meta data
                sourceMD.getAllTables();
            }

            if (sourceMD.getSchema().getTables() == null) {
            	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_NO_TABLE_TO_MIGRATE", null));
                return;
            }

            // if one or more tables are missing in the source database,
            // abort further operations and exit
            if (sourceTableNames != null &&
                (sourceMD.getSchema().getTables() == null || sourceTableNames.length != sourceMD.getSchema().getTables().size())) {
                if (flagGenStats) {
                    propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_FAILED);
                }

                // flagExitOnError is true, the MTK is invoked from Replicator
                if (flagExitOnError) {
                    throw new MTKException("One or more tables are missing from the source " + sourceDBType.getString() + " database.");
                } else {
                    throw new MTKException("One or more tables couldn't be found in the source " + sourceDBType.getString() + " database.\nWith -tables mode, the table name should be in uppercase unless it is case-sensitive.");
                }
            }

            // if fastCopy mode is on and it's not a safeMode then perform the table
            // creation as part of COPY load
            if (copyTableDDL && (!flagFastCopy || safeMode)) {
            	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATING_TABLES", null));
                int tableIndex;
                int tableCount=0;
                for (tableIndex = 0; tableIndex < sourceMD.getSchema().getTables().size(); tableIndex++) {
                    try {
                        com.enterprisedb.mtk.schema.metadata.Table table = sourceMD.getSchema().getTables().get(tableIndex);
                        rbParameters = new String[]{targetSchema + "." + table.getName()};
                        logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATING_TABLE", rbParameters));
                        targetMD.executeScript(tddl.getCreateScript(table));
                        tableCount++;
                    } catch (Exception e) {
                    	rbParameters = new String[]{sourceMD.getSchema().getTables().get(tableIndex).getName(),e.getMessage()};
                    	Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_REATING_TABLE_WITH_MSG", rbParameters));
                        sourceMD.getSchema().getTables().get(tableIndex).setCreationFailure(true) ;
                        failureCount++ ;
                        // if MTK is invoked in EDB-Replicator context, abort further operations
                        if (flagExitOnError) {
                            //TODO rollback any tables created in the current session
                            if (flagGenStats) {
                                propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_FAILED);
                            }

                            throw new MTKException("The table " + sourceMD.getSchema().getTables().get(tableIndex).getName() +
                                    " could not be created in " + targetDBType.getString() + " database.\nReason:\n" + e.getMessage());
                        }
                    }
                }

                if (flagGenStats) {
                    propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_SUCCESS);
                }
                rbParameters = new String[]{String.valueOf(tableCount)};
                logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATED_TABLES_COUNT", rbParameters));
            }


            // perform data load operation
            if (copyTableData) {
                // check if the user specified where clause via filter properties file,
                // then set the table where clause.
                if (filterProp != null && filterProp.size() > 0) {
                    // read all table names (with where clause) to handle the scenario in case the
                    // user has specified table name in mixed case/upper case/lower case
                    List<String> listFilterTable = new ArrayList<String>();

                    for (Enumeration e = filterProp.propertyNames() ; e.hasMoreElements() ;) {
                        listFilterTable.add((String)e.nextElement());
                    }

                    String tableName = null;
                    boolean tableFilterFound = false;

                    for (int i = 0; i < sourceMD.getSchema().getTables().size(); i++) {
                        tableName = sourceMD.getSchema().getTables().get(i).getName();
                        tableFilterFound = false;

                        for (String filterTable:listFilterTable) {
                            if (filterTable.equals(tableName)) {
                                tableFilterFound = true;
                                //AY
                                //No need of this instruction to be executed as it is aalready checked in If Condition
                                //tableName = filterTable;
                                break;
                            }
                        }

                        if (tableFilterFound && filterProp.getProperty(tableName) != null) {
                            sourceMD.getSchema().getTables().get(i).setWhereClause(filterProp.getProperty(tableName));
                        }
                    }
                }

                // for safe mode, copy data via plain SQL statements
                if (safeMode) {
                	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_LOADING_TABLE_DATA_SAFE_MODE", null));

                    for (int i = 0; i < sourceMD.getSchema().getTables().size(); i++) {
                        try {
                            Date startTime = new Date();
                            long tableRows = 0;
                            rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName()};
                            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_LOADING_TABLE", rbParameters));

                            if (truncateBeforeLoad) {
                            	//pass tableName as Target Schema Fully Qualified Name.
                                disableTableContraints(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));

                                // for the first phase, the dropping/restoring of indexes will be done
                                // in replicator context, later on support it for MTK use from other
                                // apps i.e. dev studio and in stand-alone mode
                                if (flagGenStats) {
                                    dropTableConstsAndIndexes(sourceMD.getSchema().getTables().get(i));
                                } else {
                                    disableTableIndexes(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                }
                            }

                            MTKBridge bridge = mtkFactory.createMTKBridge(sourceDBType,targetDBType, srcConn, targetConn);
                            tableRows = tableRows + bridge.setTableDataInSafeMode(sourceMD.getSchema().getTables().get(i));
                            totalRows = totalRows + tableRows;

                            if (truncateBeforeLoad) {
                            	//pass tableName as Target Schema Fully Qualified Name.
                                enableTableContraints(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));

                                // for the first phase, the disabling/enabling of indexes will be done
                                // in replicator context, later on support it when MTK is used from other
                                // apps i.e. dev studio and in stand-alone mode
                                if (flagGenStats) {
                                    restoreTableConstsAndIndexes(sourceMD.getSchema().getTables().get(i));
                                } else {
                                    enableTableIndexes(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                }
                            }

                            Date endTime = new Date();
                            double tableTime = endTime.getTime() - startTime.getTime();
                            totalTime = totalTime + tableTime;
                            displayTableDataLoadSummary(tableTime, tableRows, 0);
                        } catch (Exception lex) {
                            failureCount++;
                            rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName(),lex.getMessage()};
                            logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_LOADING_DATA_IN_TABLE", rbParameters));
                        }
                    }
                    rbParameters = new String[]{String.valueOf((totalTime/1000)),String.valueOf(totalRows)};
                    logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DATA_LOAD_SUMMARY", rbParameters));

                } else {
                	rbParameters = new String[]{String.valueOf(((cpBatchSize==0)?8:cpBatchSize))};
                	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_LOADING_TABLE_DATA_SIZE", rbParameters));
                    double totalSizeKBytes = 0;

                    for (int i = 0; i < sourceMD.getSchema().getTables().size(); i++) {

                        // with fastCopy mode, table creation and copy is done in the same tx
                        if (copyTableDDL && flagFastCopy) {
                            try {
                                com.enterprisedb.mtk.schema.metadata.Table table = sourceMD.getSchema().getTables().get(i);
                                rbParameters = new String[]{targetSchema + "."+ table.getName()};
                                logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATING_TABLE", rbParameters));
                                targetMD.executeScript(tddl.getCreateScript(table));
                            } catch (Exception e) {
                            	rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName(),e.getMessage()};
                            	Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_REATING_TABLE_WITH_MSG", rbParameters));
                                sourceMD.getSchema().getTables().get(i).setCreationFailure(true) ;
                                targetData.rollback();
                                failureCount++ ;
                                // if MTK is invoked in EDB-Replicator context, abort further operations
                                if (flagExitOnError) {
                                    //TODO rollback any other tables created in the current session
                                    if (flagGenStats) {
                                        propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_FAILED);
                                    }

                                    throw new MTKException("The table " + sourceMD.getSchema().getTables().get(i).getName() +
                                            " could not be created in " + targetDBType.getString() + " database.\nReason:\n" + e.getMessage());
                                }
                            }
                        }
                        
                        double tableTime = 0;
                        long tableRows = 0;
                        double tableSizeKBytes = 0;

                        if (!sourceMD.getSchema().getTables().get(i).isCreationFailure()) {
                            if (sourceMD.getSchema().getTables().get(i).hasLargeObject() == false) {
                                try {
                                    if (truncateBeforeLoad) {
                                    	//pass tableName as Target Schema Fully Qualified Name.
                                        disableTableContraints(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                        rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName()};
                                        logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_TRUNCATING_TABLE", rbParameters));
                                        targetMD.executeScript("Truncate Table " + sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, false));


                                        if (flagGenStats) {
                                            dropTableConstsAndIndexes(sourceMD.getSchema().getTables().get(i));
                                        } else {
                                            disableTableIndexes(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                        }
                                    }
                                    rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName()};
                                    logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_LOADING_TABLE", rbParameters));
                                    Date startTime = new Date();
                                    com.enterprisedb.mtk.schema.metadata.LargeBufferInputStream pis = sourceData.getTableData(sourceMD.getSchema().getTables().get(i),copyDelimeter, escapeTabDelimiter);

                                    long oldRowCount = 0;
                                    while (pis != null) {
                                        oldRowCount = tableRows;
                                        tableRows = tableRows + pis.getNumRows();
                                        tableSizeKBytes = tableSizeKBytes + (pis.getLength()/1024);
                                        targetData.setTableData(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, false), pis,copyDelimeter);

                                        if(oldRowCount != tableRows){
                                        	rbParameters = new String[]{String.valueOf(tableRows)};
                                        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_MIGRATED_ROWS", rbParameters));
                                        }
                                        pis = sourceData.getTableData(sourceMD.getSchema().getTables().get(i),copyDelimiter, escapeTabDelimiter);
                                    }

                                    // for fast copy mode, commit the tx (as auto-commit is off in this mode)
                                    if (flagFastCopy) {
                                        targetData.commit();
                                    }

                                    // log table rep stats
                                    if (flagGenStats) {
                                        propRepStats.setProperty(sourceMD.getSchema().getTables().get(i).getFullName(true),
                                                String.valueOf(tableRows));
                                    }

                                    if (truncateBeforeLoad) {
                                    	//pass tableName as Target Schema Fully Qualified Name.
                                        enableTableContraints(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));

                                        if (flagGenStats) {
                                            restoreTableConstsAndIndexes(sourceMD.getSchema().getTables().get(i));
                                        } else {
                                            enableTableIndexes(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                        }
                                    }

                                    Date endTime = new Date();
                                    tableTime = endTime.getTime() - startTime.getTime();
                                    totalTime = totalTime + tableTime;
                                    totalRows = totalRows + tableRows;
                                    totalSizeKBytes = totalSizeKBytes + tableSizeKBytes;
                                    displayTableDataLoadSummary(tableTime, tableRows, tableSizeKBytes);

                                    if (pis != null) {
                                        pis.close() ;
                                    }
                                } catch (Exception dex) {
                                    sourceMD.getSchema().getTables().get(i).dataLoadFailed();
                                    // for fast copy mode, rollback the tx (as auto-commit is off in this mode)
                                     if (flagFastCopy) {
                                        targetData.rollback();
                                    }

                                    sourceData.reset();

                                     if(dex.getMessage().contains("Rreport_invalid_encoding")){
                                     	rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).
						getName(),ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_ENCODING_MESSAGE", null)};
                                     	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_LOADING_DATA_IN_TABLE", rbParameters));
                                     }else{
                                    rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName(),dex.getMessage()};
                                    logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_LOADING_DATA_IN_TABLE", rbParameters));
                                }
				}
                            } else {
                                // for fast copy mode, commit the tx (as auto-commit is off in this mode) so that
                                // table is available when the large objects are migrated later in this process
                                if (copyTableDDL && flagFastCopy) {
                                    targetData.commit();
                                }
                            }
                        }
                    } // end of for (COPY load)

                    // if fastCopy option is specified and COPY load is done, set the auto-commit for
                    // target connection back to true
                    if (flagFastCopy) {
                        // for fast copy mode, commit the tx (as auto-commit is off in this mode)
                        //targetData.commit();
                        targetConn.setAutoCommit(true);
                    }

                    // Load Tables that failed with bulk import syntax
                    for (int i = 0; i < sourceMD.getSchema().getTables().size(); i++) {
                        double tableTime = 0;
                        long tableRows = 0;
                        double tableSizeKBytes = 0;

                        if (!sourceMD.getSchema().getTables().get(i).isCreationFailure()) {
                            try {
                                if (sourceMD.getSchema().getTables().get(i).hasDataLoadFailure() &&
                                    !sourceMD.getSchema().getTables().get(i).hasLargeObject()) {

                                    // with fastCopy and copyTableDDL mode, if data load failure occured earlier
                                    // then table creation is rolled back so perform the table creation
                                    if (copyTableDDL && flagFastCopy) {
                                        try {
                                            com.enterprisedb.mtk.schema.metadata.Table table = sourceMD.getSchema().getTables().get(i);
                                            targetMD.executeScript(tddl.getCreateScript(table));
                                        } catch (Exception e) {
                                        	rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName(), e.getMessage()};
                                        	Logger.getInstance().println(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_REATING_TABLE_WITH_MSG", rbParameters));
                                            sourceMD.getSchema().getTables().get(i).setCreationFailure(true) ;
                                            failureCount++ ;
                                            // if MTK is invoked in EDB-Replicator context, abort further operations
                                            if (flagExitOnError) {
                                                //TODO rollback any other tables created in the current session
                                                if (flagGenStats) {
                                                    propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_FAILED);
                                                }

                                                throw new MTKException("The table " + sourceMD.getSchema().getTables().get(i).getName() +
                                                        " could not be created in " + targetDBType.getString() + " database.\nReason:\n" + e.getMessage());
                                            }
                                        }
                                    }

                                    Date startTime = new Date();
                                    if (truncateBeforeLoad) {
                                    	//pass tableName as Target Schema Fully Qualified Name.
                                        disableTableContraints(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));

                                        if (flagGenStats) {
                                            dropTableConstsAndIndexes(sourceMD.getSchema().getTables().get(i));
                                        } else {
                                            disableTableIndexes(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                        }
                                    }

                                    // since COPY is only supported when PG is the target database, so in all other
                                    // cases data copy will be re-attempted via Batch Update hence the reload message should
                                    // not be displayed
                                    if (targetDBType == MTKConstants.DATABASE_TYPE.POSTGRESQL) {
                                    	rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName(), String.valueOf(batchSize)};
                                    	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_TRYING_TO_RELOAD_TABLE", rbParameters));
                                    }

                                    MTKBridge bridge = mtkFactory.createMTKBridge(sourceDBType, targetDBType,srcConn, targetConn);
                                    tableRows = bridge.setTableData(sourceMD.getSchema().getTables().get(i), batchSize);
                                    tableSizeKBytes = bridge.getLastMigratedDataSize()/1024;

                                    // log table rep stats
                                    if (flagGenStats) {
                                        propRepStats.setProperty(sourceMD.getSchema().getTables().get(i).getFullName(true),
                                                String.valueOf(tableRows));
                                    }

                                    if (truncateBeforeLoad) {
                                    	//pass tableName as Target Schema Fully Qualified Name.
                                        enableTableContraints(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));

                                        if (flagGenStats) {
                                            restoreTableConstsAndIndexes(sourceMD.getSchema().getTables().get(i));
                                        } else {
                                            enableTableIndexes(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                        }
                                    }

                                    Date endTime = new Date();
                                    tableTime = endTime.getTime() - startTime.getTime();
                                    totalTime = totalTime + tableTime;
                                    totalRows = totalRows + tableRows;
                                    totalSizeKBytes = totalSizeKBytes + tableSizeKBytes;
                                    displayTableDataLoadSummary(tableTime, tableRows, tableSizeKBytes);
                                }
                            } catch (Exception lex) {
                                failureCount++;
                                rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName(), lex.getMessage()};
                                logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_LOADING_DATA_IN_TABLE", rbParameters));
                            }
                        }
                    }
                    for (int i = 0; i < sourceMD.getSchema().getTables().size(); i++) {
                        double tableTime = 0;
                        long tableRows = 0;
                        double tableSizeKBytes = 0;

                        if (!sourceMD.getSchema().getTables().get(i).isCreationFailure()) {
                            try {
                                if (sourceMD.getSchema().getTables().get(i).hasLargeObject()) {
                                    Date startTime = new Date();
                                    if (truncateBeforeLoad) {
                                    	//pass tableName as Target Schema Fully Qualified Name.
                                        disableTableContraints(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));

                                        if (flagGenStats) {
                                            dropTableConstsAndIndexes(sourceMD.getSchema().getTables().get(i));
                                        } else {
                                            disableTableIndexes(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                        }
                                    }
                                    rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName()};
                                    logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_LOADING_LARGE_OBJECTS_IN_TABLE", rbParameters));
                                    MTKBridge bridge = mtkFactory.createMTKBridge(sourceDBType, targetDBType,srcConn, targetConn);
                                    tableRows = bridge.setTableData(sourceMD.getSchema().getTables().get(i), 1);
                                    tableSizeKBytes = bridge.getLastMigratedDataSize()/1024;

                                    // log table rep stats
                                    if (flagGenStats) {
                                        propRepStats.setProperty(sourceMD.getSchema().getTables().get(i).getFullName(true),
                                                String.valueOf(tableRows));
                                    }

                                    if (truncateBeforeLoad) {
                                        //pass tableName as Target Schema Fully Qualified Name.
                                        enableTableContraints(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));

                                        if (flagGenStats) {
                                            restoreTableConstsAndIndexes(sourceMD.getSchema().getTables().get(i));
                                        } else {
                                            enableTableIndexes(sourceMD.getSchema().getTables().get(i).getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, true));
                                        }
                                    }

                                    Date endTime = new Date();
                                    tableTime = endTime.getTime() - startTime.getTime();
                                    totalTime = totalTime + tableTime;
                                    totalRows = totalRows + tableRows;
                                    totalSizeKBytes = totalSizeKBytes + tableSizeKBytes;
                                    displayTableDataLoadSummary(tableTime, tableRows, tableSizeKBytes);
                                } // if

                            } catch (Exception lex) {
                                failureCount++;
                                rbParameters = new String[]{sourceMD.getSchema().getTables().get(i).getName(), lex.getMessage()};
                                logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_LOADING_DATA_IN_TABLE", rbParameters));
                            }
                        }
                    } // for

                    // perform VACUUM ANALYZE on PG
                    if (flagVacuumAnalyze) {
                    	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_PERFORM_VACUM_ANALYZE_ON_EDB", null));
                        targetMD.executeScript("VACUUM ANALYZE");
                    } else if (flagAnalyze) {
                        // perform ANALYZE on EnterpriseDB
                    	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_PERFORMING_ANALYZE_ON_EDB", null));
                        targetMD.executeScript("ANALYZE");
                    }

                    if (flagGenStats) {
                        if (failureCount == 0) {
                            propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_SUCCESS);
                        } else {
                            propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_WARNING);
                            propRepStats.setProperty(RREP_STATS_PROP_ERROR_MESSAGE, "One or more tables could not be replicated. Read output log for more details.");
                        }

                    }
                    rbParameters = new String[]{String.valueOf((totalTime/1000)), String.valueOf(totalRows), String.valueOf((totalSizeKBytes/1000))};
                    logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DATA_LOAD_SUMMARY", rbParameters));

                } // if

            } // if (copyTableData)

            // This is done because when integrated with DevStudio, lastTable of sourceData is set to the
            // last table migrated and migrating a table twice causes no rows to be migrated
            // second time since getTables returns null;
            sourceData.setLastTable("");

        } finally {
            if (flagGenStats) {
                if (copyTableData) {
                    propRepStats.setProperty(RREP_STATS_PROP_ROW_COUNT, String.valueOf(totalRows));
                    propRepStats.setProperty(RREP_STATS_PROP_END_TIME, Utility.formatDate(new Date(), null));
                    propRepStats.setProperty(RREP_STATS_PROP_DURATION, String.valueOf(new Double(totalTime/1000)));
                } else if (copyTableDDL) {
                    if (failureCount == 0) {
                        propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_SUCCESS);
                    } else {
                        propRepStats.setProperty(RREP_STATS_PROP_STATUS, RREP_STATUS_FAILED);
                    }
                }
            }
        }
    }

    private void displayTableDataLoadSummary(double totalTime, long totalRows, double totalDataSizeKBytes) {
        double totalTimeSecs = totalTime/1000;
        double totalMBytes = totalDataSizeKBytes / 1024;
       rbParameters = new String[]{String.valueOf(totalTimeSecs),String.valueOf(totalRows)};
       String summary = ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_SUMMARY_PART1", rbParameters);

        if (totalMBytes > 0) {
        	rbParameters = new String[]{String.valueOf(totalMBytes)};
        	summary = summary + " "+ ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_SUMMARY_PART2", rbParameters);
        }

        logMessage(summary);

    }

    public void copyConstraints(final String[] tableNames) throws SQLException {
        String commaSeptableNames = getCommaSepObjectNames(tableNames);

        if  (commaSeptableNames != null) {
            // load constraints meta data only for the selected tables
            sourceMD.getConstraints(commaSeptableNames);
        } else {
            // load constraints meta data for all tables
            sourceMD.getAllConstraints();
        }

        try {
            // Add the Primary keys and unique contraints first
            for (int i = 0; i < sourceMD.getSchema().getConstraints().size(); i++) {
                com.enterprisedb.mtk.schema.metadata.Constraint constraint = sourceMD.getSchema().getConstraints().get(i);
                try {
                    if (constraint.getType() == 'P' || constraint.getType() == 'U' ||
                        constraint.getType() == 'p' || constraint.getType() == 'u') {
                        String sql = tddl.getCreateScript(constraint);
                        if (sql.compareTo("") != 0) {
                        	rbParameters = new String[]{constraint.getName()};
                        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATING_CONSTRAINT", rbParameters));
                            targetMD.executeScript(sql);
                        }
                    }
                } catch (Exception cex) {
                    failureCount++;
                    rbParameters = new String[]{constraint.getName(), cex.getMessage()};
                    logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_CREATING_CONSTRAINT", rbParameters));
                }
            }

            for (int i = 0; i < sourceMD.getSchema().getConstraints().size(); i++) {
                com.enterprisedb.mtk.schema.metadata.Constraint constraint = sourceMD.getSchema().getConstraints().get(i);
                try {
                    if (constraint.getType() != 'P' && constraint.getType() != 'p' &&
                        constraint.getType() != 'U' && constraint.getType() != 'u') {

                        // if -skipFKConst is set to true, don't migrate FK constraints
                        if (flagSkipFKConst &&
                            (constraint.getType() == 'R' || constraint.getType() == 'r')
                           ) {
                            continue;
                        }

                        String sql = tddl.getCreateScript(constraint);
                        if (sql.compareTo("") != 0) {
                        	rbParameters = new String[]{constraint.getName()};
                        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATING_CONSTRAINT", rbParameters));
                            targetMD.executeScript(sql);
                        }
                    }
                } catch (Exception cex) {
                    failureCount++;
                    rbParameters = new String[]{constraint.getName(), cex.getMessage()};
                    logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_CREATING_CONSTRAINT_WITH_ERR_MSG", rbParameters));
                }
            }
        } catch (Exception ex) {
        	rbParameters = new String[]{ex.getMessage()};
        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_CREATING_CONSTRAINT", rbParameters));
            throw new SQLException(ex.getMessage());
        }
    }

    public void copyIndexes(final String[] tableNames) throws SQLException {
        String commaSeptableNames = getCommaSepObjectNames(tableNames);

        if  (commaSeptableNames != null) {
            // load indexes meta data only for the selected tables
            sourceMD.getIndexes(commaSeptableNames);
        } else {
            // load indexes meta data for all tables
            sourceMD.getAllIndexes();
        }

        try {
            // Add the non-unique indexes
            for (int i = 0; i < sourceMD.getSchema().getIndexes().size(); i++) {
                com.enterprisedb.mtk.schema.metadata.Index index = sourceMD.getSchema().getIndexes().get(i);
                try {
                        String sql = tddl.getCreateScript(index);
                        if (sql.compareTo("") != 0) {
                        	rbParameters = new String[]{index.getName()};
                        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_CREATING_INDEX", rbParameters));
                            targetMD.executeScript(sql);
                    }
                } catch (Exception iex) {
                    failureCount++;
                    rbParameters = new String[]{index.getName(), iex.getMessage()};
                    logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_CREATING_INDEX_WITH_ERR_MSG", rbParameters));
                }
            }
        } catch (Exception ex) {
        	rbParameters = new String[]{ex.getMessage()};
        	logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "ERR_CREATING_INDEX", rbParameters));
            throw new SQLException(ex.getMessage());
        }
    }

    private String getCommaSepObjectNames(String[] schemaObjectNames) {
        StringBuffer commaSepObjectNames= new StringBuffer();

        if  (schemaObjectNames != null) {
            String schemaObjectName = null;
            for (int i = 0; i < schemaObjectNames.length; i++) {
                schemaObjectName = schemaObjectNames[i];

                // Zahid: FB6347 fix - escape apostrophe char in case it's part of name
                schemaObjectName = schemaObjectName.replaceAll("'", "''");

                if (i > 0) {
                    commaSepObjectNames.append(",");
                }

                commaSepObjectNames.append("'").append(schemaObjectName).append("'");
            }
        } else {
            return null;
        }

        return commaSepObjectNames.toString();
    }

    private void disableTableContraints(String tableName) throws SQLException {
        rbParameters = new String[]{tableName};
        logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DISABLING_FK_CONSTR_TRIGGER_INDEXES_BEFORE_TRUNC", rbParameters));
        targetMD.executeScript("Update pg_catalog.pg_class set reltriggers = 0 where oid = '" + tableName
                + "'::pg_catalog.regclass") ;
    }

    private void disableTableIndexes(String tableName) throws SQLException {
        rbParameters = new String[]{tableName};
        logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DISABLING_INDEXES_BEFORE_DATA_LOAD", rbParameters));
        // Disable the indexes to optimize the data transfer. At the end of the data load
        // indexes will be enabled and table will be reindexed (bulk indexing is quicker as compared
        // to updating index for each of the row update)
        targetMD.executeScript("update pg_catalog.pg_class set relhasindex = 'f' where oid = '" + tableName
                + "'::pg_catalog.regclass");
    }

    private void dropTableConstsAndIndexes(Table table) throws SQLException {
        rbParameters = new String[]{table.getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, false)};
        logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_DISABLING_INDEXES_BEFORE_DATA_LOAD", rbParameters));
        // Drop the indexes to optimize the data transfer. At the end of the data load
        // indexes will be re-created and table will be reindexed (bulk indexing is quicker as compared
        // to updating index for each of the row update)
        targetMD.dropTableConstsAndIndexes(sourceDBType, table);
    }

    private void enableTableContraints(String tableName) throws SQLException {
        // re-enable the indexes at the end of the data load and reindex the
        // table (bulk indexing is quicker as compared to updating index for
        // each of the row update)

        rbParameters = new String[]{tableName};
        logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_ENABLING_FK_CONSTR_TRIGGER_INDEXES_BEFORE_TRUNC", rbParameters));
        targetMD.executeScript("Update pg_catalog.pg_class  set reltriggers = (select pg_catalog.count(*) " +
                "FROM pg_catalog.pg_trigger where pg_class.oid = tgrelid) where oid = '" +
                tableName + "'::pg_catalog.regclass") ;
    }

    private void enableTableIndexes(String tableName) throws SQLException {
        // re-enable the indexes at the end of the data load and reindex the
        // table (bulk indexing is quicker as compared to updating index for
        // each of the row update)

        rbParameters = new String[]{tableName};
        logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_ENABLING_INDEXES_AFTER_DATA_LOAD", rbParameters));
        targetMD.executeScript("update pg_catalog.pg_class set relhasindex = 't' where oid in (select indrelid from pg_catalog.pg_index where indrelid =  '" + tableName
                + "'::pg_catalog.regclass)");

        if(tableName.contains("''")){
        	tableName = tableName.replace("''", "'");
        }
        targetMD.executeScript("reindex table " + tableName);

    }


    /**
     *  Set the schema name for the source redwood schema.
     */
    public void setSourceSchema(String sourceSchema) {
        this.sourceSchema = sourceSchema;
    }

    /**
     *  Set the schema name for the target EnterpriseDB schema.
     */
    public void setTargetSchema(String targetSchema) {
        this.targetSchema = targetSchema;
    }

    private void restoreTableConstsAndIndexes(Table table) throws SQLException {
        // re-create the indexes at the end of the data load (bulk indexing is quicker
        // as compared to updating index for each of the row update)
        rbParameters = new String[]{table.getTargetSchemaFullyQualifiedName(sourceDBType, targetDBType, false)};
        logMessage(ResourceHandler.getValue(DEFAULT_RES_BUNDLE_NAME, "INFO_ENABLING_INDEXES_AFTER_DATA_LOAD", rbParameters));
        // since FK constraints are not migrated in replicator context, so set
        // flagSkipFKConst to true to avoid restroing these constraints
        flagSkipFKConst = true;
        sourceMD.clearConstraintsList();
        sourceMD.clearIndexesList();
        this.copyConstraints(new String[]{Utility.removeEnclosingQuotes(table.getName())});
        this.copyIndexes(new String[]{Utility.removeEnclosingQuotes(table.getName())});
    }

    public static void incrementFailureCount() {
        failureCount++ ;
    }

    public void setFlagUserSpecifiedTargetSchemaName(boolean flagUserSpecifiedTargetSchemaName) {
        this.flagUserSpecifiedTargetSchemaName = flagUserSpecifiedTargetSchemaName;
    }

    public static boolean skipColDefaultClause() {
        return skipColDefaultClause;
    }

    public static boolean replaceNullChar() {
        return replaceNullChar;
    }

    public static String nullReplacementChar() {
        return nullReplacementChar;
    }

    //Not Supported Functions For MySQL to PG Migration
    public void copyViews(final String[] viewNames) throws SQLException {}
    public void copySynonyms(final String[] synNames) throws SQLException{}
    public void copyTriggers(final String[] triggerNames) throws SQLException {}
    public void copySequences(final String[] sequenceNames) throws SQLException {}
    public void copyPackages(final String[] packageNames) throws SQLException {}
    public void copyProcedures(final String[] procedureNames) throws SQLException {}
    public void copyFunctions(final String[] functionNames) throws SQLException {}

	public String[] getMigratingTables() {
		return migratingTables;
	}

	public void setMigratingTables(String[] migratingTables) {
		this.migratingTables = migratingTables;
	}

	public String[] getMigratingSchemas() {
		return migratingSchemas;
	}

	public static String getDefaultDateTime() {
		return defaultDateTime;
	}

	public static void setDefaultDateTime(String defaultDateTime) {
		MigrationToolkit.defaultDateTime = defaultDateTime;
	}
	
	public static void attachOutputComponent(JTextArea textArea){
		Logger.getInstance().setTextArea(textArea);
	}	
}
